import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

project_root = str(Path.cwd())

if project_root not in sys.path:
    sys.path.insert(
        0,
        project_root,
    )


import django
django.setup()


from toolkit.models import (
    ImportBatch,
    ImportRow,
    Service,
    ImportChange,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ReferenceItem,
    ComparisonMatrix,
    ComparisonEntry,
    CommunicationTemplate,
)


BATCH_ID = 5

CONTRACT_PATH = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


# ============================================================
# PROPOSED CONSERVATIVE FALLBACKS
# SIMULATION ONLY
# ============================================================

SAFE_SHEET_KIND_FALLBACKS = {
    "CERTGEM": "CERTIFICATION",
    "GRANT": "GRANT",
    "NGO_GRANT": "GRANT",
    "Women_GRANT": "GRANT",
    "EQUITY": "EQUITY",
    "LOAN ONLY": "LOAN",
}


# ============================================================
# CONTRACT INTEGRITY
# ============================================================

contract_hash = hashlib.sha256(
    CONTRACT_PATH.read_bytes()
).hexdigest()


if (
    contract_hash
    != EXPECTED_CONTRACT_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 has changed."
    )


# ============================================================
# STAGING BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if (
    batch.file_sha256
    != EXPECTED_SOURCE_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: staged source "
        "SHA-256 mismatch."
    )


metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if (
    metadata.get("operation")
    != "workbook_staging"
):
    raise SystemExit(
        "STOPPED SAFELY: Batch #5 "
        "is not the workbook staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(
        import_batch=batch
    )
)


# ============================================================
# HELPERS
# ============================================================

def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):

    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


SERVICE_KIND_KEYWORDS = {

    "REGISTRATION": (
        "registration",
    ),

    "COMPLIANCE": (
        "compliance",
    ),

    "CERTIFICATION": (
        "certification",
        "certificate",
    ),

    "GOVT_SCHEME": (
        "government scheme",
        "govt scheme",
    ),

    "GRANT": (
        "grant",
    ),

    "LOAN": (
        "loan",
    ),

    "DEBT": (
        "debt",
    ),

    "EQUITY": (
        "equity",
    ),

    "VC": (
        "venture capital",
        " vc ",
    ),

    "SUBSIDY": (
        "subsidy",
    ),

    "LEGAL": (
        "legal",
    ),

    "DIGITAL": (
        "digital",
    ),

    "CONSULTING": (
        "consulting",
        "consultancy",
    ),
}


def kind_candidates(text):

    text = (
        " "
        + text.casefold()
        + " "
    )

    matches = set()

    for kind, tokens in (
        SERVICE_KIND_KEYWORDS.items()
    ):

        for token in tokens:

            if token in text:

                matches.add(
                    kind
                )

                break

    return matches


def v1_kind_result(group):

    source_types = []

    for row in group:

        value = payload_value(
            fields(row).get(
                "scheme_type",
                {},
            )
        )

        if value:
            source_types.append(
                value
            )


    if not source_types:

        return (
            "NO_SOURCE_TYPE",
            None,
        )


    distinct_source_types = {
        value.casefold()
        for value in source_types
    }


    if len(
        distinct_source_types
    ) > 1:

        return (
            "CONFLICTING_SOURCE_TYPES",
            None,
        )


    resolved = set()

    for value in source_types:

        matches = kind_candidates(
            value
        )

        if not matches:

            return (
                "UNRECOGNISED_TYPE",
                None,
            )

        if len(matches) > 1:

            return (
                "AMBIGUOUS_TYPE",
                None,
            )

        resolved.update(
            matches
        )


    if len(resolved) != 1:

        return (
            "CONFLICTING_KIND_MAPPING",
            None,
        )


    return (
        "RESOLVED",
        next(iter(resolved)),
    )


def coordinate_collision(row):

    row_fields = fields(
        row
    )

    deadline = row_fields.get(
        "deadline",
        {},
    )

    funding = row_fields.get(
        "funding_organisation",
        {},
    )

    if not isinstance(
        deadline,
        dict,
    ):
        return False

    if not isinstance(
        funding,
        dict,
    ):
        return False

    deadline_coordinate = (
        deadline.get(
            "coordinate"
        )
    )

    funding_coordinate = (
        funding.get(
            "coordinate"
        )
    )

    return bool(
        deadline_coordinate
        and funding_coordinate
        and (
            deadline_coordinate
            == funding_coordinate
        )
    )


def unanimous_sheet_fallback(group):

    sheets = sorted(
        {
            row.sheet_name
            for row in group
        }
    )

    kinds = []

    for sheet in sheets:

        kind = (
            SAFE_SHEET_KIND_FALLBACKS
            .get(sheet)
        )

        if kind is None:

            return (
                None,
                "NOT_ALL_SHEETS_HAVE_SAFE_FALLBACK",
            )

        kinds.append(
            kind
        )


    distinct = set(
        kinds
    )

    if len(distinct) != 1:

        return (
            None,
            "SHEET_FALLBACK_CONFLICT",
        )


    return (
        next(iter(distinct)),
        "UNANIMOUS_SAFE_FALLBACK",
    )


# ============================================================
# CANONICAL GROUPS
# ============================================================

scheme_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
        and row.source_key
    )
]


groups = defaultdict(
    list
)


for row in scheme_rows:

    groups[
        row.source_key
    ].append(
        row
    )


if len(groups) != 100:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 canonical identities."
    )


# ============================================================
# SIMULATION
# ============================================================

v1_status = Counter()
v2_simulated_status = Counter()

fallback_resolution_reason = Counter()
fallback_kind_counts = Counter()

review_reason_counts = Counter()

fallback_by_sheet_combination = Counter()
review_by_sheet_combination = Counter()

transition_counts = Counter()


for identity, group in (
    groups.items()
):

    kind_result, v1_kind = (
        v1_kind_result(
            group
        )
    )

    collision = any(
        coordinate_collision(
            row
        )
        for row in group
    )


    sheets = tuple(
        sorted(
            {
                row.sheet_name
                for row in group
            }
        )
    )

    sheet_label = (
        " + ".join(sheets)
    )


    # --------------------------------------------------------
    # V1
    # --------------------------------------------------------

    if (
        kind_result == "RESOLVED"
        and not collision
    ):

        old_status = "READY"

    else:

        old_status = "REVIEW"


    v1_status[
        old_status
    ] += 1


    # --------------------------------------------------------
    # CONSERVATIVE V2 SIMULATION
    # --------------------------------------------------------

    if collision:

        new_status = "REVIEW"

        review_reason_counts[
            "SOURCE_COORDINATE_COLLISION"
        ] += 1

        review_by_sheet_combination[
            sheet_label
        ] += 1


    elif kind_result == "RESOLVED":

        new_status = "READY"

        fallback_resolution_reason[
            "V1_ALREADY_RESOLVED"
        ] += 1


    elif kind_result in {
        "NO_SOURCE_TYPE",
        "UNRECOGNISED_TYPE",
    }:

        (
            fallback_kind,
            fallback_result,
        ) = unanimous_sheet_fallback(
            group
        )


        if fallback_kind:

            new_status = "READY"

            fallback_resolution_reason[
                kind_result
            ] += 1

            fallback_kind_counts[
                fallback_kind
            ] += 1

            fallback_by_sheet_combination[
                sheet_label
            ] += 1


        else:

            new_status = "REVIEW"

            review_reason_counts[
                kind_result
                + "__"
                + fallback_result
            ] += 1

            review_by_sheet_combination[
                sheet_label
            ] += 1


    elif kind_result == "AMBIGUOUS_TYPE":

        new_status = "REVIEW"

        review_reason_counts[
            "AMBIGUOUS_SOURCE_TYPE"
        ] += 1

        review_by_sheet_combination[
            sheet_label
        ] += 1


    elif (
        kind_result
        == "CONFLICTING_SOURCE_TYPES"
    ):

        new_status = "REVIEW"

        review_reason_counts[
            "CONFLICTING_SOURCE_TYPES"
        ] += 1

        review_by_sheet_combination[
            sheet_label
        ] += 1


    else:

        new_status = "REVIEW"

        review_reason_counts[
            kind_result
        ] += 1

        review_by_sheet_combination[
            sheet_label
        ] += 1


    v2_simulated_status[
        new_status
    ] += 1


    transition_counts[
        (
            old_status,
            new_status,
        )
    ] += 1


# ============================================================
# DESTINATION SAFETY
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if (
    destination_counts["Service"]
    != 1
):
    raise SystemExit(
        "STOPPED SAFELY: live "
        "Service count changed."
    )


for name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if destination_counts[
        name
    ] != 0:

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} unexpectedly "
            "contains data."
        )


# ============================================================
# REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10c_sheet_fallback_simulation_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10C CONSERVATIVE FALLBACK SIMULATION"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    f"Canonical candidates simulated: "
    f"{len(groups)}"
)

lines.append(
    "Database writes performed: NO"
)

lines.append("")


lines.append(
    "1. PROPOSED SAFE SHEET FALLBACKS"
)

for sheet, kind in sorted(
    SAFE_SHEET_KIND_FALLBACKS.items()
):

    lines.append(
        f"  {sheet} -> {kind}"
    )


lines.append("")


lines.append(
    "2. V1 READINESS"
)

for key, value in sorted(
    v1_status.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


lines.append(
    "3. SIMULATED V2 READINESS"
)

for key, value in sorted(
    v2_simulated_status.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


lines.append(
    "4. TRANSITIONS"
)

for (
    old_status,
    new_status,
), count in sorted(
    transition_counts.items()
):

    lines.append(
        f"  {old_status} -> "
        f"{new_status}: {count}"
    )


lines.append("")


lines.append(
    "5. FALLBACK RESOLUTIONS"
)

for key, value in sorted(
    fallback_resolution_reason.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "  NEW FALLBACK MODEL KINDS"
)

if fallback_kind_counts:

    for key, value in sorted(
        fallback_kind_counts.items()
    ):

        lines.append(
            f"    {key}: {value}"
        )

else:

    lines.append(
        "    NONE"
    )


lines.append("")


lines.append(
    "6. FALLBACK CANDIDATES BY SOURCE SHEET COMBINATION"
)

if fallback_by_sheet_combination:

    for key, value in sorted(
        fallback_by_sheet_combination.items()
    ):

        lines.append(
            f"  {key}: {value}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


lines.append(
    "7. REMAINING REVIEW REASONS"
)

for key, value in sorted(
    review_reason_counts.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


lines.append(
    "8. REMAINING REVIEW BY SOURCE SHEET COMBINATION"
)

for key, value in sorted(
    review_by_sheet_combination.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


lines.append(
    "9. SAFETY"
)

for key, value in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append(
    "  Mapping Contract v1 modified: NO"
)

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Confidential cell values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10C SIMULATION COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
