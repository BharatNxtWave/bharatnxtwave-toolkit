import os
import sys
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

project_root = str(
    Path.cwd()
)

if project_root not in sys.path:
    sys.path.insert(
        0,
        project_root,
    )

import django
django.setup()


from django.contrib.auth import (
    get_user_model,
)

from toolkit.importing.staging import (
    stage_workbook,
)

from toolkit.importing.workbook_reader import (
    file_sha256,
)

from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    SavedService,
    SearchEvent,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


SOURCE_DIR = Path(
    "confidential_source"
)


matches = []

for candidate in (
    SOURCE_DIR.glob("*.xlsx")
):

    if candidate.name.startswith(
        "~$"
    ):
        continue

    if (
        file_sha256(candidate)
        == EXPECTED_SHA256
    ):
        matches.append(
            candidate
        )


if len(matches) != 1:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "exactly one approved workbook; "
        f"found {len(matches)}."
    )


workbook_path = matches[0]


# ============================================================
# SNAPSHOT LIVE TOOLKIT STATE
# ============================================================

before = {
    "Service": (
        Service.objects.count()
    ),
    "SavedService": (
        SavedService.objects.count()
    ),
    "SearchEvent": (
        SearchEvent.objects.count()
    ),
    "ImportChange": (
        ImportChange.objects.count()
    ),
    "ServiceClassification": (
        ServiceClassification.objects
        .count()
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects
        .count()
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects
        .count()
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count()
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count()
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count()
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects
        .count()
    ),
}


User = get_user_model()

actor = (
    User.objects
    .filter(
        is_superuser=True
    )
    .order_by("id")
    .first()
)


batch, summary = stage_workbook(
    workbook_path=workbook_path,
    expected_sha256=EXPECTED_SHA256,
    imported_by=actor,
)


# ============================================================
# VERIFY STAGING ONLY
# ============================================================

after = {
    "Service": (
        Service.objects.count()
    ),
    "SavedService": (
        SavedService.objects.count()
    ),
    "SearchEvent": (
        SearchEvent.objects.count()
    ),
    "ImportChange": (
        ImportChange.objects.count()
    ),
    "ServiceClassification": (
        ServiceClassification.objects
        .count()
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects
        .count()
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects
        .count()
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count()
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count()
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count()
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects
        .count()
    ),
}


if before != after:

    differences = []

    for key in before:

        if (
            before[key]
            != after[key]
        ):
            differences.append(
                f"{key}: "
                f"{before[key]} -> "
                f"{after[key]}"
            )

    raise SystemExit(
        "POST-STAGING SAFETY FAILURE: "
        "live/non-staging table changed:\n"
        + "\n".join(
            differences
        )
    )


batch_row_count = (
    ImportRow.objects
    .filter(
        import_batch=batch
    )
    .count()
)


if batch_row_count != 478:

    raise SystemExit(
        "POST-STAGING SAFETY FAILURE: "
        f"expected 478 ImportRows, "
        f"found {batch_row_count}."
    )


# ============================================================
# SAFE REPORT — COUNTS ONLY
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step9d_staging_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 9D STAGING RESULT"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    "Workbook SHA-256 verified: YES"
)

lines.append(
    "Original workbook retained by Toolkit: NO"
)

lines.append(
    "Normalized staged source rows retained: YES"
)

lines.append("")

lines.append(
    f"Total staged rows: "
    f"{summary['total_rows']}"
)

lines.append(
    f"Structured scheme rows: "
    f"{summary['structured_rows']}"
)

lines.append("")

lines.append(
    "FAMILY COUNTS"
)

for key, value in sorted(
    summary[
        "family_counts"
    ].items()
):
    lines.append(
        f"  {key}: {value}"
    )

lines.append("")

lines.append(
    "VALIDATION COUNTS"
)

for key, value in sorted(
    summary[
        "validation_counts"
    ].items()
):
    lines.append(
        f"  {key}: {value}"
    )

lines.append("")

lines.append(
    "CANDIDATE ACTION COUNTS"
)

for key, value in sorted(
    summary[
        "action_counts"
    ].items()
):
    lines.append(
        f"  {key}: {value}"
    )

lines.append("")

lines.append(
    "DUPLICATE CHECK"
)

lines.append(
    f"  Cross-sheet duplicate groups: "
    f"{summary['duplicate_groups']}"
)

lines.append(
    f"  Cross-sheet duplicate occurrences: "
    f"{summary['duplicate_occurrences']}"
)

lines.append("")

lines.append(
    "LIVE TOOLKIT SAFETY"
)

lines.append(
    f"  Service count: "
    f"{before['Service']} -> "
    f"{after['Service']}"
)

lines.append(
    f"  SavedService count: "
    f"{before['SavedService']} -> "
    f"{after['SavedService']}"
)

lines.append(
    f"  SearchEvent count: "
    f"{before['SearchEvent']} -> "
    f"{after['SearchEvent']}"
)

lines.append(
    f"  ImportChange count: "
    f"{before['ImportChange']} -> "
    f"{after['ImportChange']}"
)

lines.append("")

lines.append(
    "Service records created: 0"
)

lines.append(
    "Service records updated: 0"
)

lines.append(
    "Service classifications created: 0"
)

lines.append(
    "Commercial records created: 0"
)

lines.append(
    "Knowledge/content records created: 0"
)

lines.append(
    "Reference records created: 0"
)

lines.append(
    "Comparison records created: 0"
)

lines.append(
    "Communication templates created: 0"
)

lines.append("")

lines.append(
    "No confidential cell values "
    "are included in this report."
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 9D STAGING COMPLETE"
)

print(
    f"ImportBatch: {batch.pk}"
)

print(
    f"ImportRows: {batch_row_count}"
)

print(
    f"SAFE REPORT: {output}"
)
