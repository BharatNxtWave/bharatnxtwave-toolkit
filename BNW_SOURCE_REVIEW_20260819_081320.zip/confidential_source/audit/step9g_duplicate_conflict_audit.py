import os
import sys
import hashlib
import re
from collections import Counter, defaultdict
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

project_root = str(Path.cwd())

if project_root not in sys.path:
    sys.path.insert(0, project_root)

import django
django.setup()

from toolkit.models import (
    ImportBatch,
    ImportRow,
    Service,
    ImportChange,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ReferenceItem,
    ComparisonMatrix,
    ComparisonEntry,
    CommunicationTemplate,
)


BATCH_ID = 5

EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

EXPECTED_SCHEME_ROWS = 113
EXPECTED_NAMED_ROWS = 112
EXPECTED_DUPLICATE_GROUPS = 9
EXPECTED_DUPLICATE_ROWS = 21


# ============================================================
# LOAD AND VERIFY STAGING BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)

if batch.file_sha256 != EXPECTED_SHA256:
    raise SystemExit(
        "STOPPED SAFELY: Batch #5 SHA-256 "
        "does not match approved workbook."
    )

metadata = (
    batch.metadata
    if isinstance(batch.metadata, dict)
    else {}
)

if metadata.get("operation") != "workbook_staging":
    raise SystemExit(
        "STOPPED SAFELY: Batch #5 is not "
        "the expected staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


# ============================================================
# HELPERS
# ============================================================

def raw_dict(row):
    return (
        row.raw_data
        if isinstance(row.raw_data, dict)
        else {}
    )


def meta(row):
    value = raw_dict(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def fields(row):
    value = raw_dict(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def normalize_text(value):

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def payload_signature(payload):
    """
    Creates an internal comparison signature.

    Nothing from this signature is printed.
    """

    if not isinstance(payload, dict):
        return ""

    link = (
        payload.get("hyperlink_target")
        or payload.get("hyperlink_location")
    )

    if link:
        return (
            "LINK:"
            + normalize_text(link)
        )

    value = normalize_text(
        payload.get("value")
    )

    if not value:
        return ""

    cell_type = str(
        payload.get(
            "cell_type",
            "",
        )
    )

    return (
        f"{cell_type}:"
        f"{value}"
    )


def raw_value_signature(payload):

    if not isinstance(payload, dict):
        return ""

    return normalize_text(
        payload.get("value")
    )


def anonymous_group_id(identity):

    digest = hashlib.sha256(
        identity.encode("utf-8")
    ).hexdigest()[:8].upper()

    return f"DG-{digest}"


def compare_payloads(payloads):

    signatures = [
        payload_signature(payload)
        for payload in payloads
    ]

    populated = [
        value
        for value in signatures
        if value
    ]

    blank_count = (
        len(signatures)
        - len(populated)
    )

    unique_populated = set(
        populated
    )

    if not populated:
        return "ALL_BLANK"

    if len(unique_populated) == 1:

        if blank_count:
            return "PARTIAL_SAME"

        return "IDENTICAL"

    return "CONFLICT"


# ============================================================
# STRUCTURED SCHEME ROWS
# ============================================================

scheme_rows = [
    row
    for row in rows
    if meta(row).get(
        "family"
    ) == "SCHEME_TABLE"
]


if len(scheme_rows) != EXPECTED_SCHEME_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "113 structured rows."
    )


named_rows = [
    row
    for row in scheme_rows
    if row.source_key
]


if len(named_rows) != EXPECTED_NAMED_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "112 named structured rows."
    )


# ============================================================
# DUPLICATE GROUPS
# ============================================================

identity_rows = defaultdict(list)

for row in named_rows:

    identity_rows[
        row.source_key
    ].append(row)


duplicate_groups = {
    identity: group
    for identity, group
    in identity_rows.items()
    if len(
        {
            row.sheet_name
            for row in group
        }
    ) > 1
}


if len(duplicate_groups) != EXPECTED_DUPLICATE_GROUPS:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "9 duplicate groups."
    )


duplicate_row_count = sum(
    len(group)
    for group
    in duplicate_groups.values()
)


if duplicate_row_count != EXPECTED_DUPLICATE_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "21 duplicate rows."
    )


comparison_fields = [
    "scheme_name",
    "benefits",
    "focus_sectors",
    "eligibility",
    "deadline",
    "funding_organisation",
    "scheme_type",
    "applicable_for",
    "portal_link",
    "minimum_charge",
    "government_charge",
    "additional_info",
    "flyer",
]


group_results = []

overall_field_results = defaultdict(
    Counter
)


for identity, group in (
    duplicate_groups.items()
):

    group_id = anonymous_group_id(
        identity
    )

    locations = sorted(
        (
            row.sheet_name,
            row.source_row_number,
        )
        for row in group
    )

    field_results = {}

    for field_name in comparison_fields:

        payloads = [
            fields(row).get(
                field_name,
                {},
            )
            for row in group
        ]

        result = compare_payloads(
            payloads
        )

        field_results[
            field_name
        ] = result

        overall_field_results[
            field_name
        ][
            result
        ] += 1


    raw_title_variants = {
        raw_value_signature(
            fields(row).get(
                "scheme_name",
                {},
            )
        )
        for row in group
        if raw_value_signature(
            fields(row).get(
                "scheme_name",
                {},
            )
        )
    }


    conflict_fields = [
        field
        for field, result
        in field_results.items()
        if result == "CONFLICT"
    ]


    partial_fields = [
        field
        for field, result
        in field_results.items()
        if result == "PARTIAL_SAME"
    ]


    group_results.append(
        {
            "id": group_id,
            "locations": locations,
            "row_count": len(group),
            "sheet_count": len(
                {
                    row.sheet_name
                    for row in group
                }
            ),
            "raw_title_variant_count": len(
                raw_title_variants
            ),
            "field_results": (
                field_results
            ),
            "conflict_fields": (
                conflict_fields
            ),
            "partial_fields": (
                partial_fields
            ),
        }
    )


group_results.sort(
    key=lambda item: item["id"]
)


# ============================================================
# SOURCE-COORDINATE COLLISION AUDIT
#
# Detects cases where two canonical fields resolve to
# the exact same Excel source coordinate due to merged cells.
# ============================================================

coordinate_collisions = []


for row in scheme_rows:

    coordinate_fields = defaultdict(
        list
    )

    for field_name, payload in (
        fields(row).items()
    ):

        if not isinstance(
            payload,
            dict,
        ):
            continue

        coordinate = normalize_text(
            payload.get(
                "coordinate"
            )
        )

        if not coordinate:
            continue

        coordinate_fields[
            coordinate
        ].append(
            field_name
        )


    for coordinate, names in (
        coordinate_fields.items()
    ):

        unique_names = sorted(
            set(names)
        )

        if len(unique_names) <= 1:
            continue

        coordinate_collisions.append(
            {
                "sheet": row.sheet_name,
                "row": (
                    row.source_row_number
                ),
                "coordinate": coordinate,
                "fields": unique_names,
            }
        )


# ============================================================
# MERGED-FIELD AUDIT
# ============================================================

merged_field_locations = []


for row in scheme_rows:

    for field_name, payload in (
        fields(row).items()
    ):

        if not isinstance(
            payload,
            dict,
        ):
            continue

        merged_from = payload.get(
            "merged_from"
        )

        if not merged_from:
            continue

        merged_field_locations.append(
            {
                "sheet": row.sheet_name,
                "row": (
                    row.source_row_number
                ),
                "field": field_name,
                "resolved_coordinate": (
                    payload.get(
                        "coordinate",
                        ""
                    )
                ),
                "merged_from": (
                    merged_from
                ),
            }
        )


# ============================================================
# INVALID ROWS
# ============================================================

invalid_rows = [
    row
    for row in scheme_rows
    if row.validation_status
    == "INVALID"
]


# ============================================================
# CANONICAL COUNT
# ============================================================

singleton_identity_count = sum(
    1
    for group
    in identity_rows.values()
    if len(group) == 1
)

candidate_canonical_count = (
    singleton_identity_count
    + len(duplicate_groups)
)


# ============================================================
# DESTINATION SAFETY CHECK
# ============================================================

destination_counts = {
    "Service": (
        Service.objects.count()
    ),
    "ImportChange": (
        ImportChange.objects.count()
    ),
    "ServiceClassification": (
        ServiceClassification.objects
        .count()
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects
        .count()
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects
        .count()
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count()
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count()
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count()
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects
        .count()
    ),
}


if destination_counts[
    "Service"
] != 1:
    raise SystemExit(
        "STOPPED SAFELY: Service count changed."
    )


for model_name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if destination_counts[
        model_name
    ] != 0:
        raise SystemExit(
            "STOPPED SAFELY: destination "
            f"{model_name} is no longer empty."
        )


# ============================================================
# REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step9g_duplicate_conflict_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 9G DUPLICATE / COLLISION AUDIT"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    f"Structured rows: {len(scheme_rows)}"
)

lines.append(
    f"Named rows: {len(named_rows)}"
)

lines.append(
    f"Unique normalized identities: "
    f"{len(identity_rows)}"
)

lines.append(
    f"Singleton identities: "
    f"{singleton_identity_count}"
)

lines.append(
    f"Duplicate identity groups: "
    f"{len(duplicate_groups)}"
)

lines.append(
    f"Rows inside duplicate groups: "
    f"{duplicate_row_count}"
)

lines.append(
    f"Candidate canonical identities: "
    f"{candidate_canonical_count}"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. DUPLICATE GROUP DETAIL"
)
# ------------------------------------------------------------

for group in group_results:

    lines.append("")
    lines.append(
        f"  {group['id']}"
    )

    lines.append(
        f"    rows: {group['row_count']}"
    )

    lines.append(
        f"    sheets: {group['sheet_count']}"
    )

    lines.append(
        f"    raw title variants: "
        f"{group['raw_title_variant_count']}"
    )

    location_text = ", ".join(
        f"{sheet}:row {row_number}"
        for sheet, row_number
        in group["locations"]
    )

    lines.append(
        f"    locations: "
        f"{location_text}"
    )

    if group[
        "conflict_fields"
    ]:

        lines.append(
            "    CONFLICT fields: "
            + ", ".join(
                group[
                    "conflict_fields"
                ]
            )
        )

    else:

        lines.append(
            "    CONFLICT fields: NONE"
        )


    if group[
        "partial_fields"
    ]:

        lines.append(
            "    PARTIAL-SAME fields: "
            + ", ".join(
                group[
                    "partial_fields"
                ]
            )
        )

    else:

        lines.append(
            "    PARTIAL-SAME fields: NONE"
        )


    lines.append(
        "    field comparison:"
    )

    for field_name in (
        comparison_fields
    ):

        lines.append(
            f"      {field_name}: "
            f"{group['field_results'][field_name]}"
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. DUPLICATE FIELD SUMMARY"
)
# ------------------------------------------------------------

for field_name in (
    comparison_fields
):

    result_counter = (
        overall_field_results[
            field_name
        ]
    )

    description = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            result_counter.items()
        )
    )

    lines.append(
        f"  {field_name}: "
        f"{description}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. SOURCE COORDINATE COLLISIONS"
)
# ------------------------------------------------------------

if coordinate_collisions:

    for item in (
        coordinate_collisions
    ):

        lines.append(
            f"  {item['sheet']}: "
            f"row {item['row']} | "
            f"coordinate "
            f"{item['coordinate']} | "
            f"fields="
            f"{', '.join(item['fields'])}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. MERGED-FIELD RESOLUTIONS"
)
# ------------------------------------------------------------

if merged_field_locations:

    for item in (
        merged_field_locations
    ):

        lines.append(
            f"  {item['sheet']}: "
            f"row {item['row']} | "
            f"field={item['field']} | "
            f"resolved="
            f"{item['resolved_coordinate']} | "
            f"merged_from="
            f"{item['merged_from']}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. INVALID STRUCTURED ROWS"
)
# ------------------------------------------------------------

if invalid_rows:

    for row in invalid_rows:

        lines.append(
            f"  {row.sheet_name}: "
            f"row {row.source_row_number} | "
            f"action={row.candidate_action}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. MERGE READINESS SUMMARY"
)
# ------------------------------------------------------------

groups_without_conflicts = sum(
    1
    for group in group_results
    if not group[
        "conflict_fields"
    ]
)

groups_with_conflicts = (
    len(group_results)
    - groups_without_conflicts
)

lines.append(
    f"  Duplicate groups with "
    f"NO conflicting populated fields: "
    f"{groups_without_conflicts}"
)

lines.append(
    f"  Duplicate groups requiring "
    f"field-level merge decisions: "
    f"{groups_with_conflicts}"
)

lines.append(
    f"  Candidate canonical Service "
    f"identities before manual exclusions: "
    f"{candidate_canonical_count}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. SAFETY"
)
# ------------------------------------------------------------

for key, value in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {value}"
    )

lines.append(
    "  ImportRow records changed: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  Scheme names printed: NO"
)

lines.append(
    "  URLs printed: NO"
)

lines.append(
    "  Commercial values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 9G AUDIT COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
