import hashlib
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import django
django.setup()

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell
from openpyxl.utils import get_column_letter

from toolkit.models import ImportBatch, ImportRow
from toolkit.importing.transformation import EXPECTED_SOURCE_SHA256
from toolkit.importing.staging import extract_workbook_rows
from toolkit.importing.sheet_registry import SCHEME_TABLES
from toolkit.importing.workbook_reader import (
    build_merged_lookup,
    find_scheme_header,
)


EXPECTED_SHEETS = 20
EXPECTED_STAGED_ROWS = 478
NONSTANDARD_COLUMN_LIMIT = 30


# ============================================================
# HELPERS
# ============================================================

def sha256_file(path):
    digest = hashlib.sha256()

    with Path(path).open("rb") as handle:
        for chunk in iter(
            lambda: handle.read(1024 * 1024),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


def has_content(cell):
    if isinstance(cell, MergedCell):
        return False

    value = cell.value

    if value is not None:
        if isinstance(value, str):
            if value.strip():
                return True
        else:
            return True

    hyperlink = getattr(
        cell,
        "hyperlink",
        None,
    )

    if hyperlink:
        if getattr(hyperlink, "target", None):
            return True
        if getattr(hyperlink, "location", None):
            return True

    return False


def is_hyperlink_like(cell):
    if isinstance(cell, MergedCell):
        return False

    hyperlink = getattr(
        cell,
        "hyperlink",
        None,
    )

    if hyperlink:
        if (
            getattr(hyperlink, "target", None)
            or getattr(hyperlink, "location", None)
        ):
            return True

    value = cell.value

    if isinstance(value, str):
        return value.strip().upper().startswith(
            "=HYPERLINK("
        )

    return False


def locate_verified_workbook():
    candidates = []

    for path in (
        ROOT / "confidential_source"
    ).rglob("*.xlsx"):

        # Do not accidentally use an audit/export copy.
        if "audit" in {
            part.casefold()
            for part in path.parts
        }:
            continue

        try:
            digest = sha256_file(path)
        except Exception:
            continue

        if digest == EXPECTED_SOURCE_SHA256:
            candidates.append(path)

    if len(candidates) != 1:
        raise RuntimeError(
            "Expected exactly one confidential workbook "
            f"matching approved SHA-256; found {len(candidates)}."
        )

    return candidates[0]


def captured_coordinates(extracted_rows):
    result = defaultdict(set)

    for row in extracted_rows:
        sheet = row["sheet_name"]
        raw = row["raw_data"]

        field_payloads = raw.get(
            "fields",
            {},
        )

        if isinstance(field_payloads, dict):
            for payload in field_payloads.values():
                if not isinstance(payload, dict):
                    continue

                coordinate = payload.get(
                    "coordinate"
                )

                if coordinate:
                    result[sheet].add(
                        coordinate
                    )

        cell_payloads = raw.get(
            "cells",
            {},
        )

        if isinstance(cell_payloads, dict):
            for payload in cell_payloads.values():
                if not isinstance(payload, dict):
                    continue

                coordinate = payload.get(
                    "coordinate"
                )

                if coordinate:
                    result[sheet].add(
                        coordinate
                    )

    return result


# ============================================================
# SOURCE VERIFICATION
# ============================================================

print("=" * 92)
print("BHARATNXT WAVE — FULL WORKBOOK CELL CENSUS")
print("=" * 92)
print()
print("MODE: READ ONLY")
print("DATABASE WRITES: NO")
print("WORKBOOK WRITES: NO")
print("CELL VALUES PRINTED: NO")

workbook_path = locate_verified_workbook()

actual_hash = sha256_file(
    workbook_path
)

print()
print("SOURCE")
print("-" * 92)
print(
    "Workbook SHA-256 match:",
    actual_hash == EXPECTED_SOURCE_SHA256,
)
print(
    "Workbook file:",
    workbook_path.name,
)


# ============================================================
# RECONSTRUCT STAGING DIRECTLY FROM ORIGINAL XLSX
# ============================================================

(
    reconstructed_rows,
    reconstructed_sheet_counts,
    reconstructed_family_counts,
) = extract_workbook_rows(
    workbook_path
)

print()
print("RECONSTRUCTED STAGING")
print("-" * 92)
print(
    "Reconstructed staged rows:",
    len(reconstructed_rows),
)


# ============================================================
# DATABASE STAGING
# ============================================================

batch = ImportBatch.objects.get(
    pk=5
)

db_rows = list(
    ImportRow.objects.filter(
        import_batch=batch
    ).order_by(
        "sheet_name",
        "source_row_number",
        "id",
    )
)

print(
    "Database ImportRows:",
    len(db_rows),
)

print(
    "Batch status:",
    batch.status,
)


# ============================================================
# EXACT STAGING RECONCILIATION
# ============================================================

reconstructed_by_key = {
    (
        row["sheet_name"],
        row["source_row_number"],
    ): row
    for row in reconstructed_rows
}

db_by_key = {
    (
        row.sheet_name,
        row.source_row_number,
    ): row
    for row in db_rows
}

reconstructed_keys = set(
    reconstructed_by_key
)

db_keys = set(
    db_by_key
)

missing_from_db = (
    reconstructed_keys
    - db_keys
)

extra_in_db = (
    db_keys
    - reconstructed_keys
)

raw_payload_mismatches = []
row_hash_mismatches = []

for key in sorted(
    reconstructed_keys
    & db_keys
):
    reconstructed = (
        reconstructed_by_key[
            key
        ]
    )

    stored = db_by_key[
        key
    ]

    if (
        reconstructed["raw_data"]
        != stored.raw_data
    ):
        raw_payload_mismatches.append(
            key
        )

    if (
        reconstructed["row_hash"]
        != stored.row_hash
    ):
        row_hash_mismatches.append(
            key
        )


# ============================================================
# DIRECT WORKBOOK CELL CENSUS
# ============================================================

wb = load_workbook(
    workbook_path,
    read_only=False,
    data_only=False,
    keep_links=True,
)

captured = captured_coordinates(
    reconstructed_rows
)

sheet_report = []

total_nonempty_rows = 0
total_nonempty_cells = 0
total_hyperlinks = 0

unmapped_structured_cells = []
beyond_ad_cells = []
uncovered_hyperlinks = []
structured_preamble_cells = []

try:

    if len(wb.sheetnames) != EXPECTED_SHEETS:
        raise RuntimeError(
            f"Workbook has {len(wb.sheetnames)} sheets, "
            f"expected {EXPECTED_SHEETS}."
        )

    for sheet_name in wb.sheetnames:

        ws = wb[
            sheet_name
        ]

        physical_max_row = (
            ws.max_row or 0
        )

        physical_max_col = (
            ws.max_column or 0
        )

        nonempty_rows = set()
        nonempty_cells = []

        hyperlink_cells = []

        for row_number in range(
            1,
            physical_max_row + 1,
        ):

            for col_number in range(
                1,
                physical_max_col + 1,
            ):

                cell = ws.cell(
                    row=row_number,
                    column=col_number,
                )

                if has_content(cell):
                    nonempty_rows.add(
                        row_number
                    )

                    nonempty_cells.append(
                        cell.coordinate
                    )

                if is_hyperlink_like(
                    cell
                ):
                    hyperlink_cells.append(
                        cell.coordinate
                    )

                    if (
                        cell.coordinate
                        not in captured[
                            sheet_name
                        ]
                    ):
                        uncovered_hyperlinks.append(
                            (
                                sheet_name,
                                cell.coordinate,
                            )
                        )

        total_nonempty_rows += (
            len(nonempty_rows)
        )

        total_nonempty_cells += (
            len(nonempty_cells)
        )

        total_hyperlinks += (
            len(hyperlink_cells)
        )

        mapped_columns = set()
        header_row = None
        unmapped_count = 0
        beyond_limit_count = 0
        preamble_count = 0

        if sheet_name in SCHEME_TABLES:

            merged_lookup = (
                build_merged_lookup(
                    ws
                )
            )

            (
                header_row,
                mapping,
            ) = find_scheme_header(
                ws,
                merged_lookup,
            )

            if header_row is None:
                raise RuntimeError(
                    "Structured header missing: "
                    + sheet_name
                )

            mapped_columns = set(
                mapping.values()
            )

            # ----------------------------------------------
            # Pre-header content.
            # This is NOT silently counted as staged data.
            # We report it separately.
            # ----------------------------------------------
            for row_number in range(
                1,
                header_row,
            ):

                for col_number in range(
                    1,
                    physical_max_col + 1,
                ):

                    cell = ws.cell(
                        row=row_number,
                        column=col_number,
                    )

                    if has_content(
                        cell
                    ):
                        structured_preamble_cells.append(
                            (
                                sheet_name,
                                cell.coordinate,
                            )
                        )

                        preamble_count += 1

            # ----------------------------------------------
            # Data-bearing cells below header that are NOT
            # represented by the structured mapper.
            # ----------------------------------------------
            for row_number in range(
                header_row + 1,
                physical_max_row + 1,
            ):

                for col_number in range(
                    1,
                    physical_max_col + 1,
                ):

                    if (
                        col_number
                        in mapped_columns
                    ):
                        continue

                    cell = ws.cell(
                        row=row_number,
                        column=col_number,
                    )

                    if has_content(
                        cell
                    ):
                        unmapped_structured_cells.append(
                            (
                                sheet_name,
                                cell.coordinate,
                            )
                        )

                        unmapped_count += 1

        else:

            # ----------------------------------------------
            # Existing non-standard staging scans A:AD.
            # Any actual content after AD would have been
            # outside its capture boundary.
            # ----------------------------------------------
            if (
                physical_max_col
                > NONSTANDARD_COLUMN_LIMIT
            ):

                for row_number in range(
                    1,
                    physical_max_row + 1,
                ):

                    for col_number in range(
                        NONSTANDARD_COLUMN_LIMIT
                        + 1,
                        physical_max_col
                        + 1,
                    ):

                        cell = ws.cell(
                            row=row_number,
                            column=col_number,
                        )

                        if has_content(
                            cell
                        ):
                            beyond_ad_cells.append(
                                (
                                    sheet_name,
                                    cell.coordinate,
                                )
                            )

                            beyond_limit_count += 1

        staged_count = (
            reconstructed_sheet_counts[
                sheet_name
            ]
        )

        db_count = sum(
            1
            for row in db_rows
            if row.sheet_name
            == sheet_name
        )

        sheet_report.append(
            {
                "sheet":
                    sheet_name,

                "max_row":
                    physical_max_row,

                "max_col":
                    physical_max_col,

                "max_col_letter":
                    get_column_letter(
                        physical_max_col
                    )
                    if physical_max_col
                    else "-",

                "nonempty_rows":
                    len(
                        nonempty_rows
                    ),

                "nonempty_cells":
                    len(
                        nonempty_cells
                    ),

                "reconstructed_rows":
                    staged_count,

                "db_rows":
                    db_count,

                "hyperlinks":
                    len(
                        hyperlink_cells
                    ),

                "structured_unmapped":
                    unmapped_count,

                "beyond_ad":
                    beyond_limit_count,

                "preamble":
                    preamble_count,
            }
        )

finally:
    wb.close()


# ============================================================
# POST-IMPORT ROW ACCOUNTING
# ============================================================

empty_outcomes = [
    row
    for row in db_rows
    if not row.import_outcomes
]

processed_rows = sum(
    1
    for row in db_rows
    if row.processed_at
    is not None
)


# ============================================================
# SAFE PER-SHEET REPORT
# ============================================================

print()
print("=" * 92)
print("PER-SHEET CENSUS")
print("=" * 92)

print(
    "Sheet | Max R | Max C | Nonempty R | "
    "Nonempty C | Staged | DB | Links | "
    "Unmapped | >AD | Preamble"
)

print("-" * 92)

for item in sheet_report:

    print(
        f"{item['sheet']} | "
        f"{item['max_row']} | "
        f"{item['max_col_letter']}"
        f"({item['max_col']}) | "
        f"{item['nonempty_rows']} | "
        f"{item['nonempty_cells']} | "
        f"{item['reconstructed_rows']} | "
        f"{item['db_rows']} | "
        f"{item['hyperlinks']} | "
        f"{item['structured_unmapped']} | "
        f"{item['beyond_ad']} | "
        f"{item['preamble']}"
    )


# ============================================================
# FINAL GATES
# ============================================================

checks = {
    "WORKBOOK_HASH":
        (
            actual_hash
            == EXPECTED_SOURCE_SHA256
        ),

    "SHEET_COUNT_20":
        (
            len(sheet_report)
            == EXPECTED_SHEETS
        ),

    "RECONSTRUCTED_ROWS_478":
        (
            len(reconstructed_rows)
            == EXPECTED_STAGED_ROWS
        ),

    "DATABASE_ROWS_478":
        (
            len(db_rows)
            == EXPECTED_STAGED_ROWS
        ),

    "RECONSTRUCTED_VS_DB_ROW_KEYS":
        (
            not missing_from_db
            and not extra_in_db
        ),

    "RAW_PAYLOAD_MATCH":
        (
            len(
                raw_payload_mismatches
            )
            == 0
        ),

    "ROW_HASH_MATCH":
        (
            len(
                row_hash_mismatches
            )
            == 0
        ),

    "STRUCTURED_UNMAPPED_DATA":
        (
            len(
                unmapped_structured_cells
            )
            == 0
        ),

    "NONSTANDARD_DATA_BEYOND_AD":
        (
            len(
                beyond_ad_cells
            )
            == 0
        ),

    "HYPERLINK_CAPTURE":
        (
            len(
                uncovered_hyperlinks
            )
            == 0
        ),

    "PROCESSED_ROWS_478":
        (
            processed_rows
            == EXPECTED_STAGED_ROWS
        ),

    "EMPTY_IMPORT_OUTCOMES":
        (
            len(
                empty_outcomes
            )
            == 0
        ),
}


print()
print("=" * 92)
print("MASTER CENSUS RESULTS")
print("=" * 92)

for name, passed in checks.items():
    print(
        f"{'PASS' if passed else 'FAIL'} | "
        f"{name}"
    )


print()
print("SAFE TOTALS")
print("-" * 92)

print(
    "Workbook sheets:",
    len(sheet_report),
)

print(
    "Physical non-empty rows across workbook:",
    total_nonempty_rows,
)

print(
    "Physical non-empty cells across workbook:",
    total_nonempty_cells,
)

print(
    "Reconstructed staged rows:",
    len(reconstructed_rows),
)

print(
    "Database staged rows:",
    len(db_rows),
)

print(
    "Processed ImportRows:",
    processed_rows,
)

print(
    "Rows with empty import outcomes:",
    len(empty_outcomes),
)

print(
    "Structured unmapped populated cells:",
    len(unmapped_structured_cells),
)

print(
    "Non-standard populated cells beyond AD:",
    len(beyond_ad_cells),
)

print(
    "Workbook hyperlink/formula-link cells:",
    total_hyperlinks,
)

print(
    "Uncovered hyperlink/formula-link cells:",
    len(uncovered_hyperlinks),
)

print(
    "Structured pre-header non-empty cells:",
    len(structured_preamble_cells),
)

print(
    "Raw payload mismatches:",
    len(raw_payload_mismatches),
)

print(
    "Row-hash mismatches:",
    len(row_hash_mismatches),
)


# Only coordinates — never workbook values.
if unmapped_structured_cells:
    print()
    print(
        "UNMAPPED STRUCTURED COORDINATES "
        "(first 30):"
    )

    for sheet, coordinate in (
        unmapped_structured_cells[
            :30
        ]
    ):
        print(
            f"  {sheet}:{coordinate}"
        )


if beyond_ad_cells:
    print()
    print(
        "BEYOND-AD COORDINATES "
        "(first 30):"
    )

    for sheet, coordinate in (
        beyond_ad_cells[
            :30
        ]
    ):
        print(
            f"  {sheet}:{coordinate}"
        )


if uncovered_hyperlinks:
    print()
    print(
        "UNCOVERED LINK COORDINATES "
        "(first 30):"
    )

    for sheet, coordinate in (
        uncovered_hyperlinks[
            :30
        ]
    ):
        print(
            f"  {sheet}:{coordinate}"
        )


if structured_preamble_cells:
    print()
    print(
        "STRUCTURED PRE-HEADER CONTENT "
        "(first 30 coordinates):"
    )

    for sheet, coordinate in (
        structured_preamble_cells[
            :30
        ]
    ):
        print(
            f"  {sheet}:{coordinate}"
        )


strict_pass = all(
    checks.values()
)


print()
print("=" * 92)

if strict_pass:
    print(
        "FULL WORKBOOK DATA CENSUS: PASS"
    )
else:
    print(
        "FULL WORKBOOK DATA CENSUS: FAIL"
    )

print(
    "DATABASE WRITES: NO"
)

print(
    "WORKBOOK WRITES: NO"
)

print("=" * 92)

if not strict_pass:
    sys.exit(2)
