import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

project_root = str(Path.cwd())

if project_root not in sys.path:
    sys.path.insert(0, project_root)

import django
django.setup()

from openpyxl.utils.cell import column_index_from_string

from toolkit.models import (
    ImportBatch,
    ImportRow,
    Service,
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

EXPECTED_TOTAL_ROWS = 478
EXPECTED_SCHEME_ROWS = 113


# ============================================================
# FIND EXACT STAGING BATCH
# ============================================================

batch = None

for candidate in (
    ImportBatch.objects
    .filter(
        file_sha256=EXPECTED_SHA256
    )
    .order_by("-id")
):

    metadata = (
        candidate.metadata
        if isinstance(candidate.metadata, dict)
        else {}
    )

    if metadata.get("operation") == "workbook_staging":
        batch = candidate
        break


if batch is None:
    raise SystemExit(
        "STOPPED SAFELY: staging batch not found."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


if len(rows) != EXPECTED_TOTAL_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: unexpected staged row count."
    )


# ============================================================
# HELPERS
# ============================================================

def raw_dict(row):

    return (
        row.raw_data
        if isinstance(row.raw_data, dict)
        else {}
    )


def meta(row):

    value = raw_dict(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def fields(row):

    value = raw_dict(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def payload_populated(payload):

    if not isinstance(payload, dict):
        return False

    value = payload.get("value")

    if (
        value is not None
        and str(value).strip()
    ):
        return True

    if payload.get("hyperlink_target"):
        return True

    if payload.get("hyperlink_location"):
        return True

    return False


def coordinate_column(payload):

    if not isinstance(payload, dict):
        return None

    coordinate = str(
        payload.get(
            "coordinate",
            "",
        )
    ).strip()

    match = re.match(
        r"^([A-Z]+)\d+$",
        coordinate,
        flags=re.I,
    )

    if not match:
        return None

    return match.group(1).upper()


def link_storage_type(payload):

    if not isinstance(payload, dict):
        return "BLANK"

    if not payload_populated(payload):
        return "BLANK"

    has_link = bool(
        payload.get("hyperlink_target")
        or payload.get("hyperlink_location")
    )

    is_formula = (
        payload.get("cell_type")
        == "f"
    )

    if has_link and is_formula:
        return "HYPERLINK_AND_FORMULA"

    if has_link:
        return "EXCEL_HYPERLINK"

    if is_formula:
        return "FORMULA_ONLY"

    return "PLAIN_VALUE"


def deadline_category(payload):

    if not isinstance(payload, dict):
        return "BLANK"

    value = payload.get("value")

    if (
        value is None
        or not str(value).strip()
    ):
        return "BLANK"

    cell_type = payload.get(
        "cell_type"
    )

    if cell_type == "d":
        return "EXCEL_DATE"

    text = str(value).strip().casefold()

    if re.search(
        r"\brolling\b",
        text,
    ):
        return "ROLLING_TEXT"

    if re.search(
        r"\b(on\s*going|ongoing)\b",
        text,
    ):
        return "ONGOING_TEXT"

    if re.search(
        r"\bclosed?\b",
        text,
    ):
        return "CLOSED_TEXT"

    if re.search(
        r"\bopen\b",
        text,
    ):
        return "OPEN_TEXT"

    if re.search(
        r"\b(no deadline|no last date)\b",
        text,
    ):
        return "NO_DEADLINE_TEXT"

    if re.search(
        r"\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}",
        text,
    ):
        return "DATE_LIKE_TEXT"

    if re.search(
        r"\b\d{1,2}\s+"
        r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)",
        text,
    ):
        return "DATE_LIKE_TEXT"

    return "OTHER_TEXT"


# ============================================================
# STRUCTURED ROWS
# ============================================================

scheme_rows = [
    row
    for row in rows
    if meta(row).get("family")
    == "SCHEME_TABLE"
]


if len(scheme_rows) != EXPECTED_SCHEME_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected 113 scheme rows."
    )


# ============================================================
# FIELD → COLUMN MAPPING
# ============================================================

field_columns = defaultdict(
    lambda: defaultdict(
        defaultdict(int)
    )
)


for row in scheme_rows:

    for field_name, payload in (
        fields(row).items()
    ):

        column = coordinate_column(
            payload
        )

        if column:

            field_columns[
                row.sheet_name
            ][
                field_name
            ][
                column
            ] += 1


# ============================================================
# LINK STORAGE AUDIT
# ============================================================

link_fields = [
    "portal_link",
    "flyer",
    "additional_info",
    "government_charge",
]


link_storage = defaultdict(
    lambda: defaultdict(
        Counter
    )
)


link_locations = defaultdict(
    list
)


for row in scheme_rows:

    row_fields = fields(row)

    for field_name in link_fields:

        if field_name not in row_fields:
            continue

        payload = row_fields[
            field_name
        ]

        storage = link_storage_type(
            payload
        )

        link_storage[
            row.sheet_name
        ][
            field_name
        ][
            storage
        ] += 1

        if (
            field_name
            in {
                "government_charge",
                "additional_info",
            }
            and (
                payload.get(
                    "hyperlink_target"
                )
                or payload.get(
                    "hyperlink_location"
                )
            )
        ):

            link_locations[
                field_name
            ].append(
                (
                    row.sheet_name,
                    row.source_row_number,
                )
            )


# ============================================================
# DEADLINE AUDIT
# ============================================================

deadline_categories = Counter()

deadline_by_sheet = defaultdict(
    Counter
)


for row in scheme_rows:

    payload = fields(row).get(
        "deadline",
        {},
    )

    category = deadline_category(
        payload
    )

    deadline_categories[
        category
    ] += 1

    deadline_by_sheet[
        row.sheet_name
    ][
        category
    ] += 1


# ============================================================
# SCHEME TYPE COVERAGE
# ============================================================

scheme_type_by_sheet = defaultdict(
    Counter
)


for row in scheme_rows:

    row_fields = fields(row)

    if "scheme_type" not in row_fields:

        scheme_type_by_sheet[
            row.sheet_name
        ][
            "NOT_MAPPED"
        ] += 1

    elif payload_populated(
        row_fields["scheme_type"]
    ):

        scheme_type_by_sheet[
            row.sheet_name
        ][
            "POPULATED"
        ] += 1

    else:

        scheme_type_by_sheet[
            row.sheet_name
        ][
            "BLANK"
        ] += 1


# ============================================================
# INVALID ROW STRUCTURAL SHAPE
# ============================================================

invalid_shapes = []


for row in scheme_rows:

    if row.validation_status != "INVALID":
        continue

    populated_fields = []

    blank_fields = []

    for field_name, payload in (
        fields(row).items()
    ):

        if payload_populated(payload):

            populated_fields.append(
                field_name
            )

        else:

            blank_fields.append(
                field_name
            )

    invalid_shapes.append(
        {
            "sheet": row.sheet_name,
            "row": row.source_row_number,
            "populated_fields": sorted(
                populated_fields
            ),
            "blank_fields": sorted(
                blank_fields
            ),
        }
    )


# ============================================================
# UNIQUE IDENTITY STRUCTURE
# ============================================================

named_rows = [
    row
    for row in scheme_rows
    if row.source_key
]


identity_counts = Counter(
    row.source_key
    for row in named_rows
)


unique_identity_count = len(
    identity_counts
)


duplicate_identity_groups = sum(
    1
    for count in identity_counts.values()
    if count > 1
)


duplicate_identity_rows = sum(
    count
    for count in identity_counts.values()
    if count > 1
)


# ============================================================
# EXISTING SERVICE MATCH WARNING CHECK
# ============================================================

existing_match_warnings = sum(
    1
    for row in scheme_rows
    if (
        "existing_service_title_match"
        in (
            row.validation_warnings
            or []
        )
    )
)


# ============================================================
# OUTPUT SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step9f_mapping_semantics_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 9F MAPPING SEMANTICS AUDIT"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    f"Structured rows: {len(scheme_rows)}"
)

lines.append(
    "Workbook opened during this audit: NO"
)

lines.append(
    "Database writes performed: NO"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. FIELD → SOURCE COLUMN MAP"
)
# ------------------------------------------------------------

for sheet_name in sorted(
    field_columns
):

    lines.append(
        f"  {sheet_name}"
    )

    for field_name in sorted(
        field_columns[
            sheet_name
        ]
    ):

        columns = field_columns[
            sheet_name
        ][
            field_name
        ]

        description = ", ".join(
            f"{column}({count})"
            for column, count
            in sorted(
                columns.items(),
                key=lambda item:
                    column_index_from_string(
                        item[0]
                    ),
            )
        )

        lines.append(
            f"    {field_name}: "
            f"{description}"
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. LINK STORAGE BY SHEET"
)
# ------------------------------------------------------------

for sheet_name in sorted(
    link_storage
):

    lines.append(
        f"  {sheet_name}"
    )

    for field_name in sorted(
        link_storage[
            sheet_name
        ]
    ):

        counts = link_storage[
            sheet_name
        ][
            field_name
        ]

        description = ", ".join(
            f"{key}={value}"
            for key, value
            in sorted(
                counts.items()
            )
        )

        lines.append(
            f"    {field_name}: "
            f"{description}"
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. LINK-BEARING NON-LINK FIELD LOCATIONS"
)
# ------------------------------------------------------------

for field_name in [
    "government_charge",
    "additional_info",
]:

    locations = link_locations[
        field_name
    ]

    if not locations:

        lines.append(
            f"  {field_name}: NONE"
        )

        continue

    lines.append(
        f"  {field_name}:"
    )

    for sheet_name, row_number in locations:

        lines.append(
            f"    {sheet_name}: "
            f"row {row_number}"
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. DEADLINE CLASSIFICATION PREVIEW"
)
# ------------------------------------------------------------

for key, value in sorted(
    deadline_categories.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "  BY SHEET"
)

for sheet_name in sorted(
    deadline_by_sheet
):

    description = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            deadline_by_sheet[
                sheet_name
            ].items()
        )
    )

    lines.append(
        f"    {sheet_name}: "
        f"{description}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. SCHEME TYPE COVERAGE BY SHEET"
)
# ------------------------------------------------------------

for sheet_name in sorted(
    scheme_type_by_sheet
):

    description = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            scheme_type_by_sheet[
                sheet_name
            ].items()
        )
    )

    lines.append(
        f"  {sheet_name}: "
        f"{description}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. INVALID ROW STRUCTURE"
)
# ------------------------------------------------------------

if not invalid_shapes:

    lines.append(
        "  NONE"
    )

else:

    for item in invalid_shapes:

        lines.append(
            f"  {item['sheet']}: "
            f"row {item['row']}"
        )

        lines.append(
            "    populated canonical fields: "
            + (
                ", ".join(
                    item[
                        "populated_fields"
                    ]
                )
                or "NONE"
            )
        )

        lines.append(
            "    blank canonical fields: "
            + (
                ", ".join(
                    item[
                        "blank_fields"
                    ]
                )
                or "NONE"
            )
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. CANONICAL IDENTITY STRUCTURE"
)
# ------------------------------------------------------------

lines.append(
    f"  Named structured rows: "
    f"{len(named_rows)}"
)

lines.append(
    f"  Unique normalized identities: "
    f"{unique_identity_count}"
)

lines.append(
    f"  Duplicate identity groups: "
    f"{duplicate_identity_groups}"
)

lines.append(
    f"  Rows participating in duplicate identities: "
    f"{duplicate_identity_rows}"
)

lines.append(
    f"  Existing live Service title-match warnings: "
    f"{existing_match_warnings}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. SAFETY"
)
# ------------------------------------------------------------

lines.append(
    f"  Current Service count: "
    f"{Service.objects.count()}"
)

lines.append(
    "  ImportRow records changed: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  Confidential values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 9F AUDIT COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
