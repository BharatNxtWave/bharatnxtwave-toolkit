import csv
import hashlib
import io
import re

from collections import Counter
from datetime import date, datetime
from difflib import SequenceMatcher
from pathlib import Path

from openpyxl import load_workbook

from toolkit.models import Category, Service


ALIASES = {
    "scheme_name": (
        "scheme",
        "scheme name",
        "service",
        "service name",
        "program",
        "programme",
    ),
    "benefits": (
        "benefit",
        "benefits",
        "assistance",
        "support",
    ),
    "eligibility": (
        "eligibility",
        "eligible",
        "eligibility criteria",
    ),
    "deadline": (
        "deadline",
        "last date",
        "application deadline",
        "closing date",
    ),
    "focus_sectors": (
        "sector",
        "sectors",
        "industry",
        "industries",
    ),
    "funding_organisation": (
        "funding organisation",
        "funding organization",
        "organisation",
        "organization",
    ),
    "scheme_type": (
        "scheme type",
    ),
    "applicable_for": (
        "applicable for",
        "who can apply",
    ),
    "portal_link": (
        "portal link",
        "application link",
        "apply link",
        "website",
        "url",
    ),
    "flyer": (
        "flyer",
        "brochure",
    ),
    "additional_info": (
        "additional info",
        "additional information",
        "reference",
    ),
    "government_charge": (
        "government fee",
        "government fees",
        "govt fee",
        "govt fees",
    ),
    "minimum_charge": (
        "minimum charge",
        "minimum charges",
        "consultancy fee",
        "our fee",
    ),
    "vendor_cost": (
        "vendor cost",
        "vendor costs",
        "govt fees vendor cost",
    ),
    "bdm_deduction": (
        "bdm deduction",
        "bdm deductions",
    ),
    "commercial_remark": (
        "remark",
        "remarks",
    ),
}


SECTIONS = (
    (
        "ELIGIBILITY",
        (
            "eligibility",
            "eligible",
            "minimum requirement",
            "who can apply",
        ),
    ),
    (
        "DOCUMENTS",
        (
            "documents required",
            "required documents",
            "checklist",
        ),
    ),
    (
        "PROCESS",
        (
            "how to",
            "process",
            "steps to",
            "procedure",
            "incorporate",
        ),
    ),
    (
        "BENEFITS",
        (
            "benefit",
            "advantages",
        ),
    ),
    (
        "FUNDING",
        (
            "funding",
            "fund scheme",
            "financial assistance",
        ),
    ),
    (
        "TIMELINE",
        (
            "timeline",
            "working days",
            "processing time",
        ),
    ),
    (
        "SCOPE",
        (
            "scope of work",
            "descriptive scope",
        ),
    ),
    (
        "COMMERCIAL",
        (
            "commercial",
            "amount to be charge",
            "charges",
            "consultancy fee",
        ),
    ),
    (
        "NOTES",
        (
            "please note",
            "note:",
        ),
    ),
)


CATEGORY_RULES = (
    (
        "startup-and-msme-recognition",
        "REGISTRATION",
        (
            "startup india",
            "dpiit recognition",
            "start-up india",
        ),
    ),
    (
        "company-incorporation",
        "REGISTRATION",
        (
            "private limited",
            "pvt ltd",
            "llp incorporation",
            "llp registration",
            "company incorporation",
            "opc",
        ),
    ),
    (
        "gst-and-tax-compliance",
        "COMPLIANCE",
        (
            "gst",
            "income tax",
            "80-iac",
            "80iac",
            "tax exemption",
        ),
    ),
    (
        "government-grants",
        "GRANT",
        (
            "grant",
        ),
    ),
    (
        "credit-and-guarantee-schemes",
        "GOVT_SCHEME",
        (
            "credit guarantee",
            "loan scheme",
        ),
    ),
    (
        "funding-programs",
        "GOVT_SCHEME",
        (
            "seed fund",
            "funding program",
            "funding programme",
        ),
    ),
    (
        "equity-funding",
        "EQUITY",
        (
            "equity",
            "venture fund",
            "vc fund",
            "angel fund",
        ),
    ),
    (
        "debt-funding",
        "DEBT",
        (
            "debt funding",
        ),
    ),
    (
        "licenses",
        "REGISTRATION",
        (
            "license",
            "licence",
        ),
    ),
    (
        "certifications",
        "CERTIFICATION",
        (
            "certificate",
            "certification",
            "iso",
            "zed",
            "nsic",
        ),
    ),
    (
        "trademark-and-intellectual-property",
        "LEGAL",
        (
            "trademark",
            "patent",
            "ipr",
        ),
    ),
    (
        "website-development",
        "DIGITAL",
        (
            "website",
            "web development",
        ),
    ),
    (
        "digital-marketing",
        "DIGITAL",
        (
            "digital marketing",
        ),
    ),
    (
        "seo",
        "DIGITAL",
        (
            "seo",
            "search engine optimization",
        ),
    ),
    (
        "social-media",
        "DIGITAL",
        (
            "social media",
        ),
    ),
)


def norm(value):
    return re.sub(
        r"[^a-z0-9]+",
        " ",
        str(value or "").lower(),
    ).strip()


def safe(value):
    if value is None:
        return ""

    if isinstance(
        value,
        (
            datetime,
            date,
        ),
    ):
        return value.isoformat()

    if isinstance(
        value,
        (
            str,
            int,
            float,
            bool,
        ),
    ):
        return value

    return str(value)


def sha256(file_obj):
    file_obj.seek(0)

    digest = hashlib.sha256()

    for chunk in iter(
        lambda: file_obj.read(
            1024 * 1024
        ),
        b"",
    ):
        digest.update(chunk)

    file_obj.seek(0)

    return digest.hexdigest()


def field_for_header(value):
    text = norm(value)

    for field, aliases in ALIASES.items():
        for alias in aliases:
            if (
                text == alias
                or (
                    len(alias) >= 7
                    and alias in text
                )
            ):
                return field

    return None


def detect_header(rows):
    best = None

    for row_no, values, _ in rows[:30]:

        mapped = {}

        nonempty = sum(
            bool(norm(value))
            for value in values
        )

        for index, value in enumerate(
            values
        ):
            field = field_for_header(
                value
            )

            if (
                field
                and field not in mapped
            ):
                mapped[field] = index

        score = (
            len(mapped) * 10
            + min(nonempty, 10)
        )

        if (
            mapped
            and (
                best is None
                or score > best["score"]
            )
        ):
            best = {
                "row": row_no,
                "mapping": mapped,
                "nonempty": nonempty,
                "score": score,
            }

    return best


def sheet_kind(rows, header):

    values = [
        str(value)
        for _, row, _ in rows
        for value in row
        if str(value or "").strip()
    ]

    joined = " ".join(
        norm(value)
        for value in values[:1000]
    )

    max_width = max(
        (
            len(row)
            for _, row, _ in rows
        ),
        default=0,
    )

    mapping = (
        header["mapping"]
        if header
        else {}
    )

    # --------------------------------------------------------
    # DATA SHAPE
    # --------------------------------------------------------

    data_rows = []

    if header:

        for row_no, row, links in rows:

            if row_no > header["row"]:
                data_rows.append(row)

    else:

        data_rows = [
            row
            for _, row, _ in rows
        ]

    meaningful_data_rows = [
        row
        for row in data_rows
        if any(
            str(value or "").strip()
            for value in row
        )
    ]

    multi_cell_rows = sum(
        sum(
            bool(str(value or "").strip())
            for value in row
        ) >= 2
        for row in meaningful_data_rows
    )

    pair_ratio = (
        multi_cell_rows
        / len(meaningful_data_rows)
        if meaningful_data_rows
        else 0
    )

    # --------------------------------------------------------
    # COMMERCIAL SERVICE TABLE
    #
    # Do NOT classify a narrative knowledge sheet as a
    # commercial catalogue simply because the text contains
    # words such as consultancy fee.
    #
    # We require actual commercial COLUMNS with repeated data.
    # --------------------------------------------------------

    commercial_fields = {
        "vendor_cost",
        "bdm_deduction",
        "minimum_charge",
        "government_charge",
        "commercial_remark",
    }

    actual_commercial_fields = (
        commercial_fields
        & set(mapping)
    )

    if (
        header
        and "scheme_name" in mapping
        and actual_commercial_fields
    ):

        title_index = mapping[
            "scheme_name"
        ]

        commercial_indexes = [
            mapping[field]
            for field
            in actual_commercial_fields
            if field in mapping
        ]

        titled = 0
        commercial_rows = 0

        for row in meaningful_data_rows:

            title = (
                row[title_index]
                if title_index < len(row)
                else ""
            )

            if not str(
                title or ""
            ).strip():
                continue

            titled += 1

            has_commercial = any(
                index < len(row)
                and str(
                    row[index] or ""
                ).strip()
                for index
                in commercial_indexes
            )

            if has_commercial:
                commercial_rows += 1

        commercial_ratio = (
            commercial_rows / titled
            if titled
            else 0
        )

        if (
            commercial_rows >= 5
            and commercial_ratio >= 0.35
        ):
            return "COMMERCIAL_SERVICE_TABLE"

    # --------------------------------------------------------
    # COMMUNICATION
    # --------------------------------------------------------

    communication_signals = sum(
        marker in joined
        for marker in (
            "subject",
            "dear ",
            "regards",
            "thank you",
            "email",
            "mail",
            "attached",
        )
    )

    knowledge_signals = sum(
        marker in joined
        for marker in (
            "eligibility",
            "eligibility criteria",
            "documents required",
            "required documents",
            "scope of work",
            "benefits",
            "objectives",
            "timeline",
            "how to",
            "minimum requirements",
            "financial assistance",
            "incorporation",
            "registration process",
        )
    )

    if (
        max_width <= 2
        and communication_signals >= 3
        and knowledge_signals <= 1
    ):
        return "COMMUNICATION"

    # --------------------------------------------------------
    # HORIZONTAL COMPARISON MATRIX
    # --------------------------------------------------------

    if header:

        nonempty = header["nonempty"]
        recognised = len(mapping)

        unrecognised = max(
            0,
            nonempty - recognised,
        )

        if (
            "scheme_name" in mapping
            and nonempty >= 4
            and unrecognised >= 3
            and recognised <= 2
        ):
            return "COMPARISON_MATRIX"

    # --------------------------------------------------------
    # NORMAL STRUCTURED SERVICE TABLE
    #
    # IMPORTANT:
    # Check this BEFORE narrative detection.
    #
    # A real scheme table naturally contains columns such as
    # Benefits and Eligibility. Those words must not make the
    # whole table look like narrative knowledge.
    # --------------------------------------------------------

    if (
        header
        and "scheme_name" in mapping
        and len(mapping) >= 2
    ):
        return "STRUCTURED_TABLE"

    # --------------------------------------------------------
    # SIMPLE REFERENCE TABLE
    #
    # Example:
    # Sr No | Benefit
    # --------------------------------------------------------

    if (
        header
        and "scheme_name" not in mapping
        and header["nonempty"] <= 3
        and pair_ratio >= 0.60
    ):
        return "REFERENCE_TABLE"

    # --------------------------------------------------------
    # NARRATIVE KNOWLEDGE
    # --------------------------------------------------------

    long_ratio = (
        sum(
            len(value.strip()) >= 35
            for value in values
        )
        / len(values)
        if values
        else 0
    )

    if (
        knowledge_signals >= 2
        and (
            long_ratio >= 0.08
            or (
                max_width <= 3
                and pair_ratio < 0.60
            )
        )
    ):
        return "NARRATIVE_KNOWLEDGE"

    if header:
        return "REFERENCE_TABLE"

    return "UNKNOWN"


def section_type(text):

    normalized = norm(text)

    for section, markers in SECTIONS:

        if any(
            marker in normalized
            for marker in markers
        ):
            return section

    return None


def is_heading(text):

    raw = str(
        text or ""
    ).strip()

    normalized = norm(raw)

    return bool(
        raw
        and (
            (
                raw.startswith("*")
                and raw.endswith("*")
            )
            or (
                len(raw) <= 110
                and section_type(raw)
            )
            or (
                len(raw) <= 90
                and (
                    raw.endswith(":")
                    or normalized
                    in {
                        "benefits",
                        "commercials",
                        "timeline",
                    }
                )
            )
        )
    )


def propose(text, available):

    normalized = norm(text)

    for (
        category_slug,
        service_kind,
        markers,
    ) in CATEGORY_RULES:

        if (
            category_slug in available
            and any(
                marker in normalized
                for marker in markers
            )
        ):
            return {
                "category_slug":
                    category_slug,

                "service_kind":
                    service_kind,

                "confidence":
                    0.85,
            }

    fallback = (
        "other-business-services"
        if (
            "other-business-services"
            in available
        )
        else None
    )

    return {
        "category_slug":
            fallback,

        "service_kind":
            "OTHER",

        "confidence":
            0.35,
    }


def match_service(
    title,
    services,
):

    normalized = norm(
        title
    )

    if not normalized:

        return {
            "action": "INVALID",
            "matched_service_id": None,
            "score": 0,
        }

    for (
        service_id,
        service_title,
    ) in services:

        if (
            norm(service_title)
            == normalized
        ):
            return {
                "action":
                    "UPDATE",

                "matched_service_id":
                    service_id,

                "score":
                    1,
            }

    best = max(
        (
            (
                SequenceMatcher(
                    None,
                    normalized,
                    norm(service_title),
                ).ratio(),

                service_id,
            )
            for (
                service_id,
                service_title,
            )
            in services
        ),
        default=(0, None),
    )

    if best[0] >= 0.90:

        return {
            "action":
                "MERGE_REVIEW",

            "matched_service_id":
                best[1],

            "score":
                round(
                    best[0],
                    4,
                ),
        }

    return {
        "action":
            "CREATE",

        "matched_service_id":
            None,

        "score":
            round(
                best[0],
                4,
            ),
    }


def structured_candidates(
    rows,
    header,
    available,
    services,
):

    result = []

    mapping = header[
        "mapping"
    ]

    for (
        row_no,
        values,
        links,
    ) in rows:

        if (
            row_no
            <= header["row"]
        ):
            continue

        fields = {}
        source_links = []

        for (
            field,
            index,
        ) in mapping.items():

            if (
                index < len(values)
                and str(
                    values[index]
                ).strip()
            ):
                fields[field] = safe(
                    values[index]
                )

            if (
                index < len(links)
                and links[index]
            ):
                source_links.append(
                    {
                        "field":
                            field,

                        "url":
                            links[index],
                    }
                )

        title = str(
            fields.get(
                "scheme_name",
                "",
            )
        ).strip()

        if not title:
            continue

        combined = (
            title
            + " "
            + " ".join(
                str(value)
                for value
                in fields.values()
            )
        )

        result.append(
            {
                "source_row":
                    row_no,

                "title":
                    title,

                "fields":
                    fields,

                "links":
                    source_links,

                "proposal":
                    propose(
                        combined,
                        available,
                    ),

                "match":
                    match_service(
                        title,
                        services,
                    ),
            }
        )

    return result


def narrative_candidate(
    sheet_name,
    rows,
    available,
    services,
):

    sections = []
    seen = set()

    current = "OTHER"
    title = None

    for (
        row_no,
        values,
        links,
    ) in rows:

        for (
            column,
            value,
        ) in enumerate(
            values,
            1,
        ):

            text = str(
                value or ""
            ).strip()

            key = (
                row_no,
                norm(text),
            )

            if (
                not text
                or key in seen
            ):
                continue

            seen.add(
                key
            )

            heading = is_heading(
                text
            )

            detected = section_type(
                text
            )

            if (
                heading
                and detected
            ):
                current = detected

            if (
                title is None
                and len(text) <= 180
            ):

                normalized = norm(
                    text
                )

                if any(
                    marker in normalized
                    for marker in (
                        "registration",
                        "scheme",
                        "startup india",
                        "seed fund",
                        "tax exemption",
                        "certificate",
                        "incorporation",
                        "licence",
                        "license",
                    )
                ):
                    title = re.sub(
                        r"[*_]+",
                        "",
                        text,
                    ).strip(
                        " :-"
                    )

            url = (
                links[
                    column - 1
                ]
                if (
                    column - 1
                    < len(links)
                )
                else None
            )

            sections.append(
                {
                    "source_row":
                        row_no,

                    "source_column":
                        column,

                    "section_type":
                        (
                            detected
                            if (
                                heading
                                and detected
                            )
                            else current
                        ),

                    "is_heading":
                        heading,

                    "content":
                        text,

                    "url":
                        url,
                }
            )

    title = (
        title
        or sheet_name.replace(
            "_",
            " ",
        ).strip()
    )

    combined = (
        title
        + " "
        + " ".join(
            item["content"]
            for item
            in sections[:80]
        )
    )

    return {
        "source_row":
            (
                sections[0][
                    "source_row"
                ]
                if sections
                else 1
            ),

        "title":
            title,

        "sections":
            sections,

        "proposal":
            propose(
                combined,
                available,
            ),

        "match":
            match_service(
                title,
                services,
            ),
    }


def xlsx_sheets(
    file_obj,
):

    file_obj.seek(0)

    workbook = load_workbook(
        file_obj,
        read_only=False,
        data_only=False,
    )

    result = []

    try:

        for worksheet in (
            workbook.worksheets
        ):

            rows = []

            max_column = min(
                worksheet.max_column
                or 1,
                200,
            )

            for row in worksheet.iter_rows(
                min_row=1,
                max_row=(
                    worksheet.max_row
                    or 1
                ),
                max_col=max_column,
            ):

                values = [
                    safe(cell.value)
                    for cell in row
                ]

                links = [
                    (
                        cell.hyperlink.target
                        if cell.hyperlink
                        else None
                    )
                    for cell in row
                ]

                if any(
                    str(value).strip()
                    or link
                    for (
                        value,
                        link,
                    )
                    in zip(
                        values,
                        links,
                    )
                ):

                    while (
                        values
                        and not str(
                            values[-1]
                        ).strip()
                        and not links[-1]
                    ):
                        values.pop()
                        links.pop()

                    rows.append(
                        (
                            row[0].row,
                            values,
                            links,
                        )
                    )

            result.append(
                (
                    worksheet.title,
                    rows,
                )
            )

    finally:

        workbook.close()

        file_obj.seek(0)

    return result


def csv_sheets(
    file_obj,
):

    file_obj.seek(0)

    raw = file_obj.read()

    file_obj.seek(0)

    if isinstance(
        raw,
        bytes,
    ):

        try:
            text = raw.decode(
                "utf-8-sig"
            )

        except UnicodeDecodeError:

            text = raw.decode(
                "cp1252"
            )

    else:
        text = raw

    try:

        dialect = csv.Sniffer().sniff(
            text[:8192],
            delimiters=",;\t|",
        )

    except csv.Error:

        dialect = csv.excel

    rows = []

    for (
        row_no,
        values,
    ) in enumerate(
        csv.reader(
            io.StringIO(text),
            dialect,
        ),
        1,
    ):

        values = [
            safe(value)
            for value
            in values
        ]

        if any(
            str(value).strip()
            for value in values
        ):

            rows.append(
                (
                    row_no,
                    values,
                    [None] * len(
                        values
                    ),
                )
            )

    return [
        (
            "CSV",
            rows,
        )
    ]


def analyse_file(
    file_obj,
    filename,
):

    extension = Path(
        filename
    ).suffix.lower()

    if extension not in {
        ".xlsx",
        ".csv",
    }:

        raise ValueError(
            "Only .xlsx and .csv files are supported."
        )

    available = set(
        Category.objects
        .values_list(
            "slug",
            flat=True,
        )
    )

    services = list(
        Service.objects
        .values_list(
            "id",
            "title",
        )
    )

    if extension == ".xlsx":

        source_sheets = (
            xlsx_sheets(
                file_obj
            )
        )

    else:

        source_sheets = (
            csv_sheets(
                file_obj
            )
        )

    sheets = []

    action_counts = Counter()
    kind_counts = Counter()

    total_candidates = 0

    for (
        sheet_name,
        rows,
    ) in source_sheets:

        header = detect_header(
            rows
        )

        kind = sheet_kind(
            rows,
            header,
        )

        kind_counts[
            kind
        ] += 1

        candidates = []

        if (
            kind in {
                "STRUCTURED_TABLE",
                "COMMERCIAL_SERVICE_TABLE",
            }
            and header
        ):

            candidates = (
                structured_candidates(
                    rows,
                    header,
                    available,
                    services,
                )
            )

        elif (
            kind
            == "NARRATIVE_KNOWLEDGE"
        ):

            candidate = (
                narrative_candidate(
                    sheet_name,
                    rows,
                    available,
                    services,
                )
            )

            if candidate[
                "sections"
            ]:

                candidates = [
                    candidate
                ]

        for candidate in (
            candidates
        ):

            action_counts[
                candidate[
                    "match"
                ][
                    "action"
                ]
            ] += 1

        total_candidates += len(
            candidates
        )

        sheets.append(
            {
                "name":
                    sheet_name,

                "kind":
                    kind,

                "nonempty_rows":
                    len(rows),

                "header_row":
                    (
                        header["row"]
                        if header
                        else None
                    ),

                "field_mapping":
                    (
                        header[
                            "mapping"
                        ]
                        if header
                        else {}
                    ),

                "candidate_count":
                    len(
                        candidates
                    ),

                "candidates":
                    candidates,
            }
        )

    return {
        "engine_version":
            "1.1",

        "business_knowledge_visibility":
            "BDE",

        "commercial_business_data_visible_to_bde":
            True,

        "technical_import_internals_visible_to_bde":
            False,

        "source_type":
            (
                "XLSX"
                if extension
                == ".xlsx"
                else "CSV"
            ),

        "source_name":
            Path(
                filename
            ).name,

        "file_sha256":
            sha256(
                file_obj
            ),

        "sheet_count":
            len(
                sheets
            ),

        "sheet_type_counts":
            dict(
                kind_counts
            ),

        "candidate_count":
            total_candidates,

        "candidate_action_counts":
            dict(
                action_counts
            ),

        "sheets":
            sheets,

        "database_writes":
            0,
    }
