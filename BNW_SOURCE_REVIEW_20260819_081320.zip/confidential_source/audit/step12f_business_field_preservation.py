import os
import sys
import inspect
from collections import Counter
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import django
django.setup()

import toolkit.importing.transformation as transformation

from toolkit.importing.transformation import (
    build_core_transformation_plan,
    load_verified_context,
    payload_value,
)


print("=" * 84)
print("BHARATNXT WAVE — STEP 12F BUSINESS FIELD PRESERVATION")
print("=" * 84)
print()
print("MODE: READ ONLY")
print("BUSINESS VALUES PRINTED: NO")
print("DATABASE WRITES: NO")


contract, batch, rows = (
    load_verified_context()
)

rows = list(rows)

core = (
    build_core_transformation_plan()
)

services = core.get(
    "services",
    {},
)


# ============================================================
# 1. EXACT SERVICE PLAN FIELD UNIVERSE
# ============================================================

service_keys = set()

for item in services.values():

    if isinstance(item, dict):
        service_keys.update(
            item.keys()
        )


print()
print("=" * 84)
print("1. PLANNED SERVICE FIELD UNIVERSE")
print("=" * 84)

print(
    "Planned Services:",
    len(services),
)

for key in sorted(service_keys):
    print(
        f"  {key}"
    )


# ============================================================
# 2. CONTRACT-RELEVANT SOURCE FIELD COVERAGE
# ============================================================

SOURCE_FIELDS = (
    "scheme_name",
    "benefits",
    "eligibility",
    "funding_organisation",
    "applicable_for",
    "deadline",
    "minimum_charge",
    "government_fee",
    "additional_charges",
    "portal",
    "flyer",
    "additional_info",
)


structured_rows = [
    row
    for row in rows
    if row.sheet_name in {
        "GRANT",
        "Women_GRANT",
        "Agriculture_FUND",
        "NGO_GRANT",
        "EQUITY",
        "GRANTDEBTEQUITY",
        "DEBTEQUITY",
        "LOAN ONLY",
        "LOANSUBSIDY",
        "CERTGEM",
        "Rolling_Grants",
    }
]


print()
print("=" * 84)
print("2. STRUCTURED SOURCE FIELD POPULATION")
print("=" * 84)

print(
    "Structured source rows:",
    len(structured_rows),
)


for field_name in SOURCE_FIELDS:

    populated = 0

    for row in structured_rows:

        try:

            value = payload_value(
                row,
                field_name,
            )

        except Exception:

            value = None

        if value not in (
            None,
            "",
            [],
            {},
        ):
            populated += 1

    print(
        f"  {field_name}: "
        f"{populated} populated row(s)"
    )


# ============================================================
# 3. DESTINATION FIELD EXPECTATIONS
# ============================================================

EXPECTED_DESTINATION_FIELDS = {
    "title":
        "Service.title",

    "benefits":
        "Service.benefits",

    "eligibility":
        "Service.eligibility_summary",

    "funding_organisation":
        "Service.funding_organisation",

    "applicable_for":
        "Service.applicable_for_raw",

    "deadline":
        (
            "Service.application_deadline_raw / "
            "application_deadline / deadline_status"
        ),

    "minimum_charge":
        "ServiceCommercial.minimum_charge_raw",

    "government_fee":
        "ServiceCommercial.government_fee_raw",

    "portal":
        "ServiceSource",

    "flyer":
        "ServiceSource",

    "additional_info":
        "ServiceSource or preserved source content",
}


print()
print("=" * 84)
print("3. DESTINATION PRESERVATION CHECK")
print("=" * 84)


service_plan_expectations = {
    "title":
        (
            "title"
            in service_keys
        ),

    "benefits":
        (
            "benefits"
            in service_keys
        ),

    "eligibility":
        (
            "eligibility_summary"
            in service_keys
            or "eligibility"
            in service_keys
        ),

    "funding_organisation":
        (
            "funding_organisation"
            in service_keys
        ),

    "applicable_for":
        (
            "applicable_for_raw"
            in service_keys
            or "applicable_for"
            in service_keys
        ),

    "deadline":
        any(
            field in service_keys
            for field in (
                "application_deadline_raw",
                "application_deadline",
                "deadline_status",
            )
        ),
}


for source_name, destination in (
    EXPECTED_DESTINATION_FIELDS.items()
):

    if source_name in (
        "minimum_charge",
        "government_fee",
        "portal",
        "flyer",
        "additional_info",
    ):

        status = (
            "SEPARATE SUPPORTING PLAN"
        )

    else:

        status = (
            "PRESENT"
            if service_plan_expectations[
                source_name
            ]
            else "MISSING FROM SERVICE PLAN"
        )

    print(
        f"  {source_name}: "
        f"{status}"
    )

    print(
        f"    destination: "
        f"{destination}"
    )


# ============================================================
# 4. IDENTIFY ACTUAL SERVICE-BUILDER FUNCTIONS
# ============================================================

print()
print("=" * 84)
print("4. SERVICE TRANSFORMATION IMPLEMENTATION")
print("=" * 84)


matches = []


for name, obj in inspect.getmembers(
    transformation,
    inspect.isfunction,
):

    if obj.__module__ != transformation.__name__:
        continue

    try:

        source = inspect.getsource(
            obj
        )

    except Exception:

        continue


    if (
        "source_row_ids"
        in source
        and (
            '"title"'
            in source
            or "'title'"
            in source
        )
    ):

        matches.append(
            (
                name,
                inspect.getsourcelines(
                    obj
                )[1],
                source,
            )
        )


print(
    "Matching builder functions:",
    len(matches),
)


IMPORTANT_TOKENS = (
    "benefits",
    "eligibility",
    "funding_organisation",
    "applicable_for_raw",
    "application_deadline_raw",
    "application_deadline",
    "deadline_status",
    "source_row_ids",
)


for name, line_number, source in matches:

    print()
    print(
        f"FUNCTION: {name}"
    )

    print(
        f"START LINE: {line_number}"
    )

    for token in IMPORTANT_TOKENS:

        print(
            f"  contains {token}: "
            f"{'YES' if token in source else 'NO'}"
        )


# ============================================================
# 5. FINAL VERDICT
# ============================================================

missing_core_fields = [
    field
    for field, present
    in service_plan_expectations.items()
    if not present
]


print()
print("=" * 84)
print("5. COMPLETENESS VERDICT")
print("=" * 84)

print(
    "Missing contract-relevant Service fields:",
    len(missing_core_fields),
)

for field in missing_core_fields:
    print(
        f"  - {field}"
    )


if missing_core_fields:

    print()
    print(
        "SERVICE TRANSFORMATION COMPLETENESS: FAIL"
    )

    print(
        "IMPORT MUST REMAIN BLOCKED."
    )

else:

    print()
    print(
        "SERVICE TRANSFORMATION COMPLETENESS: PASS"
    )


print()
print("=" * 84)
print("STEP 12F COMPLETE")
print("DATABASE WRITES: NO")
print("LIVE IMPORT: NOT STARTED")
print("=" * 84)
