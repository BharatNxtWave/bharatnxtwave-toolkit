import inspect
import os
import sys
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import django
django.setup()

from django.apps import apps

from toolkit.importing.transformation import (
    build_core_transformation_plan,
    load_verified_context,
)

from toolkit.importing.supporting_transformation import (
    build_supporting_transformation_plan,
)


print("=" * 80)
print("BHARATNXT WAVE — STEP 12B PLAN / SCHEMA FINGERPRINT")
print("=" * 80)
print()
print("MODE: READ ONLY")
print("CONFIDENTIAL VALUES PRINTED: NO")
print("DATABASE WRITES: NO")


# ============================================================
# HELPERS
# ============================================================

def describe_collection(name, value):

    print()
    print(f"[{name}]")
    print("type:", type(value).__name__)

    if isinstance(value, dict):

        print("count:", len(value))

        if value:

            sample_value = next(
                iter(value.values())
            )

            print(
                "value_type:",
                type(sample_value).__name__,
            )

            if isinstance(
                sample_value,
                dict,
            ):
                print(
                    "value_fields:",
                    ", ".join(
                        sorted(
                            sample_value.keys()
                        )
                    ),
                )

    elif isinstance(
        value,
        (list, tuple, set),
    ):

        print("count:", len(value))

        if value:

            sample = next(
                iter(value)
            )

            print(
                "item_type:",
                type(sample).__name__,
            )

            if isinstance(
                sample,
                dict,
            ):
                print(
                    "item_fields:",
                    ", ".join(
                        sorted(
                            sample.keys()
                        )
                    ),
                )

    else:
        print(
            "value_shape: scalar/object"
        )


def model_schema(model_name):

    model = apps.get_model(
        "toolkit",
        model_name,
    )

    print()
    print(f"[MODEL {model_name}]")

    for field in model._meta.get_fields():

        if not getattr(
            field,
            "concrete",
            False,
        ):
            continue

        remote = getattr(
            field,
            "remote_field",
            None,
        )

        related = None

        if remote is not None:

            related_model = getattr(
                remote,
                "model",
                None,
            )

            if related_model is not None:
                related = getattr(
                    related_model,
                    "__name__",
                    str(related_model),
                )

        print(
            field.name,
            "|",
            field.__class__.__name__,
            "| null=",
            getattr(
                field,
                "null",
                False,
            ),
            "| blank=",
            getattr(
                field,
                "blank",
                False,
            ),
            "| unique=",
            getattr(
                field,
                "unique",
                False,
            ),
            "| related=",
            related,
        )


# ============================================================
# FUNCTION SIGNATURES
# ============================================================

print()
print("=" * 80)
print("1. TRANSFORMATION FUNCTION SIGNATURES")
print("=" * 80)

print(
    "build_core_transformation_plan",
    inspect.signature(
        build_core_transformation_plan
    ),
)

print(
    "build_supporting_transformation_plan",
    inspect.signature(
        build_supporting_transformation_plan
    ),
)

print(
    "load_verified_context",
    inspect.signature(
        load_verified_context
    ),
)


# ============================================================
# VERIFIED CONTEXT
# ============================================================

print()
print("=" * 80)
print("2. VERIFIED IMPORT CONTEXT")
print("=" * 80)

contract, batch, staged_rows = (
    load_verified_context()
)

print(
    "contract_version:",
    contract.get(
        "contract",
        {},
    ).get(
        "version",
        "UNKNOWN",
    ),
)

print(
    "import_batch_id:",
    batch.id,
)

print(
    "import_batch_status:",
    batch.status,
)

print(
    "staged_rows:",
    len(staged_rows),
)


# ============================================================
# CORE PLAN
# ============================================================

print()
print("=" * 80)
print("3. CORE TRANSFORMATION PLAN")
print("=" * 80)

core = build_core_transformation_plan()

print(
    "core_type:",
    type(core).__name__,
)

if not isinstance(
    core,
    dict,
):
    raise SystemExit(
        "STOPPED: core transformation plan is not a dictionary."
    )

print(
    "core_top_level_field_count:",
    len(core),
)

print(
    "core_top_level_fields:",
    ", ".join(
        sorted(
            core.keys()
        )
    ),
)

for name in sorted(
    core.keys()
):
    describe_collection(
        name,
        core[name],
    )


# ============================================================
# SUPPORTING PLAN
# ============================================================

print()
print("=" * 80)
print("4. SUPPORTING TRANSFORMATION PLAN")
print("=" * 80)

supporting = (
    build_supporting_transformation_plan(
        core
    )
)

print(
    "supporting_type:",
    type(supporting).__name__,
)

if not isinstance(
    supporting,
    dict,
):
    raise SystemExit(
        "STOPPED: supporting plan is not a dictionary."
    )

print(
    "supporting_top_level_field_count:",
    len(supporting),
)

print(
    "supporting_top_level_fields:",
    ", ".join(
        sorted(
            supporting.keys()
        )
    ),
)

for name in sorted(
    supporting.keys()
):
    describe_collection(
        name,
        supporting[name],
    )


# ============================================================
# CRITICAL MODEL SCHEMAS
# ============================================================

print()
print("=" * 80)
print("5. CRITICAL IMPORT MODEL SCHEMAS")
print("=" * 80)

for model_name in (
    "ImportBatch",
    "ImportRow",
    "ImportChange",
    "Service",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceSource",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):
    model_schema(
        model_name
    )


# ============================================================
# CURRENT DATABASE COUNTS
# ============================================================

print()
print("=" * 80)
print("6. CURRENT DATABASE COUNTS")
print("=" * 80)

for model_name in (
    "Service",
    "ServiceDomain",
    "Category",
    "ImportBatch",
    "ImportRow",
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceSource",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):

    model = apps.get_model(
        "toolkit",
        model_name,
    )

    print(
        f"{model_name}: "
        f"{model.objects.count()}"
    )


print()
print("=" * 80)
print("STEP 12B FINGERPRINT COMPLETE")
print("DATABASE WRITES: NO")
print("=" * 80)
