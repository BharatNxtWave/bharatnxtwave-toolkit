#!/usr/bin/env bash
set -euo pipefail

cd "/mnt/d/BharatNXT Wave/BharatNXTwave Toolkit"
source .venv/bin/activate

echo ""
echo "============================================================"
echo "STEP 11D — PRIVATE KNOWLEDGE CANDIDATE RANKING"
echo "============================================================"

RUNNER="confidential_source/audit/step11d_knowledge_candidate_ranking.py"

if [ -e "$RUNNER" ]; then
    echo "STOPPED SAFELY: $RUNNER already exists."
    echo "No file was overwritten."
    exit 41
fi


cat > "$RUNNER" <<'PY'
import hashlib
import json
import os
import re
import sys

from collections import Counter
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.importing.transformation import (
    build_core_transformation_plan,
    load_verified_context,
    normalize_identity,
)

from toolkit.importing.supporting_transformation import (
    row_text,
)

from toolkit.models import (
    Category,
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ServiceDomain,
    ServiceSource,
)


# ============================================================
# CONSTANTS
# ============================================================

KNOWLEDGE_SHEETS = (
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
)


SIGNATURES = {

    "START_UP INDIA": {

        "phrases": (
            "startup india",
            "start up india",
            "dpiit",
            "startup recognition",
            "startup registration",
            "startup india registration",
        ),

        "acronyms": (
            "dpiit",
        ),

        "categories": (
            "startup-and-msme-recognition",
            "business-registrations",
            "sector-specific-schemes",
        ),

        "domains": (
            "business-incorporation-and-launch",
            "government-schemes-and-grants",
        ),

        "kinds": (
            "REGISTRATION",
            "GOVT_SCHEME",
            "OTHER",
        ),
    },


    "TAX_CERT": {

        "phrases": (
            "tax certificate",
            "tax certification",
            "tax exemption",
            "tax exempt",
            "tax holiday",
            "80iac",
            "80 iac",
            "section 80iac",
        ),

        "acronyms": (
            "80iac",
        ),

        "categories": (
            "certifications",
            "gst-and-tax-compliance",
            "startup-and-msme-recognition",
        ),

        "domains": (
            "licenses-registrations-and-certifications",
            "compliance-management",
            "business-incorporation-and-launch",
        ),

        "kinds": (
            "CERTIFICATION",
            "COMPLIANCE",
            "OTHER",
        ),
    },


    "SEED FUND": {

        "phrases": (
            "seed fund",
            "seed funding",
            "startup india seed fund",
            "seed fund scheme",
            "sisfs",
        ),

        "acronyms": (
            "sisfs",
        ),

        "categories": (
            "government-grants",
            "sector-specific-schemes",
            "funding-programs",
            "investor-connect",
        ),

        "domains": (
            "government-schemes-and-grants",
            "funding-and-equity-support",
        ),

        "kinds": (
            "GRANT",
            "GOVT_SCHEME",
            "EQUITY",
            "OTHER",
        ),
    },


    "PVT": {

        "phrases": (
            "private limited",
            "pvt ltd",
            "pvt limited",
            "private company",
            "company incorporation",
            "company registration",
        ),

        "acronyms": (
            "pvt",
        ),

        "categories": (
            "company-incorporation",
            "business-registrations",
        ),

        "domains": (
            "business-incorporation-and-launch",
        ),

        "kinds": (
            "REGISTRATION",
            "OTHER",
        ),
    },


    "LLP": {

        "phrases": (
            "limited liability partnership",
            "llp registration",
            "llp incorporation",
            "llp",
        ),

        "acronyms": (
            "llp",
        ),

        "categories": (
            "company-incorporation",
            "business-registrations",
        ),

        "domains": (
            "business-incorporation-and-launch",
        ),

        "kinds": (
            "REGISTRATION",
            "OTHER",
        ),
    },
}


PRIVATE_JSON = Path(
    "confidential_source/audit/"
    "step11d_knowledge_candidates_PRIVATE.json"
)

PRIVATE_TEXT = Path(
    "confidential_source/audit/"
    "step11d_knowledge_candidates_PRIVATE.txt"
)

SAFE_REPORT = Path(
    "confidential_source/audit/"
    "step11d_knowledge_candidates_SAFE_TO_SHARE.txt"
)


# ============================================================
# HELPERS
# ============================================================

def anonymous_id(identity):
    return (
        "SVC-"
        + hashlib.sha256(
            identity.encode(
                "utf-8"
            )
        ).hexdigest()[:10].upper()
    )


def contains_phrase(
    text,
    phrase,
):
    text = normalize_identity(
        text
    )

    phrase = normalize_identity(
        phrase
    )

    if not text or not phrase:
        return False

    return bool(
        re.search(
            r"(?:^|\s)"
            + re.escape(
                phrase
            )
            + r"(?:\s|$)",
            text,
        )
    )


def token_set(value):
    return set(
        normalize_identity(
            value
        ).split()
    )


def content_evidence(
    identity,
    rows,
):
    candidate_tokens = (
        token_set(
            identity
        )
    )

    exact = 0
    full_containment = 0
    early_containment = 0
    earliest = None

    ordered = sorted(
        rows,
        key=lambda row: (
            row.source_row_number,
            row.id,
        ),
    )

    early_ids = {
        row.id
        for row in ordered[:10]
    }

    for row in ordered:

        text = row_text(
            row
        )

        normalized = (
            normalize_identity(
                text
            )
        )

        row_tokens = set(
            normalized.split()
        )

        if normalized == identity:
            exact += 1

        if (
            candidate_tokens
            and candidate_tokens.issubset(
                row_tokens
            )
        ):

            full_containment += 1

            if row.id in early_ids:
                early_containment += 1

            if (
                earliest is None
                or row.source_row_number
                < earliest
            ):
                earliest = (
                    row.source_row_number
                )

    return {
        "exact":
            exact,

        "containment":
            full_containment,

        "early_containment":
            early_containment,

        "earliest":
            earliest,
    }


# ============================================================
# DB SNAPSHOT
# ============================================================

def snapshot():
    return {

        "Service":
            Service.objects.count(),

        "ServiceDomain":
            ServiceDomain.objects.count(),

        "Category":
            Category.objects.count(),

        "ImportRow":
            ImportRow.objects.count(),

        "ImportChange":
            ImportChange.objects.count(),

        "ServiceClassification":
            ServiceClassification.objects.count(),

        "ServiceSource":
            ServiceSource.objects.count(),

        "ServiceCommercial":
            ServiceCommercial.objects.count(),

        "ServiceContentSection":
            ServiceContentSection.objects.count(),

        "ReferenceItem":
            ReferenceItem.objects.count(),

        "ComparisonMatrix":
            ComparisonMatrix.objects.count(),

        "ComparisonEntry":
            ComparisonEntry.objects.count(),

        "CommunicationTemplate":
            CommunicationTemplate.objects.count(),
    }


EXPECTED_DB = {

    "Service": 1,

    "ServiceDomain": 8,

    "Category": 32,

    "ImportRow": 478,

    "ImportChange": 0,

    "ServiceClassification": 0,

    "ServiceSource": 0,

    "ServiceCommercial": 0,

    "ServiceContentSection": 0,

    "ReferenceItem": 0,

    "ComparisonMatrix": 0,

    "ComparisonEntry": 0,

    "CommunicationTemplate": 0,
}


before = snapshot()


if before != EXPECTED_DB:

    raise SystemExit(
        "STOPPED SAFELY: database state differs "
        "from approved pre-import state."
    )


# ============================================================
# LOAD COMPLETE 162-SERVICE PLAN
# ============================================================

(
    contract,
    batch,
    staged_rows,
) = load_verified_context()


core = (
    build_core_transformation_plan()
)


services = core[
    "services"
]


if len(services) != 162:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "162 planned Services."
    )


# ============================================================
# SCORE ALL 162 SERVICES FOR EACH KNOWLEDGE SHEET
# ============================================================

rankings = {}


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    signature = (
        SIGNATURES[
            sheet_name
        ]
    )

    sheet_rows = [
        row
        for row in staged_rows
        if row.sheet_name
        == sheet_name
    ]


    scored = []


    for identity, plan in (
        services.items()
    ):

        score = 0

        reasons = []


        # ----------------------------------------------------
        # 1. Strong semantic title phrases
        # ----------------------------------------------------

        phrase_hits = [
            phrase
            for phrase in (
                signature[
                    "phrases"
                ]
            )
            if contains_phrase(
                identity,
                phrase,
            )
        ]


        if phrase_hits:

            phrase_score = (
                120
                + (
                    max(
                        len(
                            token_set(
                                phrase
                            )
                        )
                        for phrase
                        in phrase_hits
                    )
                    * 15
                )
            )

            score += (
                phrase_score
            )

            reasons.append(
                "STRONG_TITLE_SIGNATURE"
            )


        # ----------------------------------------------------
        # 2. Acronym/title evidence
        # ----------------------------------------------------

        acronym_hits = [
            acronym
            for acronym in (
                signature[
                    "acronyms"
                ]
            )
            if contains_phrase(
                identity,
                acronym,
            )
        ]


        if acronym_hits:

            score += 140

            reasons.append(
                "ACRONYM_TITLE_MATCH"
            )


        # ----------------------------------------------------
        # 3. Expected category
        # ----------------------------------------------------

        if (
            plan[
                "category_slug"
            ]
            in signature[
                "categories"
            ]
        ):

            score += 45

            reasons.append(
                "EXPECTED_CATEGORY"
            )


        # ----------------------------------------------------
        # 4. Expected domain
        # ----------------------------------------------------

        if (
            plan[
                "domain_slug"
            ]
            in signature[
                "domains"
            ]
        ):

            score += 25

            reasons.append(
                "EXPECTED_DOMAIN"
            )


        # ----------------------------------------------------
        # 5. Expected service kind
        # ----------------------------------------------------

        if (
            plan[
                "service_kind"
            ]
            in signature[
                "kinds"
            ]
        ):

            score += 25

            reasons.append(
                "EXPECTED_KIND"
            )


        # ----------------------------------------------------
        # 6. Knowledge-content evidence
        # ----------------------------------------------------

        evidence = (
            content_evidence(
                identity,
                sheet_rows,
            )
        )


        if evidence[
            "exact"
        ]:

            score += (
                150
                * evidence[
                    "exact"
                ]
            )

            reasons.append(
                "EXACT_CONTENT_IDENTITY"
            )


        if evidence[
            "containment"
        ]:

            score += min(
                100,
                evidence[
                    "containment"
                ]
                * 12,
            )

            reasons.append(
                "CONTENT_CONTAINMENT"
            )


        if evidence[
            "early_containment"
        ]:

            score += min(
                75,
                evidence[
                    "early_containment"
                ]
                * 20,
            )

            reasons.append(
                "EARLY_CONTENT_EVIDENCE"
            )


        # ----------------------------------------------------
        # 7. Sheet signature terms occurring in Service title
        # ----------------------------------------------------

        signature_tokens = set()

        for phrase in (
            signature[
                "phrases"
            ]
        ):
            signature_tokens.update(
                token_set(
                    phrase
                )
            )


        identity_tokens = token_set(
            identity
        )


        overlap = (
            identity_tokens
            & signature_tokens
        )


        if overlap:

            overlap_score = min(
                60,
                len(overlap)
                * 15,
            )

            score += (
                overlap_score
            )

            reasons.append(
                "SIGNATURE_TOKEN_OVERLAP"
            )


        # ----------------------------------------------------
        # Mild penalty for single-token generic candidates
        # unless they match a sheet acronym.
        # ----------------------------------------------------

        if (
            len(
                identity_tokens
            )
            == 1
            and not acronym_hits
            and not phrase_hits
        ):

            score -= 20


        scored.append(
            {
                "identity":
                    identity,

                "anonymous_id":
                    anonymous_id(
                        identity
                    ),

                "service_id":
                    plan[
                        "service_id"
                    ],

                "title":
                    plan[
                        "title"
                    ],

                "source_family":
                    plan[
                        "source_family"
                    ],

                "service_kind":
                    plan[
                        "service_kind"
                    ],

                "domain_slug":
                    plan[
                        "domain_slug"
                    ],

                "category_slug":
                    plan[
                        "category_slug"
                    ],

                "score":
                    score,

                "reasons":
                    reasons,

                "content_exact":
                    evidence[
                        "exact"
                    ],

                "content_containment":
                    evidence[
                        "containment"
                    ],

                "early_containment":
                    evidence[
                        "early_containment"
                    ],

                "earliest_content_row":
                    evidence[
                        "earliest"
                    ],
            }
        )


    scored.sort(
        key=lambda item: (
            item[
                "score"
            ],
            item[
                "content_exact"
            ],
            item[
                "early_containment"
            ],
            item[
                "content_containment"
            ],
            item[
                "title"
            ].casefold(),
        ),
        reverse=True,
    )


    top_five = (
        scored[:5]
    )


    rankings[
        sheet_name
    ] = (
        top_five
    )


# ============================================================
# PRIVATE JSON
# ============================================================

private_payload = {

    "warning": (
        "CONFIDENTIAL: contains BharatNXT "
        "Service names. Do not paste into chat."
    ),

    "contract_version":
        contract[
            "contract"
        ][
            "version"
        ],

    "import_batch_id":
        batch.id,

    "instructions": (
        "Review ranks 1-5 for each knowledge "
        "sheet and return only the chosen rank "
        "number, never the Service name."
    ),

    "rankings": {},
}


for sheet_name, candidates in (
    rankings.items()
):

    private_payload[
        "rankings"
    ][
        sheet_name
    ] = []


    for rank, candidate in enumerate(
        candidates,
        start=1,
    ):

        item = dict(
            candidate
        )

        item[
            "rank"
        ] = rank

        private_payload[
            "rankings"
        ][
            sheet_name
        ].append(
            item
        )


PRIVATE_JSON.write_text(
    json.dumps(
        private_payload,
        indent=2,
        ensure_ascii=False,
    )
    + "\n",
    encoding="utf-8",
)


# ============================================================
# PRIVATE HUMAN-READABLE REPORT
# ============================================================

private_lines = [

    "=" * 80,

    "BHARATNXT WAVE — PRIVATE KNOWLEDGE ANCHOR CANDIDATES",

    "=" * 80,

    "",

    "CONFIDENTIAL.",

    (
        "DO NOT COPY THIS FILE INTO CHAT. "
        "SEND ONLY RANK NUMBERS 1-5."
    ),

    "",

]


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    private_lines.append(
        "-" * 80
    )

    private_lines.append(
        sheet_name
    )

    private_lines.append(
        "-" * 80
    )


    for rank, candidate in enumerate(
        rankings[
            sheet_name
        ],
        start=1,
    ):

        private_lines.append(
            (
                f"RANK {rank}: "
                f"{candidate['title']}"
            )
        )

        private_lines.append(
            (
                f"  Service ID: "
                f"{candidate['service_id']}"
            )
        )

        private_lines.append(
            (
                f"  Anonymous ID: "
                f"{candidate['anonymous_id']}"
            )
        )

        private_lines.append(
            (
                f"  Score: "
                f"{candidate['score']}"
            )
        )

        private_lines.append(
            (
                f"  Source family: "
                f"{candidate['source_family']}"
            )
        )

        private_lines.append(
            (
                f"  Kind: "
                f"{candidate['service_kind']}"
            )
        )

        private_lines.append(
            (
                f"  Domain: "
                f"{candidate['domain_slug']}"
            )
        )

        private_lines.append(
            (
                f"  Category: "
                f"{candidate['category_slug']}"
            )
        )

        private_lines.append(
            (
                "  Evidence: "
                + (
                    ", ".join(
                        candidate[
                            "reasons"
                        ]
                    )
                    if candidate[
                        "reasons"
                    ]
                    else "NONE"
                )
            )
        )

        private_lines.append(
            (
                "  Content exact / containment / early: "
                f"{candidate['content_exact']} / "
                f"{candidate['content_containment']} / "
                f"{candidate['early_containment']}"
            )
        )

        private_lines.append(
            ""
        )


PRIVATE_TEXT.write_text(
    "\n".join(
        private_lines
    ),
    encoding="utf-8",
)


# ============================================================
# SAFE REPORT
# ============================================================

safe_lines = [

    "=" * 80,

    (
        "BHARATNXT WAVE — "
        "STEP 11D KNOWLEDGE CANDIDATE RANKING"
    ),

    "=" * 80,

    "",

    (
        f"Mapping Contract version: "
        f"{contract['contract']['version']}"
    ),

    (
        f"Import Batch ID: "
        f"{batch.id}"
    ),

    "Candidate universe: ALL 162 planned Services",

    "Database writes performed: NO",

    "",

    "1. TOP-5 ANONYMOUS CANDIDATES",
]


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    safe_lines.append(
        f"  {sheet_name}"
    )


    candidates = (
        rankings[
            sheet_name
        ]
    )


    for rank, candidate in enumerate(
        candidates,
        start=1,
    ):

        safe_lines.append(
            (
                f"    {rank}. "
                f"{candidate['anonymous_id']} | "
                f"score={candidate['score']} | "
                f"family={candidate['source_family']} | "
                f"kind={candidate['service_kind']} | "
                f"category={candidate['category_slug']}"
            )
        )


    if len(candidates) >= 2:

        gap = (
            candidates[
                0
            ][
                "score"
            ]
            - candidates[
                1
            ][
                "score"
            ]
        )

    else:

        gap = 0


    safe_lines.append(
        (
            f"    top-vs-runner score gap: "
            f"{gap}"
        )
    )


safe_lines.extend(
    [
        "",
        "2. PRIVATE REVIEW ARTIFACT",
        (
            "  Private candidate file created: YES"
        ),
        (
            "  Contains actual Service names: YES"
        ),
        (
            "  Names printed to terminal: NO"
        ),
        (
            "  User should return only ranks 1-5: YES"
        ),
        "",
        "3. DATABASE SAFETY",
    ]
)


after = snapshot()


if after != before:

    raise SystemExit(
        "STOPPED SAFELY: candidate ranking "
        "changed database counts."
    )


for key, value in (
    after.items()
):

    safe_lines.append(
        f"  {key}: {value}"
    )


safe_lines.extend(
    [
        "",
        "4. RESULT",
        (
            "  AUTOMATIC KNOWLEDGE IMPORT "
            "REMAINS BLOCKED"
        ),
        (
            "  PRIVATE HUMAN SEMANTIC REVIEW REQUIRED"
        ),
        (
            "  LIVE DATABASE IMPORT: NOT STARTED"
        ),
    ]
)


SAFE_REPORT.write_text(
    "\n".join(
        safe_lines
    ),
    encoding="utf-8",
)


print(
    "STEP 11D CANDIDATE RANKING COMPLETE"
)

print(
    "Candidate universe: 162 Services"
)

print(
    "Private report created locally."
)

print(
    f"PRIVATE FILE: {PRIVATE_TEXT}"
)

print(
    f"SAFE REPORT: {SAFE_REPORT}"
)

print(
    "Do not paste the PRIVATE file into chat."
)
PY


echo ""
echo "===== COMPILE ====="

python -m py_compile \
    confidential_source/audit/step11d_knowledge_candidate_ranking.py


echo ""
echo "===== DJANGO CHECK ====="

python manage.py check


echo ""
echo "===== MIGRATION CHECK ====="

python manage.py makemigrations \
    --check \
    --dry-run


echo ""
echo "===== RUN PRIVATE RANKING ====="

PYTHONPATH="$PWD" \
python \
    confidential_source/audit/step11d_knowledge_candidate_ranking.py


chmod 600 \
    confidential_source/audit/step11d_knowledge_candidates_PRIVATE.json \
    confidential_source/audit/step11d_knowledge_candidates_PRIVATE.txt \
    2>/dev/null || true


echo ""
echo "===== SAFE REPORT ====="

cat \
    confidential_source/audit/step11d_knowledge_candidates_SAFE_TO_SHARE.txt


echo ""
echo "===== POST-RUN CHECKS ====="

python manage.py check

python manage.py makemigrations \
    --check \
    --dry-run


echo ""
echo "============================================================"
echo "STEP 11D SUCCESS"
echo "============================================================"
