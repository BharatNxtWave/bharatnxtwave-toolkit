import hashlib
import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)


project_root = str(
    Path.cwd()
)

if project_root not in sys.path:
    sys.path.insert(
        0,
        project_root,
    )


import django
django.setup()


from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


BATCH_ID = 5

CONTRACT_PATH = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


# ============================================================
# CONTRACT
# ============================================================

contract_bytes = CONTRACT_PATH.read_bytes()

contract_hash = hashlib.sha256(
    contract_bytes
).hexdigest()

contract = json.loads(
    contract_bytes.decode("utf-8")
)


if contract.get(
    "version"
) != 1:
    raise SystemExit(
        "STOPPED SAFELY: unexpected "
        "mapping contract version."
    )


# ============================================================
# STAGING BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if batch.file_sha256 != EXPECTED_SHA256:
    raise SystemExit(
        "STOPPED SAFELY: staged source "
        "SHA-256 mismatch."
    )


metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if metadata.get(
    "operation"
) != "workbook_staging":
    raise SystemExit(
        "STOPPED SAFELY: unexpected ImportBatch."
    )


rows = list(
    ImportRow.objects
    .filter(
        import_batch=batch
    )
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


# ============================================================
# HELPERS
# ============================================================

def raw_dict(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw_dict(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):

    value = raw_dict(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def payload_signature(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    link = (
        payload.get(
            "hyperlink_target"
        )
        or payload.get(
            "hyperlink_location"
        )
    )

    if link:
        return (
            "LINK:"
            + str(link).strip()
        )

    value = payload_value(
        payload
    )

    if not value:
        return ""

    return (
        str(
            payload.get(
                "cell_type",
                "",
            )
        )
        + ":"
        + value
    )


def populated(payload):

    return bool(
        payload_signature(
            payload
        )
    )


def canonical_status(
    payload
):

    if not populated(
        payload
    ):
        return (
            "UNKNOWN",
            None,
            "BLANK",
        )

    cell_type = payload.get(
        "cell_type"
    )

    value = payload_value(
        payload
    )

    text = value.casefold()


    if cell_type == "d":

        normalized_date = None

        try:

            parsed = datetime.fromisoformat(
                value
            )

            normalized_date = (
                parsed.date().isoformat()
            )

        except ValueError:

            try:

                normalized_date = (
                    date.fromisoformat(
                        value
                    ).isoformat()
                )

            except ValueError:
                normalized_date = None


        return (
            "DATED",
            normalized_date,
            "EXCEL_DATE",
        )


    if re.search(
        r"\brolling\b",
        text,
    ):
        return (
            "ROLLING",
            None,
            "ROLLING_TEXT",
        )


    if re.search(
        r"\b(on\s*going|ongoing)\b",
        text,
    ):
        return (
            "ONGOING",
            None,
            "ONGOING_TEXT",
        )


    if re.search(
        r"\bclosed?\b",
        text,
    ):
        return (
            "CLOSED",
            None,
            "CLOSED_TEXT",
        )


    if re.search(
        r"\bopen\b",
        text,
    ):
        return (
            "OPEN",
            None,
            "OPEN_TEXT",
        )


    if re.search(
        r"\b(no deadline|no last date)\b",
        text,
    ):
        return (
            "NO_DEADLINE",
            None,
            "NO_DEADLINE_TEXT",
        )


    if (
        re.search(
            r"\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}",
            text,
        )
        or re.search(
            r"\b\d{1,2}\s+"
            r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)",
            text,
        )
    ):
        return (
            "OTHER",
            None,
            "DATE_LIKE_TEXT",
        )


    return (
        "OTHER",
        None,
        "OTHER_TEXT",
    )


SERVICE_KIND_KEYWORDS = {
    "REGISTRATION": (
        "registration",
    ),
    "COMPLIANCE": (
        "compliance",
    ),
    "CERTIFICATION": (
        "certification",
        "certificate",
    ),
    "GOVT_SCHEME": (
        "government scheme",
        "govt scheme",
    ),
    "GRANT": (
        "grant",
    ),
    "LOAN": (
        "loan",
    ),
    "DEBT": (
        "debt",
    ),
    "EQUITY": (
        "equity",
    ),
    "VC": (
        "venture capital",
        " vc ",
    ),
    "SUBSIDY": (
        "subsidy",
    ),
    "LEGAL": (
        "legal",
    ),
    "DIGITAL": (
        "digital",
    ),
    "CONSULTING": (
        "consulting",
        "consultancy",
    ),
}


def kind_candidates(
    raw_value
):

    text = (
        " "
        + raw_value.casefold()
        + " "
    )

    matches = set()

    for kind, tokens in (
        SERVICE_KIND_KEYWORDS.items()
    ):

        for token in tokens:

            if token in text:

                matches.add(
                    kind
                )

                break

    return matches


def resolve_service_kind(
    group
):

    raw_types = []

    for row in group:

        payload = fields(row).get(
            "scheme_type",
            {},
        )

        value = payload_value(
            payload
        )

        if value:
            raw_types.append(
                value
            )


    if not raw_types:

        return (
            None,
            "NO_SOURCE_TYPE",
        )


    raw_signatures = {
        value.casefold()
        for value in raw_types
    }


    if len(
        raw_signatures
    ) > 1:

        return (
            None,
            "CONFLICTING_SOURCE_TYPES",
        )


    combined_matches = set()

    for value in raw_types:

        matches = kind_candidates(
            value
        )

        if len(matches) != 1:

            return (
                None,
                (
                    "AMBIGUOUS_TYPE"
                    if len(matches) > 1
                    else "UNRECOGNISED_TYPE"
                ),
            )

        combined_matches.update(
            matches
        )


    if len(
        combined_matches
    ) != 1:

        return (
            None,
            "CONFLICTING_KIND_MAPPING",
        )


    return (
        next(
            iter(
                combined_matches
            )
        ),
        "RESOLVED",
    )


def coordinate_collision(
    row
):

    row_fields = fields(
        row
    )

    deadline = row_fields.get(
        "deadline",
        {},
    )

    funding = row_fields.get(
        "funding_organisation",
        {},
    )

    deadline_coordinate = (
        deadline.get(
            "coordinate"
        )
        if isinstance(
            deadline,
            dict,
        )
        else None
    )

    funding_coordinate = (
        funding.get(
            "coordinate"
        )
        if isinstance(
            funding,
            dict,
        )
        else None
    )

    return bool(
        deadline_coordinate
        and funding_coordinate
        and (
            deadline_coordinate
            == funding_coordinate
        )
    )


def field_variant_count(
    group,
    field_name,
):

    signatures = {
        payload_signature(
            fields(row).get(
                field_name,
                {},
            )
        )
        for row in group
    }

    signatures.discard(
        ""
    )

    return len(
        signatures
    )


def hyperlink_count(
    group,
    field_name,
):

    links = set()

    for row in group:

        payload = fields(row).get(
            field_name,
            {},
        )

        if not isinstance(
            payload,
            dict,
        ):
            continue

        target = (
            payload.get(
                "hyperlink_target"
            )
            or payload.get(
                "hyperlink_location"
            )
        )

        if target:
            links.add(
                str(target).strip()
            )

    return len(
        links
    )


# ============================================================
# STRUCTURED ROWS
# ============================================================

scheme_rows = [
    row
    for row in rows
    if meta(row).get(
        "family"
    ) == "SCHEME_TABLE"
]


if len(
    scheme_rows
) != 113:
    raise SystemExit(
        "STOPPED SAFELY: expected 113 "
        "structured staged rows."
    )


invalid_rows = [
    row
    for row in scheme_rows
    if not row.source_key
]


if len(
    invalid_rows
) != 1:
    raise SystemExit(
        "STOPPED SAFELY: expected exactly "
        "one unnamed structured row."
    )


# ============================================================
# CANONICAL GROUPING
# ============================================================

identity_groups = defaultdict(
    list
)


for row in scheme_rows:

    if row.source_key:

        identity_groups[
            row.source_key
        ].append(
            row
        )


if len(
    identity_groups
) != 100:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 canonical identities."
    )


duplicate_groups = [
    group
    for group in (
        identity_groups.values()
    )
    if len(group) > 1
]


if len(
    duplicate_groups
) != 9:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "9 duplicate groups."
    )


if sum(
    len(group)
    for group in duplicate_groups
) != 21:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "21 duplicate source rows."
    )


# ============================================================
# NORMALIZATION PREVIEW
# ============================================================

candidate_status = Counter()
block_reasons = Counter()
warning_codes = Counter()
kind_resolution = Counter()
resolved_kinds = Counter()
deadline_statuses = Counter()
deadline_source_types = Counter()

candidate_source_row_counts = Counter()

portal_source_counts = Counter()
flyer_source_counts = Counter()

commercial_presence = Counter()

duplicate_conflict_summary = Counter()


for identity, group in (
    identity_groups.items()
):

    blockers = []
    warnings = []


    candidate_source_row_counts[
        len(group)
    ] += 1


    # --------------------------------------------------------
    # Service kind
    # --------------------------------------------------------

    service_kind, kind_result = (
        resolve_service_kind(
            group
        )
    )

    kind_resolution[
        kind_result
    ] += 1


    if service_kind:

        resolved_kinds[
            service_kind
        ] += 1

    else:

        blockers.append(
            "service_kind_"
            + kind_result.casefold()
        )


    # --------------------------------------------------------
    # Duplicate scalar conflicts
    # --------------------------------------------------------

    if len(group) > 1:

        scalar_fields = [
            "benefits",
            "eligibility",
            "deadline",
            "funding_organisation",
            "applicable_for",
            "scheme_type",
        ]

        scalar_conflicts = [
            field_name
            for field_name
            in scalar_fields
            if field_variant_count(
                group,
                field_name,
            ) > 1
        ]


        if scalar_conflicts:

            duplicate_conflict_summary[
                "scalar_conflict"
            ] += 1

            warnings.append(
                "duplicate_scalar_variants"
            )

        else:

            duplicate_conflict_summary[
                "no_scalar_conflict"
            ] += 1


        focus_variants = (
            field_variant_count(
                group,
                "focus_sectors",
            )
        )

        if focus_variants > 1:

            warnings.append(
                "multiple_focus_sector_variants"
            )


        portal_variants = (
            field_variant_count(
                group,
                "portal_link",
            )
        )

        if portal_variants > 1:

            warnings.append(
                "multiple_portal_sources"
            )


    # --------------------------------------------------------
    # Source-coordinate collision
    # --------------------------------------------------------

    if any(
        coordinate_collision(
            row
        )
        for row in group
    ):

        blockers.append(
            "source_coordinate_collision"
        )


    # --------------------------------------------------------
    # Deadline preview
    # --------------------------------------------------------

    deadline_results = []

    for row in group:

        result = canonical_status(
            fields(row).get(
                "deadline",
                {},
            )
        )

        deadline_results.append(
            result
        )


    deadline_categories = {
        result[2]
        for result in deadline_results
    }


    if len(
        deadline_categories
    ) > 1:

        blockers.append(
            "deadline_semantic_conflict"
        )

    else:

        category = next(
            iter(
                deadline_categories
            )
        )

        status = (
            deadline_results[0][0]
        )

        deadline_source_types[
            category
        ] += 1

        deadline_statuses[
            status
        ] += 1


        if category in {
            "DATE_LIKE_TEXT",
            "OTHER_TEXT",
        }:

            warnings.append(
                "deadline_text_not_auto_parsed"
            )


    # --------------------------------------------------------
    # Links
    # --------------------------------------------------------

    portal_count = hyperlink_count(
        group,
        "portal_link",
    )

    flyer_count = hyperlink_count(
        group,
        "flyer",
    )


    portal_source_counts[
        portal_count
    ] += 1

    flyer_source_counts[
        flyer_count
    ] += 1


    # --------------------------------------------------------
    # Commercial source presence
    # --------------------------------------------------------

    has_minimum_charge = any(
        populated(
            fields(row).get(
                "minimum_charge",
                {},
            )
        )
        for row in group
    )

    has_government_charge = any(
        populated(
            fields(row).get(
                "government_charge",
                {},
            )
        )
        for row in group
    )


    if has_minimum_charge:

        commercial_presence[
            "minimum_charge_present"
        ] += 1


    if has_government_charge:

        commercial_presence[
            "government_charge_present"
        ] += 1


    # --------------------------------------------------------
    # Final dry-run status
    # --------------------------------------------------------

    blockers = sorted(
        set(blockers)
    )

    warnings = sorted(
        set(warnings)
    )


    for reason in blockers:

        block_reasons[
            reason
        ] += 1


    for warning in warnings:

        warning_codes[
            warning
        ] += 1


    if blockers:

        candidate_status[
            "REVIEW_REQUIRED"
        ] += 1

    else:

        candidate_status[
            "READY_FOR_IMPORT_PREVIEW"
        ] += 1


# ============================================================
# LIVE DESTINATION SAFETY
# ============================================================

destination_counts = {
    "Service": (
        Service.objects.count()
    ),
    "ImportChange": (
        ImportChange.objects.count()
    ),
    "ServiceClassification": (
        ServiceClassification.objects
        .count()
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects
        .count()
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects
        .count()
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count()
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count()
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count()
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects
        .count()
    ),
}


if destination_counts[
    "Service"
] != 1:
    raise SystemExit(
        "STOPPED SAFELY: live Service count changed."
    )


for name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if destination_counts[
        name
    ] != 0:

        raise SystemExit(
            "STOPPED SAFELY: destination "
            f"{name} unexpectedly contains data."
        )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10a_normalization_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10A NORMALIZATION DRY RUN"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    "Mapping Contract Version: 1"
)

lines.append(
    f"Mapping Contract SHA-256: "
    f"{contract_hash}"
)

lines.append("")

lines.append(
    f"Structured source rows: "
    f"{len(scheme_rows)}"
)

lines.append(
    f"Unnamed rows excluded from "
    f"canonical creation: "
    f"{len(invalid_rows)}"
)

lines.append(
    f"Canonical candidate identities: "
    f"{len(identity_groups)}"
)

lines.append("")


lines.append(
    "1. NORMALIZATION READINESS"
)

for key, value in sorted(
    candidate_status.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


lines.append(
    "2. BLOCKING REASONS"
)

if block_reasons:

    for key, value in sorted(
        block_reasons.items()
    ):

        lines.append(
            f"  {key}: {value}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


lines.append(
    "3. NON-BLOCKING WARNINGS"
)

if warning_codes:

    for key, value in sorted(
        warning_codes.items()
    ):

        lines.append(
            f"  {key}: {value}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


lines.append(
    "4. SERVICE KIND RESOLUTION"
)

for key, value in sorted(
    kind_resolution.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "  RESOLVED MODEL KINDS"
)

if resolved_kinds:

    for key, value in sorted(
        resolved_kinds.items()
    ):

        lines.append(
            f"    {key}: {value}"
        )

else:

    lines.append(
        "    NONE"
    )


lines.append("")


lines.append(
    "5. DEADLINE NORMALIZATION"
)

lines.append(
    "  MODEL STATUS"
)

for key, value in sorted(
    deadline_statuses.items()
):

    lines.append(
        f"    {key}: {value}"
    )


lines.append(
    "  SOURCE TYPE"
)

for key, value in sorted(
    deadline_source_types.items()
):

    lines.append(
        f"    {key}: {value}"
    )


lines.append("")


lines.append(
    "6. CANDIDATE SOURCE ROW COUNTS"
)

for source_rows, count in sorted(
    candidate_source_row_counts.items()
):

    lines.append(
        f"  Candidates backed by "
        f"{source_rows} source row(s): "
        f"{count}"
    )


lines.append("")


lines.append(
    "7. LINK SOURCE COUNTS"
)

for count, candidates in sorted(
    portal_source_counts.items()
):

    lines.append(
        f"  Candidates with "
        f"{count} embedded portal hyperlink(s): "
        f"{candidates}"
    )


for count, candidates in sorted(
    flyer_source_counts.items()
):

    lines.append(
        f"  Candidates with "
        f"{count} embedded flyer hyperlink(s): "
        f"{candidates}"
    )


lines.append("")


lines.append(
    "8. COMMERCIAL SOURCE PRESENCE"
)

for key, value in sorted(
    commercial_presence.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append(
    "  Numeric commercial parsing performed: NO"
)

lines.append(
    "  Commercial data written to Service: NO"
)


lines.append("")


lines.append(
    "9. DUPLICATE NORMALIZATION"
)

for key, value in sorted(
    duplicate_conflict_summary.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


lines.append(
    "10. LIVE DESTINATION SAFETY"
)

for key, value in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "11. WRITE SAFETY"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  ImportRow records changed: 0"
)

lines.append(
    "  ServiceSource records created: 0"
)

lines.append(
    "  ServiceCommercial records created: 0"
)

lines.append(
    "  ServiceContentSection records created: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Confidential source values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10A NORMALIZATION DRY RUN COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
