from pathlib import Path
from hashlib import sha256
from collections import Counter, defaultdict
from datetime import datetime, date
import json
import math
import re
import sys


# ============================================================
# CONFIG
# ============================================================

SOURCE_DIR = Path("confidential_source")
AUDIT_DIR = SOURCE_DIR / "audit"

EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


# ------------------------------------------------------------
# We are NOT guessing these from the data.
# These are based only on the workbook structure already
# established in the previous structural/header audits.
# ------------------------------------------------------------

SCHEME_TABLES = {
    "GRANT",
    "Women_GRANT",
    "Agriculture_FUND",
    "NGO_GRANT",
    "EQUITY",
    "GRANTDEBTEQUITY",
    "DEBTEQUITY",
    "LOAN ONLY",
    "LOANSUBSIDY",
    "CERTGEM",
}


REFERENCE_TABLES = {
    "BENEFITS",
    "AMOUNT DEDUCTIONS",
}


MATRIX_TABLES = {
    "LOAN",
}


MANUAL_REVIEW_SHEETS = {
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
    "ONBOARDING_MAIL",
    "Rolling_Grants",
}


EXPECTED_HEADER_ROWS = {
    "GRANT": 1,
    "Women_GRANT": 1,
    "Agriculture_FUND": 1,
    "NGO_GRANT": 1,
    "EQUITY": 1,
    "GRANTDEBTEQUITY": 1,
    "DEBTEQUITY": 1,
    "LOAN ONLY": 1,
    "LOANSUBSIDY": 1,
    "CERTGEM": 1,
    "BENEFITS": 1,
    "LOAN": 2,
    "AMOUNT DEDUCTIONS": 1,
}


# ============================================================
# LOAD OPENPYXL
# ============================================================

try:
    from openpyxl import load_workbook
    from openpyxl.cell.cell import MergedCell

except ImportError:

    raise SystemExit(
        "STOPPED SAFELY: openpyxl is not installed."
    )


# ============================================================
# FIND SOURCE
# ============================================================

xlsx_files = [
    p
    for p in SOURCE_DIR.glob("*.xlsx")
    if p.is_file()
    and not p.name.startswith("~$")
]


if len(xlsx_files) != 1:

    raise SystemExit(
        "STOPPED SAFELY: expected exactly one XLSX "
        f"in {SOURCE_DIR}. Found {len(xlsx_files)}."
    )


source = xlsx_files[0]


# ============================================================
# VERIFY SHA-256
# ============================================================

digest = sha256()


with source.open("rb") as handle:

    for chunk in iter(
        lambda: handle.read(1024 * 1024),
        b"",
    ):

        digest.update(chunk)


actual_sha256 = digest.hexdigest()


if actual_sha256 != EXPECTED_SHA256:

    raise SystemExit(
        "\n"
        "STOPPED SAFELY\n"
        "============================================================\n"
        "The workbook fingerprint has changed since our first audit.\n"
        "No inspection was performed.\n\n"
        f"Expected:\n{EXPECTED_SHA256}\n\n"
        f"Actual:\n{actual_sha256}\n"
        "============================================================\n"
    )


# ============================================================
# HELPERS
# ============================================================

def clean_text(value):

    if value is None:
        return ""

    text = str(value)

    text = re.sub(
        r"\s+",
        " ",
        text,
    )

    return text.strip()


def normalize(value):

    text = clean_text(value).casefold()

    text = re.sub(
        r"\s+",
        " ",
        text,
    )

    return text.strip()


def normalize_header(value):

    text = normalize(value)

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    text = re.sub(
        r"\s+",
        " ",
        text,
    )

    return text.strip()


def excel_column_letter(number):

    output = ""

    while number:

        number, remainder = divmod(
            number - 1,
            26,
        )

        output = (
            chr(65 + remainder)
            + output
        )

    return output


def value_is_blank(value):

    return clean_text(value) == ""


def classify_value(cell):

    if isinstance(cell, MergedCell):
        return "merged"

    value = cell.value


    if value is None:
        return "blank"


    if cell.data_type == "f":
        return "formula"


    if cell.data_type == "e":
        return "error"


    if isinstance(value, bool):
        return "boolean"


    if isinstance(
        value,
        (datetime, date),
    ):
        return "date"


    if isinstance(value, (int, float)):

        if isinstance(value, float) and math.isnan(value):
            return "blank"

        return "number"


    return "text"


def hash_text(text):

    return sha256(
        text.encode("utf-8")
    ).hexdigest()


def safe_row_hash(values):

    normalized_values = [
        normalize(value)
        for value in values
    ]

    payload = "\x1f".join(
        normalized_values
    )

    return hash_text(payload)


def likely_url(text):

    text = clean_text(text)

    return bool(
        re.match(
            r"^https?://",
            text,
            flags=re.IGNORECASE,
        )
    )


def parse_date_string(value):

    text = clean_text(value)

    if not text:
        return "blank"


    lowered = text.casefold()


    # These are not dates but can be legitimate deadline statuses.
    deadline_status_words = {
        "rolling",
        "ongoing",
        "open",
        "open throughout the year",
        "throughout the year",
        "always open",
        "continuous",
        "no deadline",
        "na",
        "n/a",
        "not applicable",
    }


    if lowered in deadline_status_words:

        return "text_status"


    formats = [
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%d.%m.%Y",
        "%Y-%m-%d",
        "%d/%m/%y",
        "%d-%m-%y",
        "%d %b %Y",
        "%d %B %Y",
        "%b %d %Y",
        "%B %d %Y",
        "%d %b, %Y",
        "%d %B, %Y",
    ]


    for fmt in formats:

        try:

            datetime.strptime(
                text,
                fmt,
            )

            return "valid_date_string"

        except ValueError:

            pass


    return "unparsed_text"


def sheet_classification(sheet_name):

    if sheet_name in SCHEME_TABLES:
        return "SCHEME_TABLE"

    if sheet_name in REFERENCE_TABLES:
        return "REFERENCE_TABLE"

    if sheet_name in MATRIX_TABLES:
        return "COMPARISON_MATRIX"

    return "MANUAL_STRUCTURAL_REVIEW"


# ============================================================
# OPEN WORKBOOK
#
# Important:
# read_only=False is used only because it gives reliable
# dimensions, hyperlink and merged-cell access.
#
# We NEVER call workbook.save().
# Therefore the source workbook is not modified.
# ============================================================

try:

    workbook = load_workbook(
        filename=source,
        read_only=False,
        data_only=False,
        keep_links=True,
    )

except Exception as exc:

    raise SystemExit(
        "STOPPED SAFELY: workbook could not be opened.\n"
        f"{type(exc).__name__}: {exc}"
    )


# ============================================================
# REPORT CONTAINERS
# ============================================================

report = {
    "source_filename": source.name,
    "sha256_verified": True,
    "sha256": actual_sha256,
    "generated_at": datetime.now().isoformat(
        timespec="seconds"
    ),
    "sheet_count": len(workbook.sheetnames),
    "sheets": [],
    "cross_sheet_scheme_duplicates": {
        "unique_duplicate_names": 0,
        "duplicate_occurrences": 0,
        "locations": [],
    },
}


scheme_locations = defaultdict(list)


# ============================================================
# PROCESS EACH SHEET
# ============================================================

for sheet_index, sheet_name in enumerate(
    workbook.sheetnames,
    start=1,
):

    ws = workbook[sheet_name]

    classification = sheet_classification(
        sheet_name
    )


    # ========================================================
    # DISCOVER REAL USED RANGE
    # ========================================================

    first_row = None
    last_row = None
    first_col = None
    last_col = None

    nonempty_cells = 0
    formula_count = 0
    hyperlink_count = 0


    for row in ws.iter_rows():

        for cell in row:

            if isinstance(cell, MergedCell):
                continue


            if value_is_blank(cell.value):
                continue


            nonempty_cells += 1


            if first_row is None:
                first_row = cell.row

            if first_col is None:
                first_col = cell.column


            first_row = min(
                first_row,
                cell.row,
            )

            last_row = max(
                last_row or cell.row,
                cell.row,
            )


            first_col = min(
                first_col,
                cell.column,
            )

            last_col = max(
                last_col or cell.column,
                cell.column,
            )


            if cell.data_type == "f":
                formula_count += 1


            hyperlink = getattr(
                cell,
                "hyperlink",
                None,
            )


            if hyperlink:
                hyperlink_count += 1


    # ========================================================
    # BASE SHEET REPORT
    # ========================================================

    sheet_report = {
        "index": sheet_index,
        "sheet": sheet_name,
        "classification": classification,
        "used_range": {
            "first_row": first_row,
            "last_row": last_row,
            "first_column": (
                excel_column_letter(first_col)
                if first_col
                else None
            ),
            "last_column": (
                excel_column_letter(last_col)
                if last_col
                else None
            ),
        },
        "nonempty_cells": nonempty_cells,
        "formula_count": formula_count,
        "hyperlink_count": hyperlink_count,
        "merged_range_count": len(
            ws.merged_cells.ranges
        ),
        "header_row": None,
        "record_rows": 0,
        "columns": [],
        "quality": {},
    }


    # ========================================================
    # MANUAL STRUCTURE SHEETS
    # ========================================================

    if classification == "MANUAL_STRUCTURAL_REVIEW":

        sheet_report["quality"] = {
            "status": "MANUAL_REVIEW_REQUIRED",
            "reason": (
                "This sheet does not follow the same "
                "row/column scheme-table structure."
            ),
        }


        report["sheets"].append(
            sheet_report
        )

        continue


    # ========================================================
    # KNOWN HEADER ROW
    # ========================================================

    header_row = EXPECTED_HEADER_ROWS.get(
        sheet_name
    )


    if not header_row:

        sheet_report["quality"] = {
            "status": "HEADER_NOT_CONFIRMED"
        }

        report["sheets"].append(
            sheet_report
        )

        continue


    sheet_report["header_row"] = header_row


    # ========================================================
    # BUILD HEADER MAP
    # ========================================================

    headers = {}

    duplicate_header_names = defaultdict(list)


    effective_last_col = (
        last_col
        or ws.max_column
        or 1
    )


    for column_number in range(
        1,
        effective_last_col + 1,
    ):

        cell = ws.cell(
            row=header_row,
            column=column_number,
        )


        header_text = clean_text(
            cell.value
        )


        if not header_text:
            continue


        normalized = normalize_header(
            header_text
        )


        headers[column_number] = {
            "column": excel_column_letter(
                column_number
            ),
            "header": header_text,
            "normalized_header": normalized,
        }


        duplicate_header_names[
            normalized
        ].append(
            excel_column_letter(
                column_number
            )
        )


    duplicate_headers = {
        key: value
        for key, value
        in duplicate_header_names.items()
        if len(value) > 1
    }


    # ========================================================
    # DETERMINE DATA ROWS
    # ========================================================

    data_start_row = header_row + 1

    data_end_row = (
        last_row
        if last_row is not None
        else header_row
    )


    active_rows = []


    for row_number in range(
        data_start_row,
        data_end_row + 1,
    ):

        values = [
            ws.cell(
                row=row_number,
                column=column_number,
            ).value
            for column_number in range(
                1,
                effective_last_col + 1,
            )
        ]


        if any(
            not value_is_blank(value)
            for value in values
        ):

            active_rows.append(
                row_number
            )


    sheet_report["record_rows"] = len(
        active_rows
    )


    # ========================================================
    # COLUMN METRICS
    # ========================================================

    column_metrics = []


    for column_number, header_info in headers.items():

        type_counts = Counter()

        nonblank = 0
        blank = 0

        distinct_hashes = set()

        text_lengths = []

        formula_rows = []

        hyperlink_rows = []

        url_text_rows = []

        suspicious_link_rows = []


        for row_number in active_rows:

            cell = ws.cell(
                row=row_number,
                column=column_number,
            )

            value = cell.value

            value_type = classify_value(
                cell
            )


            type_counts[value_type] += 1


            if value_is_blank(value):

                blank += 1

            else:

                nonblank += 1


                normalized_value = normalize(
                    value
                )


                distinct_hashes.add(
                    hash_text(
                        normalized_value
                    )
                )


                if isinstance(value, str):

                    text_lengths.append(
                        len(value)
                    )


                if cell.data_type == "f":

                    formula_rows.append(
                        row_number
                    )


                hyperlink = getattr(
                    cell,
                    "hyperlink",
                    None,
                )


                if hyperlink:

                    hyperlink_rows.append(
                        row_number
                    )


                    target = (
                        getattr(
                            hyperlink,
                            "target",
                            None,
                        )
                        or getattr(
                            hyperlink,
                            "location",
                            None,
                        )
                        or ""
                    )


                    if (
                        target
                        and not re.match(
                            r"^(https?://|mailto:|#)",
                            str(target),
                            flags=re.IGNORECASE,
                        )
                    ):

                        suspicious_link_rows.append(
                            row_number
                        )


                if isinstance(value, str):

                    if likely_url(value):

                        url_text_rows.append(
                            row_number
                        )


        metric = {
            "column": header_info["column"],
            "header": header_info["header"],
            "populated": nonblank,
            "blank": blank,
            "distinct_nonblank_values": len(
                distinct_hashes
            ),
            "type_counts": dict(
                type_counts
            ),
            "formula_rows": formula_rows,
            "hyperlink_count": len(
                hyperlink_rows
            ),
            "text_url_count": len(
                url_text_rows
            ),
            "suspicious_hyperlink_rows": (
                suspicious_link_rows
            ),
        }


        if text_lengths:

            metric[
                "average_text_length"
            ] = round(
                sum(text_lengths)
                / len(text_lengths),
                1,
            )

            metric[
                "maximum_text_length"
            ] = max(
                text_lengths
            )


        column_metrics.append(
            metric
        )


    sheet_report["columns"] = (
        column_metrics
    )


    # ========================================================
    # FIND IMPORTANT COLUMNS
    # ========================================================

    def find_column(*possible_names):

        normalized_possible = {
            normalize_header(name)
            for name in possible_names
        }


        for column_number, info in headers.items():

            if (
                info["normalized_header"]
                in normalized_possible
            ):

                return column_number


        return None


    scheme_name_col = find_column(
        "Scheme Name",
    )


    serial_col = find_column(
        "Sr. No.",
        "Sr. no.",
        "SL NO",
    )


    benefits_col = find_column(
        "Benefits",
    )


    sector_col = find_column(
        "Focus Sectors",
    )


    eligibility_col = find_column(
        "Eligibility Criteria",
    )


    deadline_col = find_column(
        "Last date",
    )


    organisation_col = find_column(
        "Funding Organisation",
        "Organisation",
    )


    scheme_type_col = find_column(
        "Type of Scheme",
    )


    applicable_col = find_column(
        "Applicable for",
        "Application for",
    )


    portal_col = find_column(
        "Portal Links",
        "Portal Link",
    )


    charge_col = find_column(
        "Min Charge (Upfront)",
    )


    govt_charge_col = find_column(
        "Govt charges (if any)",
        "Govt Registration Charge",
    )


    # ========================================================
    # CRITICAL FIELD BLANKS
    # ========================================================

    blank_critical = {}


    critical_columns = {
        "scheme_name": scheme_name_col,
        "benefits": benefits_col,
        "focus_sectors": sector_col,
        "eligibility": eligibility_col,
        "deadline": deadline_col,
        "organisation": organisation_col,
        "scheme_type": scheme_type_col,
        "applicable_for": applicable_col,
        "portal_link": portal_col,
    }


    for key, column_number in critical_columns.items():

        if column_number is None:
            blank_critical[key] = {
                "column_present": False,
                "blank_count": None,
                "blank_rows": [],
            }

            continue


        blank_rows = []


        for row_number in active_rows:

            if value_is_blank(
                ws.cell(
                    row=row_number,
                    column=column_number,
                ).value
            ):

                blank_rows.append(
                    row_number
                )


        blank_critical[key] = {
            "column_present": True,
            "blank_count": len(
                blank_rows
            ),
            "blank_rows": blank_rows,
        }


    # ========================================================
    # DUPLICATE SCHEME NAMES
    #
    # Actual scheme names are NOT written to the report.
    # We store only hashes + row numbers.
    # ========================================================

    duplicate_scheme_groups = []


    if scheme_name_col:

        name_rows = defaultdict(list)


        for row_number in active_rows:

            value = ws.cell(
                row=row_number,
                column=scheme_name_col,
            ).value


            normalized_name = normalize(
                value
            )


            if not normalized_name:
                continue


            value_hash = hash_text(
                normalized_name
            )


            name_rows[
                value_hash
            ].append(
                row_number
            )


            scheme_locations[
                value_hash
            ].append({
                "sheet": sheet_name,
                "row": row_number,
            })


        for value_hash, rows in name_rows.items():

            if len(rows) > 1:

                duplicate_scheme_groups.append({
                    "hash": value_hash,
                    "rows": rows,
                })


    # ========================================================
    # SERIAL NUMBER DUPLICATES
    # ========================================================

    duplicate_serial_groups = []


    if serial_col:

        serial_rows = defaultdict(list)


        for row_number in active_rows:

            value = ws.cell(
                row=row_number,
                column=serial_col,
            ).value


            normalized_serial = normalize(
                value
            )


            if not normalized_serial:
                continue


            serial_hash = hash_text(
                normalized_serial
            )


            serial_rows[
                serial_hash
            ].append(
                row_number
            )


        for value_hash, rows in serial_rows.items():

            if len(rows) > 1:

                duplicate_serial_groups.append({
                    "hash": value_hash,
                    "rows": rows,
                })


    # ========================================================
    # EXACT DUPLICATE ROWS
    #
    # Values are hashed. Actual contents stay in Excel.
    # ========================================================

    row_hashes = defaultdict(list)


    for row_number in active_rows:

        values = [
            ws.cell(
                row=row_number,
                column=column_number,
            ).value
            for column_number in range(
                1,
                effective_last_col + 1,
            )
        ]


        row_hash = safe_row_hash(
            values
        )


        row_hashes[
            row_hash
        ].append(
            row_number
        )


    exact_duplicate_rows = [
        {
            "hash": row_hash,
            "rows": rows,
        }
        for row_hash, rows in row_hashes.items()
        if len(rows) > 1
    ]


    # ========================================================
    # DEADLINE QUALITY
    # ========================================================

    deadline_quality = None


    if deadline_col:

        deadline_counts = Counter()

        unparsed_rows = []


        for row_number in active_rows:

            cell = ws.cell(
                row=row_number,
                column=deadline_col,
            )


            value = cell.value


            if value_is_blank(value):

                deadline_counts[
                    "blank"
                ] += 1

                continue


            if isinstance(
                value,
                (datetime, date),
            ):

                deadline_counts[
                    "excel_date"
                ] += 1

                continue


            result = parse_date_string(
                value
            )


            deadline_counts[
                result
            ] += 1


            if result == "unparsed_text":

                unparsed_rows.append(
                    row_number
                )


        deadline_quality = {
            "counts": dict(
                deadline_counts
            ),
            "unparsed_rows": unparsed_rows,
        }


    # ========================================================
    # CHARGE / FEE QUALITY
    # ========================================================

    money_columns = []


    for label, column_number in [
        (
            "minimum_upfront_charge",
            charge_col,
        ),
        (
            "government_charge",
            govt_charge_col,
        ),
    ]:

        if column_number is None:
            continue


        counts = Counter()


        for row_number in active_rows:

            cell = ws.cell(
                row=row_number,
                column=column_number,
            )


            value_type = classify_value(
                cell
            )


            counts[
                value_type
            ] += 1


        money_columns.append({
            "field": label,
            "column": excel_column_letter(
                column_number
            ),
            "type_counts": dict(
                counts
            ),
        })


    # ========================================================
    # PORTAL LINK QUALITY
    # ========================================================

    portal_quality = None


    if portal_col:

        with_hyperlink = 0
        visible_url = 0
        populated_without_detectable_url = 0
        blank = 0


        for row_number in active_rows:

            cell = ws.cell(
                row=row_number,
                column=portal_col,
            )


            value = cell.value

            hyperlink = getattr(
                cell,
                "hyperlink",
                None,
            )


            if value_is_blank(value) and not hyperlink:

                blank += 1

                continue


            if hyperlink:

                with_hyperlink += 1

                continue


            if likely_url(value):

                visible_url += 1

                continue


            populated_without_detectable_url += 1


        portal_quality = {
            "hyperlink_cells": (
                with_hyperlink
            ),
            "visible_url_cells": (
                visible_url
            ),
            "populated_without_detectable_url": (
                populated_without_detectable_url
            ),
            "blank": blank,
        }


    # ========================================================
    # FINAL SHEET QUALITY
    # ========================================================

    sheet_report["quality"] = {
        "status": "AUDITED",
        "duplicate_headers": duplicate_headers,
        "blank_critical_fields": blank_critical,
        "duplicate_scheme_groups": (
            duplicate_scheme_groups
        ),
        "duplicate_serial_groups": (
            duplicate_serial_groups
        ),
        "exact_duplicate_row_groups": (
            exact_duplicate_rows
        ),
        "deadline_quality": (
            deadline_quality
        ),
        "money_column_quality": (
            money_columns
        ),
        "portal_link_quality": (
            portal_quality
        ),
    }


    report["sheets"].append(
        sheet_report
    )


# ============================================================
# CROSS-SHEET SCHEME DUPLICATES
# ============================================================

cross_sheet_groups = []


for value_hash, locations in scheme_locations.items():

    sheet_names = {
        item["sheet"]
        for item in locations
    }


    if len(sheet_names) > 1:

        cross_sheet_groups.append({
            "hash": value_hash,
            "locations": locations,
        })


report[
    "cross_sheet_scheme_duplicates"
] = {
    "unique_duplicate_names": len(
        cross_sheet_groups
    ),
    "duplicate_occurrences": sum(
        len(group["locations"])
        for group in cross_sheet_groups
    ),
    "locations": cross_sheet_groups,
}


# ============================================================
# SAVE MACHINE REPORT
# ============================================================

AUDIT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


json_path = (
    AUDIT_DIR
    / "data_quality_audit_private.json"
)


json_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
    ),
    encoding="utf-8",
)


# ============================================================
# CREATE SAFE HUMAN-READABLE SUMMARY
#
# NO SCHEME NAMES
# NO ELIGIBILITY TEXT
# NO CHARGES
# NO URLs
# NO CONFIDENTIAL VALUES
# ============================================================

lines = []


lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — SAFE DATA QUALITY SUMMARY"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    f"Workbook: {source.name}"
)

lines.append(
    "SHA-256 verified: YES"
)

lines.append(
    f"Sheets: {len(workbook.sheetnames)}"
)

lines.append("")

lines.append(
    "CONFIDENTIAL CELL VALUES ARE NOT INCLUDED IN THIS REPORT."
)

lines.append("")


for sheet in report["sheets"]:

    lines.append(
        "-" * 80
    )

    lines.append(
        f"[{sheet['index']}] {sheet['sheet']}"
    )

    lines.append(
        "-" * 80
    )

    lines.append(
        f"Classification: "
        f"{sheet['classification']}"
    )


    used = sheet["used_range"]


    lines.append(
        "Used rows: "
        f"{used['first_row']} - "
        f"{used['last_row']}"
    )

    lines.append(
        "Used columns: "
        f"{used['first_column']} - "
        f"{used['last_column']}"
    )

    lines.append(
        f"Non-empty cells: "
        f"{sheet['nonempty_cells']}"
    )

    lines.append(
        f"Formulas: "
        f"{sheet['formula_count']}"
    )

    lines.append(
        f"Hyperlinks: "
        f"{sheet['hyperlink_count']}"
    )

    lines.append(
        f"Merged ranges: "
        f"{sheet['merged_range_count']}"
    )


    if (
        sheet["classification"]
        == "MANUAL_STRUCTURAL_REVIEW"
    ):

        lines.append(
            "Import status: MANUAL REVIEW REQUIRED"
        )

        lines.append(
            "Reason: this sheet is not a standard "
            "scheme table."
        )

        lines.append("")

        continue


    lines.append(
        f"Header row: "
        f"{sheet['header_row']}"
    )

    lines.append(
        f"Active data rows: "
        f"{sheet['record_rows']}"
    )


    if sheet["columns"]:

        lines.append("")

        lines.append(
            "COLUMN QUALITY"
        )


        for column in sheet["columns"]:

            lines.append(
                f"  {column['column']} | "
                f"{column['header']} | "
                f"filled={column['populated']} | "
                f"blank={column['blank']} | "
                f"unique={column['distinct_nonblank_values']} | "
                f"types={column['type_counts']}"
            )


    quality = sheet["quality"]


    if quality.get(
        "status"
    ) == "AUDITED":

        lines.append("")

        lines.append(
            "CRITICAL FIELD BLANKS"
        )


        for key, item in (
            quality[
                "blank_critical_fields"
            ].items()
        ):

            if not item[
                "column_present"
            ]:

                lines.append(
                    f"  {key}: column not present"
                )

            else:

                lines.append(
                    f"  {key}: "
                    f"{item['blank_count']} blank"
                )


        lines.append("")

        lines.append(
            "DUPLICATES"
        )

        lines.append(
            "  Duplicate scheme-name groups: "
            f"{len(quality['duplicate_scheme_groups'])}"
        )

        lines.append(
            "  Duplicate serial-number groups: "
            f"{len(quality['duplicate_serial_groups'])}"
        )

        lines.append(
            "  Exact duplicate-row groups: "
            f"{len(quality['exact_duplicate_row_groups'])}"
        )


        if quality.get(
            "deadline_quality"
        ):

            lines.append("")

            lines.append(
                "DEADLINE QUALITY"
            )

            lines.append(
                "  "
                + str(
                    quality[
                        "deadline_quality"
                    ]["counts"]
                )
            )


            lines.append(
                "  Unparsed deadline rows: "
                f"{len(quality['deadline_quality']['unparsed_rows'])}"
            )


        if quality.get(
            "portal_link_quality"
        ):

            portal = quality[
                "portal_link_quality"
            ]


            lines.append("")

            lines.append(
                "PORTAL LINK QUALITY"
            )

            lines.append(
                f"  Hyperlink cells: "
                f"{portal['hyperlink_cells']}"
            )

            lines.append(
                f"  Visible URL cells: "
                f"{portal['visible_url_cells']}"
            )

            lines.append(
                "  Populated but no detectable URL: "
                f"{portal['populated_without_detectable_url']}"
            )

            lines.append(
                f"  Blank: "
                f"{portal['blank']}"
            )


        if quality.get(
            "money_column_quality"
        ):

            lines.append("")

            lines.append(
                "CHARGE / FEE FIELD TYPES"
            )


            for money in quality[
                "money_column_quality"
            ]:

                lines.append(
                    f"  {money['field']} "
                    f"({money['column']}): "
                    f"{money['type_counts']}"
                )


    lines.append("")


lines.append(
    "=" * 80
)

lines.append(
    "CROSS-SHEET DUPLICATE CHECK"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Scheme names appearing in more than one "
    "structured scheme sheet: "
    f"{report['cross_sheet_scheme_duplicates']['unique_duplicate_names']}"
)

lines.append(
    "Total occurrences of those duplicated names: "
    f"{report['cross_sheet_scheme_duplicates']['duplicate_occurrences']}"
)

lines.append("")

lines.append(
    "No scheme names are printed above."
)

lines.append("")

lines.append(
    "NO EXCEL CELLS WERE MODIFIED."
)

lines.append(
    "NO DJANGO DATA WAS CREATED, UPDATED OR DELETED."
)

lines.append(
    "NO SOURCE DATA WAS UPLOADED."
)


safe_path = (
    AUDIT_DIR
    / "data_quality_SAFE_TO_SHARE.txt"
)


safe_path.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


# ============================================================
# CLOSE WORKBOOK WITHOUT SAVE
# ============================================================

workbook.close()


# ============================================================
# OUTPUT
# ============================================================

print("")
print("=" * 80)
print("BHARATNXT WAVE — STEP 4 DATA QUALITY AUDIT COMPLETE")
print("=" * 80)

print("")
print(f"Workbook: {source.name}")
print("SHA-256 verified: YES")
print(f"Sheets audited: {len(report['sheets'])}")

print("")

print("Sheet classification:")


for sheet in report["sheets"]:

    print(
        f"  [{sheet['index']:02}] "
        f"{sheet['sheet']:<22} "
        f"{sheet['classification']}"
    )


print("")
print("Cross-sheet duplicate scheme names:")
print(
    "  Unique duplicate names: "
    f"{report['cross_sheet_scheme_duplicates']['unique_duplicate_names']}"
)

print(
    "  Total duplicate occurrences: "
    f"{report['cross_sheet_scheme_duplicates']['duplicate_occurrences']}"
)

print("")

print("SAFE REPORT TO SHARE:")
print(safe_path)

print("")

print("PRIVATE MACHINE REPORT:")
print(json_path)

print("")

print(
    "IMPORTANT:"
)

print(
    "  Paste ONLY data_quality_SAFE_TO_SHARE.txt into ChatGPT."
)

print(
    "  Do NOT paste data_quality_audit_private.json."
)

print("")

print(
    "NO EXCEL CELLS WERE MODIFIED."
)

print(
    "NO DJANGO DATA WAS CHANGED."
)

print(
    "NO SOURCE DATA WAS UPLOADED."
)
