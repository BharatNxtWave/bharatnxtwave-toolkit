import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.importing.transformation import (
    build_core_transformation_plan,
    fields,
    load_verified_context,
    normalize_identity,
    payload_value,
)

from toolkit.importing.supporting_transformation import (
    build_supporting_transformation_plan,
    row_text,
)

from toolkit.models import (
    Category,
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ServiceDomain,
    ServiceSource,
)


# ============================================================
# CONSTANTS
# ============================================================

KNOWLEDGE_SHEETS = (
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
)


# Deliberately conservative.
#
# These aliases identify obvious service-family wording only.
# They are never written to the database.

ALIASES = {

    "START_UP INDIA": (
        "startup india",
        "start up india",
    ),

    "TAX_CERT": (
        "tax certificate",
        "tax certification",
        "tax cert",
    ),

    "SEED FUND": (
        "seed fund",
        "seed funding",
    ),

    "PVT": (
        "private limited",
        "pvt ltd",
        "pvt limited",
    ),

    "LLP": (
        "limited liability partnership",
        "llp",
    ),
}


# ============================================================
# HELPERS
# ============================================================

def anonymous_identity(
    identity,
):
    return (
        "SVC-"
        + hashlib.sha256(
            identity.encode(
                "utf-8"
            )
        ).hexdigest()[
            :10
        ].upper()
    )


def token_set(value):
    return set(
        normalize_identity(
            value
        ).split()
    )


def alias_matches_identity(
    identity,
    alias,
):
    identity_tokens = token_set(
        identity
    )

    alias_tokens = token_set(
        alias
    )

    if not (
        identity_tokens
        and alias_tokens
    ):
        return False

    return alias_tokens.issubset(
        identity_tokens
    )


def containment_evidence(
    identity,
    sheet_rows,
):
    candidate_tokens = token_set(
        identity
    )

    exact = 0

    containment = 0

    earliest = None


    for row in sheet_rows:

        text = row_text(
            row
        )

        normalized = normalize_identity(
            text
        )

        text_tokens = set(
            normalized.split()
        )


        if (
            normalized
            == identity
        ):
            exact += 1


        if (
            candidate_tokens
            and candidate_tokens.issubset(
                text_tokens
            )
        ):

            containment += 1


            if (
                earliest is None
                or row.source_row_number
                < earliest
            ):

                earliest = (
                    row.source_row_number
                )


    return {
        "exact":
            exact,

        "containment":
            containment,

        "earliest":
            earliest,
    }


# ============================================================
# DATABASE SNAPSHOT
# ============================================================

def snapshot():
    return {

        "Service":
            Service.objects.count(),

        "ServiceDomain":
            ServiceDomain.objects.count(),

        "Category":
            Category.objects.count(),

        "ImportRow":
            ImportRow.objects.count(),

        "ImportChange":
            ImportChange.objects.count(),

        "ServiceClassification":
            ServiceClassification.objects.count(),

        "ServiceSource":
            ServiceSource.objects.count(),

        "ServiceCommercial":
            ServiceCommercial.objects.count(),

        "ServiceContentSection":
            ServiceContentSection.objects.count(),

        "ReferenceItem":
            ReferenceItem.objects.count(),

        "ComparisonMatrix":
            ComparisonMatrix.objects.count(),

        "ComparisonEntry":
            ComparisonEntry.objects.count(),

        "CommunicationTemplate":
            CommunicationTemplate.objects.count(),
    }


EXPECTED_DB = {

    "Service": 1,

    "ServiceDomain": 8,

    "Category": 32,

    "ImportRow": 478,

    "ImportChange": 0,

    "ServiceClassification": 0,

    "ServiceSource": 0,

    "ServiceCommercial": 0,

    "ServiceContentSection": 0,

    "ReferenceItem": 0,

    "ComparisonMatrix": 0,

    "ComparisonEntry": 0,

    "CommunicationTemplate": 0,
}


before = snapshot()


if before != EXPECTED_DB:

    raise SystemExit(
        "STOPPED SAFELY: database state "
        "differs from approved pre-import state."
    )


# ============================================================
# LOAD APPROVED PLANS
# ============================================================

(
    contract,
    batch,
    staged_rows,
) = load_verified_context()


core = (
    build_core_transformation_plan()
)


support = (
    build_supporting_transformation_plan(
        core
    )
)


if (
    len(
        support[
            "knowledge"
        ][
            "plans"
        ]
    )
    != 207
):

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "207 knowledge plans."
    )


# ============================================================
# CURRENT ANCHORS
# ============================================================

current_anchors = {
    sheet:
        data[
            "service_identity"
        ]
    for sheet, data
    in support[
        "knowledge"
    ][
        "anchors"
    ].items()
}


if set(
    current_anchors
) != set(
    KNOWLEDGE_SHEETS
):

    raise SystemExit(
        "STOPPED SAFELY: knowledge "
        "sheet anchor set changed."
    )


current_anchor_groups = defaultdict(
    list
)


for sheet, identity in (
    current_anchors.items()
):

    current_anchor_groups[
        identity
    ].append(
        sheet
    )


# ============================================================
# COMMERCIAL SERVICE UNIVERSE
# ============================================================

commercial_identities = {
    identity
    for identity, plan
    in core[
        "services"
    ].items()
    if (
        plan[
            "source_family"
        ]
        == "COMMERCIAL"
    )
}


if len(
    commercial_identities
) != 60:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "60 additional commercial Services."
    )


# ============================================================
# ALIAS + CONTENT EVIDENCE
# ============================================================

sheet_results = {}


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    sheet_rows = [
        row
        for row in staged_rows
        if row.sheet_name
        == sheet_name
    ]


    alias_candidates = []


    for identity in sorted(
        commercial_identities
    ):

        matched_aliases = [
            alias
            for alias in (
                ALIASES[
                    sheet_name
                ]
            )
            if alias_matches_identity(
                identity,
                alias,
            )
        ]


        if matched_aliases:

            alias_candidates.append(
                identity
            )


    evidence = []


    for identity in (
        commercial_identities
    ):

        result = (
            containment_evidence(
                identity,
                sheet_rows,
            )
        )


        evidence.append(
            {
                "identity":
                    identity,

                "exact":
                    result[
                        "exact"
                    ],

                "containment":
                    result[
                        "containment"
                    ],

                "earliest":
                    (
                        result[
                            "earliest"
                        ]
                        if result[
                            "earliest"
                        ]
                        is not None
                        else 999999
                    ),
            }
        )


    evidence.sort(
        key=lambda item: (
            item[
                "exact"
            ],
            item[
                "containment"
            ],
            -item[
                "earliest"
            ],
        ),
        reverse=True,
    )


    top = evidence[
        0
    ]

    runner = evidence[
        1
    ]


    current = (
        current_anchors[
            sheet_name
        ]
    )


    unique_alias = (
        alias_candidates[
            0
        ]
        if len(
            alias_candidates
        )
        == 1
        else None
    )


    sheet_results[
        sheet_name
    ] = {

        "current":
            current,

        "current_id":
            anonymous_identity(
                current
            ),

        "current_shared_by":
            len(
                current_anchor_groups[
                    current
                ]
            ),

        "alias_candidate_count":
            len(
                alias_candidates
            ),

        "unique_alias":
            unique_alias,

        "unique_alias_id":
            (
                anonymous_identity(
                    unique_alias
                )
                if unique_alias
                else None
            ),

        "current_matches_unique_alias":
            (
                unique_alias
                is not None
                and unique_alias
                == current
            ),

        "top_id":
            anonymous_identity(
                top[
                    "identity"
                ]
            ),

        "top_exact":
            top[
                "exact"
            ],

        "top_containment":
            top[
                "containment"
            ],

        "top_earliest":
            (
                None
                if top[
                    "earliest"
                ]
                == 999999
                else top[
                    "earliest"
                ]
            ),

        "runner_id":
            anonymous_identity(
                runner[
                    "identity"
                ]
            ),

        "runner_exact":
            runner[
                "exact"
            ],

        "runner_containment":
            runner[
                "containment"
            ],

        "runner_earliest":
            (
                None
                if runner[
                    "earliest"
                ]
                == 999999
                else runner[
                    "earliest"
                ]
            ),
    }


# ============================================================
# PROPOSED ANCHOR READINESS
# ============================================================

unique_alias_resolved = sum(
    1
    for result in (
        sheet_results.values()
    )
    if result[
        "unique_alias"
    ]
    is not None
)


unique_alias_agrees_current = sum(
    1
    for result in (
        sheet_results.values()
    )
    if result[
        "current_matches_unique_alias"
    ]
)


proposed_alias_identities = {
    result[
        "unique_alias"
    ]
    for result in (
        sheet_results.values()
    )
    if result[
        "unique_alias"
    ]
    is not None
}


all_five_unique_aliases = (
    unique_alias_resolved
    == 5
)


five_distinct_alias_services = (
    all_five_unique_aliases
    and len(
        proposed_alias_identities
    )
    == 5
)


# ============================================================
# CURRENT COLLISION SUMMARY
# ============================================================

shared_anchor_groups = {
    identity:
        sheets
    for identity, sheets
    in current_anchor_groups.items()
    if len(sheets) > 1
}


# ============================================================
# UNRESOLVED SOURCE PRESERVATION CHECK
# ============================================================

unresolved_link_rows = []


structured_row_ids = {
    row_id
    for plan in (
        core[
            "services"
        ].values()
    )
    if (
        plan[
            "source_family"
        ]
        == "STRUCTURED"
    )
    for row_id in (
        plan[
            "source_row_ids"
        ]
    )
}


for row in staged_rows:

    if row.id not in (
        structured_row_ids
    ):
        continue


    for field_name in (
        "portal_link",
        "flyer",
    ):

        payload = fields(
            row
        ).get(
            field_name,
            {},
        )


        value = payload_value(
            payload
        )


        if not value:
            continue


        has_http = bool(
            re.search(
                r"https?://",
                value,
                flags=re.I,
            )
            or payload.get(
                "hyperlink_target"
            )
            or payload.get(
                "hyperlink_location"
            )
        )


        if not has_http:

            unresolved_link_rows.append(
                (
                    row.id,
                    field_name,
                )
            )


# ============================================================
# DATABASE UNCHANGED
# ============================================================

after = snapshot()


if after != before:

    raise SystemExit(
        "STOPPED SAFELY: anchor integrity "
        "audit changed database counts."
    )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step11c_knowledge_anchor_integrity_SAFE_TO_SHARE.txt"
)


lines = [

    "=" * 80,

    (
        "BHARATNXT WAVE — "
        "STEP 11C KNOWLEDGE ANCHOR INTEGRITY"
    ),

    "=" * 80,

    "",

    (
        f"Mapping Contract version: "
        f"{contract['contract']['version']}"
    ),

    (
        f"Import Batch ID: "
        f"{batch.id}"
    ),

    (
        f"Knowledge documents: "
        f"{len(KNOWLEDGE_SHEETS)}"
    ),

    (
        f"Current distinct Service anchors: "
        f"{len(current_anchor_groups)}"
    ),

    (
        f"Current shared-anchor groups: "
        f"{len(shared_anchor_groups)}"
    ),

    "Database writes performed: NO",

    "",

    "1. CURRENT ANCHOR MAP",
]


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    result = (
        sheet_results[
            sheet_name
        ]
    )


    lines.append(
        f"  {sheet_name}: "
        f"{result['current_id']} | "
        f"shared_by="
        f"{result['current_shared_by']}"
    )


lines.extend(
    [
        "",
        "2. SHARED CURRENT ANCHORS",
    ]
)


if shared_anchor_groups:

    for identity, sheets in sorted(
        shared_anchor_groups.items(),
        key=lambda item: (
            anonymous_identity(
                item[0]
            )
        ),
    ):

        lines.append(
            f"  {anonymous_identity(identity)}: "
            + ", ".join(
                sorted(
                    sheets
                )
            )
        )

else:

    lines.append(
        "  NONE"
    )


lines.extend(
    [
        "",
        "3. SHEET-SPECIFIC ALIAS EVIDENCE",
    ]
)


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    result = (
        sheet_results[
            sheet_name
        ]
    )


    lines.append(
        f"  {sheet_name}"
    )

    lines.append(
        f"    alias_candidate_count: "
        f"{result['alias_candidate_count']}"
    )

    lines.append(
        f"    unique_alias_candidate: "
        f"{result['unique_alias_id'] or 'NONE'}"
    )

    lines.append(
        f"    agrees_with_current_anchor: "
        + (
            "YES"
            if result[
                "current_matches_unique_alias"
            ]
            else "NO"
        )
    )


lines.extend(
    [
        "",
        "4. CONTENT-EVIDENCE LEADERS",
    ]
)


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    result = (
        sheet_results[
            sheet_name
        ]
    )


    lines.append(
        f"  {sheet_name}"
    )

    lines.append(
        f"    top: "
        f"{result['top_id']} | "
        f"exact="
        f"{result['top_exact']} | "
        f"containment="
        f"{result['top_containment']} | "
        f"earliest="
        f"{result['top_earliest'] or 'NONE'}"
    )

    lines.append(
        f"    runner: "
        f"{result['runner_id']} | "
        f"exact="
        f"{result['runner_exact']} | "
        f"containment="
        f"{result['runner_containment']} | "
        f"earliest="
        f"{result['runner_earliest'] or 'NONE'}"
    )


lines.extend(
    [
        "",
        "5. DETERMINISTIC ALIAS READINESS",
        (
            f"  Sheets with exactly one "
            f"alias-matched commercial Service: "
            f"{unique_alias_resolved}"
        ),
        (
            f"  Unique alias matches agreeing "
            f"with current anchor: "
            f"{unique_alias_agrees_current}"
        ),
        (
            "  All five sheets uniquely "
            "resolved by aliases: "
            + (
                "YES"
                if all_five_unique_aliases
                else "NO"
            )
        ),
        (
            "  Those five aliases resolve "
            "to five distinct Services: "
            + (
                "YES"
                if five_distinct_alias_services
                else "NO"
            )
        ),
        "",
        "6. UNRESOLVED LINK PRESERVATION",
        (
            "  Portal/flyer source fields "
            "without verified link evidence: "
            f"{len(unresolved_link_rows)}"
        ),
        (
            "  Still preserved in ImportRow: "
            "YES"
        ),
        (
            "  Automatically discarded: NO"
        ),
        "",
        "7. DATABASE SAFETY",
    ]
)


for key, value in (
    after.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "8. CONFIDENTIALITY",
        "  Service names printed: NO",
        "  Commercial labels printed: NO",
        "  Knowledge content printed: NO",
        "  URLs printed: NO",
        "  Commercial amounts printed: NO",
        "",
        "9. WRITE-GATE RESULT",
    ]
)


if five_distinct_alias_services:

    lines.append(
        (
            "  KNOWLEDGE ANCHOR CORRECTION "
            "CAN BE MADE DETERMINISTICALLY"
        )
    )

else:

    lines.append(
        (
            "  KNOWLEDGE ANCHORS REQUIRE "
            "TARGETED RESOLUTION BEFORE IMPORT"
        )
    )


lines.append(
    "  LIVE DATABASE IMPORT: BLOCKED"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 11C KNOWLEDGE ANCHOR AUDIT COMPLETE"
)

print(
    f"Current distinct anchors: "
    f"{len(current_anchor_groups)}"
)

print(
    f"Unique alias-resolved sheets: "
    f"{unique_alias_resolved}"
)

print(
    f"Five distinct alias anchors: "
    + (
        "YES"
        if five_distinct_alias_services
        else "NO"
    )
)

print(
    f"SAFE REPORT: {output}"
)
