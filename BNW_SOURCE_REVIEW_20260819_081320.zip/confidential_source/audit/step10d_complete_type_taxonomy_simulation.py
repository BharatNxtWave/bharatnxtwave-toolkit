import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

PROJECT_ROOT = Path.cwd()

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(PROJECT_ROOT),
    )


import django
django.setup()


from toolkit.models import (
    Category,
    ImportBatch,
    ImportRow,
    Service,
    ImportChange,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ReferenceItem,
    ComparisonMatrix,
    ComparisonEntry,
    CommunicationTemplate,
)


# ============================================================
# CONSTANTS
# ============================================================

BATCH_ID = 5

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

CONTRACT_V1_PATH = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_V1_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)


# ============================================================
# VERIFY CONTRACT V1
# ============================================================

actual_contract_hash = hashlib.sha256(
    CONTRACT_V1_PATH.read_bytes()
).hexdigest()


if (
    actual_contract_hash
    != EXPECTED_CONTRACT_V1_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 has changed."
    )


# ============================================================
# VERIFY BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if (
    batch.file_sha256
    != EXPECTED_SOURCE_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: source SHA-256 mismatch."
    )


metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if (
    metadata.get("operation")
    != "workbook_staging"
):
    raise SystemExit(
        "STOPPED SAFELY: ImportBatch #5 "
        "is not workbook staging."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
)


# ============================================================
# MODEL SERVICE-KIND CHOICES
# ============================================================

service_kind_field = (
    Service._meta.get_field(
        "service_kind"
    )
)

model_kind_values = {
    str(value)
    for value, label
    in service_kind_field.choices
}


required_kinds = {
    "GRANT",
    "LOAN",
    "EQUITY",
    "CERTIFICATION",
    "GOVT_SCHEME",
}


missing_required_kinds = (
    required_kinds
    - model_kind_values
)


if missing_required_kinds:

    raise SystemExit(
        "STOPPED SAFELY: model is missing "
        "required service_kind choices: "
        + ", ".join(
            sorted(
                missing_required_kinds
            )
        )
    )


# ============================================================
# HELPERS
# ============================================================

def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):

    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def coordinate_collision(row):

    row_fields = fields(
        row
    )

    deadline = row_fields.get(
        "deadline",
        {},
    )

    funding = row_fields.get(
        "funding_organisation",
        {},
    )

    if not isinstance(
        deadline,
        dict,
    ):
        return False

    if not isinstance(
        funding,
        dict,
    ):
        return False

    deadline_coord = (
        deadline.get(
            "coordinate"
        )
    )

    funding_coord = (
        funding.get(
            "coordinate"
        )
    )

    return bool(
        deadline_coord
        and funding_coord
        and (
            deadline_coord
            == funding_coord
        )
    )


# ============================================================
# SOURCE TYPE KEYWORDS
# ============================================================

SOURCE_TYPE_KEYWORDS = {

    "GRANT": (
        "grant",
    ),

    "LOAN": (
        "loan",
    ),

    "DEBT": (
        "debt",
    ),

    "EQUITY": (
        "equity",
    ),

    "SUBSIDY": (
        "subsidy",
    ),

    "CERTIFICATION": (
        "certificate",
        "certification",
    ),

    "GOVT_SCHEME": (
        "government scheme",
        "govt scheme",
    ),

    "REGISTRATION": (
        "registration",
    ),

    "COMPLIANCE": (
        "compliance",
    ),

    "LEGAL": (
        "legal",
    ),

    "CONSULTING": (
        "consulting",
        "consultancy",
    ),

    "DIGITAL": (
        "digital",
    ),
}


def source_type_signals(
    text
):

    padded = (
        " "
        + text.casefold()
        + " "
    )

    matches = set()

    for kind, keywords in (
        SOURCE_TYPE_KEYWORDS.items()
    ):

        for keyword in keywords:

            if keyword in padded:

                matches.add(
                    kind
                )

                break

    return matches


# ============================================================
# SHEET TAXONOMY
# ============================================================

SHEET_CLASSIFICATIONS = {

    "GRANT": {
        "Grant",
    },

    "Women_GRANT": {
        "Grant",
        "Women",
    },

    "Agriculture_FUND": {
        "Agriculture",
        "Funding",
    },

    "NGO_GRANT": {
        "Grant",
        "NGO",
    },

    "EQUITY": {
        "Equity",
    },

    "GRANTDEBTEQUITY": {
        "Grant",
        "Debt",
        "Equity",
        "Mixed Finance",
    },

    "DEBTEQUITY": {
        "Debt",
        "Equity",
        "Mixed Finance",
    },

    "LOAN ONLY": {
        "Loan",
    },

    "LOANSUBSIDY": {
        "Loan",
        "Subsidy",
        "Mixed Finance",
    },

    "CERTGEM": {
        "Certification",
    },
}


# Safe primary fallback.
#
# Composite source families deliberately become GOVT_SCHEME.
# We do not pretend they are exclusively Grant/Loan/etc.

SHEET_PRIMARY_KIND = {

    "GRANT":
        "GRANT",

    "Women_GRANT":
        "GRANT",

    "Agriculture_FUND":
        "GOVT_SCHEME",

    "NGO_GRANT":
        "GRANT",

    "EQUITY":
        "EQUITY",

    "GRANTDEBTEQUITY":
        "GOVT_SCHEME",

    "DEBTEQUITY":
        "GOVT_SCHEME",

    "LOAN ONLY":
        "LOAN",

    "LOANSUBSIDY":
        "GOVT_SCHEME",

    "CERTGEM":
        "CERTIFICATION",
}


# ============================================================
# STRUCTURED GROUPS
# ============================================================

scheme_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
    )
]


if len(scheme_rows) != 113:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "113 structured rows."
    )


unnamed_rows = [
    row
    for row in scheme_rows
    if not row.source_key
]


if len(unnamed_rows) != 1:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "exactly one unnamed row."
    )


groups = defaultdict(
    list
)


for row in scheme_rows:

    if row.source_key:

        groups[
            row.source_key
        ].append(
            row
        )


if len(groups) != 100:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 canonical identities."
    )


# ============================================================
# COMPLETE TYPE RESOLUTION
# ============================================================

primary_kind_counts = Counter()

resolution_method_counts = Counter()

classification_counts = Counter()

classification_combo_counts = Counter()

field_review_counts = Counter()

candidate_readiness = Counter()

candidate_source_counts = Counter()

source_signal_shapes = Counter()

sheet_combination_counts = Counter()

unresolved_primary_kind = 0


for identity, group in (
    groups.items()
):

    sheets = sorted(
        {
            row.sheet_name
            for row in group
        }
    )


    sheet_label = (
        " + ".join(sheets)
    )

    sheet_combination_counts[
        sheet_label
    ] += 1


    candidate_source_counts[
        len(group)
    ] += 1


    # --------------------------------------------------------
    # TAXONOMY UNION
    # --------------------------------------------------------

    classifications = set()

    for sheet in sheets:

        classifications.update(
            SHEET_CLASSIFICATIONS.get(
                sheet,
                set(),
            )
        )


    # --------------------------------------------------------
    # SOURCE-TYPE SIGNALS
    # --------------------------------------------------------

    source_type_values = []

    source_kind_signal_sets = []


    for row in group:

        value = payload_value(
            fields(row).get(
                "scheme_type",
                {},
            )
        )

        if not value:
            continue


        source_type_values.append(
            value
        )


        source_kind_signal_sets.append(
            source_type_signals(
                value
            )
        )


    all_signals = set()

    for signal_set in (
        source_kind_signal_sets
    ):
        all_signals.update(
            signal_set
        )


    source_signal_shapes[
        len(all_signals)
    ] += 1


    # Convert valid signals into taxonomy.
    if "GRANT" in all_signals:
        classifications.add(
            "Grant"
        )

    if "LOAN" in all_signals:
        classifications.add(
            "Loan"
        )

    if "DEBT" in all_signals:
        classifications.add(
            "Debt"
        )

    if "EQUITY" in all_signals:
        classifications.add(
            "Equity"
        )

    if "SUBSIDY" in all_signals:
        classifications.add(
            "Subsidy"
        )

    if "CERTIFICATION" in all_signals:
        classifications.add(
            "Certification"
        )


    # --------------------------------------------------------
    # PRIMARY KIND RESOLUTION
    # --------------------------------------------------------

    sheet_primary_kinds = {
        SHEET_PRIMARY_KIND[
            sheet
        ]
        for sheet in sheets
        if sheet in SHEET_PRIMARY_KIND
    }


    source_type_normalized = {
        value.casefold()
        for value in source_type_values
    }


    # Case 1:
    # Exact one source semantic signal.
    #
    # Only use the source signal if it corresponds to a
    # valid Service.service_kind choice.

    valid_source_primary = {
        signal
        for signal in all_signals
        if signal in model_kind_values
    }


    if (
        len(valid_source_primary) == 1
        and len(source_type_normalized) <= 1
    ):

        primary_kind = next(
            iter(
                valid_source_primary
            )
        )

        resolution_method = (
            "SOURCE_TYPE_SINGLE_SIGNAL"
        )


    # Case 2:
    # All source sheets agree on the same safe primary kind.

    elif (
        len(sheet_primary_kinds)
        == 1
    ):

        primary_kind = next(
            iter(
                sheet_primary_kinds
            )
        )

        resolution_method = (
            "UNANIMOUS_SHEET_FALLBACK"
        )


    # Case 3:
    # Different families or genuinely mixed source meaning.
    #
    # GOVT_SCHEME is used as the broad parent kind,
    # while classifications retain the components.

    elif sheet_primary_kinds:

        primary_kind = (
            "GOVT_SCHEME"
        )

        resolution_method = (
            "MIXED_FAMILY_GOVT_SCHEME"
        )


    else:

        primary_kind = None

        resolution_method = (
            "UNRESOLVED"
        )


    if primary_kind:

        primary_kind_counts[
            primary_kind
        ] += 1

    else:

        unresolved_primary_kind += 1


    resolution_method_counts[
        resolution_method
    ] += 1


    # --------------------------------------------------------
    # FIELD-LEVEL REVIEW
    # --------------------------------------------------------

    field_reviews = set()


    if any(
        coordinate_collision(row)
        for row in group
    ):

        field_reviews.add(
            "funding_organisation_coordinate_collision"
        )


    # Duplicate source types can still exist even when
    # primary kind is safely represented by GOVT_SCHEME.
    # Preserve that conflict for admin review.

    if len(
        source_type_normalized
    ) > 1:

        field_reviews.add(
            "multiple_source_type_variants"
        )


    # Multiple portal URLs are acceptable, not a blocker.
    portal_links = set()

    for row in group:

        payload = fields(row).get(
            "portal_link",
            {},
        )

        if not isinstance(
            payload,
            dict,
        ):
            continue

        link = (
            payload.get(
                "hyperlink_target"
            )
            or payload.get(
                "hyperlink_location"
            )
        )

        if link:
            portal_links.add(
                str(link).strip()
            )


    if len(
        portal_links
    ) > 1:

        field_reviews.add(
            "multiple_portal_sources"
        )


    for review in field_reviews:

        field_review_counts[
            review
        ] += 1


    # --------------------------------------------------------
    # FINAL SIMULATION READINESS
    # --------------------------------------------------------

    if not primary_kind:

        candidate_readiness[
            "PRIMARY_KIND_UNRESOLVED"
        ] += 1

    elif field_reviews:

        candidate_readiness[
            "TYPE_RESOLVED_FIELD_REVIEW"
        ] += 1

    else:

        candidate_readiness[
            "TYPE_AND_TAXONOMY_RESOLVED"
        ] += 1


    # --------------------------------------------------------
    # CLASSIFICATION COUNTS
    # --------------------------------------------------------

    for classification in (
        classifications
    ):

        classification_counts[
            classification
        ] += 1


    combination = tuple(
        sorted(
            classifications
        )
    )

    classification_combo_counts[
        combination
    ] += 1


# ============================================================
# EXISTING CATEGORY COVERAGE
# ============================================================

existing_category_names = {
    str(name).strip().casefold()
    for name in (
        Category.objects
        .values_list(
            "name",
            flat=True,
        )
    )
    if str(name).strip()
}


proposed_category_names = {
    name
    for name in (
        classification_counts.keys()
    )
}


existing_matches = sorted(
    name
    for name in (
        proposed_category_names
    )
    if name.casefold()
    in existing_category_names
)


missing_category_names = sorted(
    name
    for name in (
        proposed_category_names
    )
    if name.casefold()
    not in existing_category_names
)


# ============================================================
# LIVE TABLE SAFETY
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if (
    destination_counts["Service"]
    != 1
):

    raise SystemExit(
        "STOPPED SAFELY: live "
        "Service count changed."
    )


for name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if destination_counts[
        name
    ] != 0:

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} unexpectedly "
            "contains data."
        )


# ============================================================
# HARD EXPECTATION
# ============================================================

if unresolved_primary_kind:

    result_label = (
        "INCOMPLETE"
    )

else:

    result_label = (
        "ALL_100_PRIMARY_KINDS_RESOLVED"
    )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10d_complete_type_taxonomy_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10D COMPLETE TYPE / TAXONOMY SIMULATION"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    f"Structured source rows: "
    f"{len(scheme_rows)}"
)

lines.append(
    f"Unnamed structured rows retained "
    f"for review: {len(unnamed_rows)}"
)

lines.append(
    f"Canonical identities simulated: "
    f"{len(groups)}"
)

lines.append(
    f"Resolution result: "
    f"{result_label}"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. PRIMARY SERVICE KIND RESULT"
)
# ------------------------------------------------------------

for key, count in sorted(
    primary_kind_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append(
    f"  UNRESOLVED: "
    f"{unresolved_primary_kind}"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. RESOLUTION METHOD"
)
# ------------------------------------------------------------

for key, count in sorted(
    resolution_method_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. TYPE / TAXONOMY READINESS"
)
# ------------------------------------------------------------

for key, count in sorted(
    candidate_readiness.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. FIELD-LEVEL REVIEW FLAGS"
)
# ------------------------------------------------------------

if field_review_counts:

    for key, count in sorted(
        field_review_counts.items()
    ):

        lines.append(
            f"  {key}: {count}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. PROPOSED CLASSIFICATION COUNTS"
)
# ------------------------------------------------------------

for key, count in sorted(
    classification_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. CLASSIFICATION COMBINATIONS"
)
# ------------------------------------------------------------

for combination, count in sorted(
    classification_combo_counts.items(),
    key=lambda item:
        (
            -item[1],
            item[0],
        ),
):

    label = (
        " + ".join(
            combination
        )
        if combination
        else "NONE"
    )

    lines.append(
        f"  {label}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. CATEGORY MODEL COVERAGE"
)
# ------------------------------------------------------------

lines.append(
    f"  Existing Category records: "
    f"{Category.objects.count()}"
)

lines.append(
    f"  Proposed taxonomy labels: "
    f"{len(proposed_category_names)}"
)

lines.append(
    f"  Labels already represented: "
    f"{len(existing_matches)}"
)

lines.append(
    f"  Labels requiring later mapping/"
    f"creation decision: "
    f"{len(missing_category_names)}"
)

if missing_category_names:

    lines.append(
        "  Missing proposed labels:"
    )

    for name in (
        missing_category_names
    ):

        lines.append(
            f"    {name}"
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. CANDIDATE SOURCE ROW STRUCTURE"
)
# ------------------------------------------------------------

for source_count, count in sorted(
    candidate_source_counts.items()
):

    lines.append(
        f"  {source_count} source row(s): "
        f"{count} candidates"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "9. SOURCE-TYPE SIGNAL COMPLEXITY"
)
# ------------------------------------------------------------

for signal_count, count in sorted(
    source_signal_shapes.items()
):

    lines.append(
        f"  Candidates with "
        f"{signal_count} recognized source-type "
        f"signal(s): {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "10. LIVE DESTINATION SAFETY"
)
# ------------------------------------------------------------

for key, count in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "11. WRITE SAFETY"
)
# ------------------------------------------------------------

lines.append(
    "  Mapping Contract v1 modified: NO"
)

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Category records created: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Scheme names printed: NO"
)

lines.append(
    "  Source type values printed: NO"
)

lines.append(
    "  Confidential cell values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10D SIMULATION COMPLETE"
)

print(
    f"Resolution result: "
    f"{result_label}"
)

print(
    f"SAFE REPORT: {output}"
)
