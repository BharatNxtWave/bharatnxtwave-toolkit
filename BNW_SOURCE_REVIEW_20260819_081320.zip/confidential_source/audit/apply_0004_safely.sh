#!/usr/bin/env bash
set -euo pipefail

cd "/mnt/d/BharatNXT Wave/BharatNXTwave Toolkit"
source .venv/bin/activate

MIGRATION_NAME="0004_workbook_import_architecture_v1"
MIGRATION_FILE="toolkit/migrations/${MIGRATION_NAME}.py"

echo ""
echo "================================================================"
echo "STEP 8E — SAFE DATABASE MIGRATION"
echo "================================================================"


# ============================================================
# 1. MIGRATION MUST EXIST AND MUST STILL BE UNAPPLIED
# ============================================================

echo ""
echo "===== 1. MIGRATION STATE GATE ====="

test -f "$MIGRATION_FILE"

if python manage.py showmigrations toolkit \
    | grep -Fq "[ ] ${MIGRATION_NAME}"; then

    echo "PASS: 0004 exists and is currently UNAPPLIED."

else

    echo "STOPPED SAFELY:"
    echo "0004 is not in the expected unapplied state."
    exit 1
fi


# ============================================================
# 2. CORRECTED SEMANTIC AUDIT WITH DJANGO INITIALISED
# ============================================================

echo ""
echo "===== 2. CORRECTED SEMANTIC MIGRATION AUDIT ====="

python - <<'PY'
import os
import sys
import importlib.util
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

project_root = str(Path.cwd())

if project_root not in sys.path:
    sys.path.insert(0, project_root)

import django
django.setup()


path = Path(
    "toolkit/migrations/"
    "0004_workbook_import_architecture_v1.py"
)

spec = importlib.util.spec_from_file_location(
    "toolkit_migration_0004_audit",
    path,
)

module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


print("Dependencies:")

for dependency in module.Migration.dependencies:
    print("  ", dependency)


allowed = {
    "CreateModel",
    "AddField",
    "AlterField",
    "AddIndex",
    "AddConstraint",
}

forbidden = {
    "RemoveField",
    "DeleteModel",
    "RenameField",
    "RenameModel",
    "RunPython",
    "RunSQL",
}


print("")
print("Operations:")

unexpected = []

for number, operation in enumerate(
    module.Migration.operations,
    start=1,
):
    name = operation.__class__.__name__

    print(
        f"  {number:02}. {name}"
    )

    if name in forbidden:
        raise SystemExit(
            "STOPPED SAFELY: forbidden operation "
            f"detected: {name}"
        )

    if name not in allowed:
        unexpected.append(name)


if unexpected:
    raise SystemExit(
        "STOPPED SAFELY: unexpected operations: "
        + ", ".join(sorted(set(unexpected)))
    )


print("")
print(
    "PASS: migration contains only approved schema operations."
)
print(
    "PASS: no RunPython or RunSQL data migration."
)
PY


# ============================================================
# 3. IDENTIFY SQLITE DATABASE
# ============================================================

echo ""
echo "===== 3. DATABASE IDENTIFICATION ====="

DB_ENGINE=$(
python - <<'PY'
import os

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

import django
django.setup()

from django.conf import settings

print(
    settings.DATABASES["default"]["ENGINE"]
)
PY
)


DB_PATH=$(
python - <<'PY'
import os
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

import django
django.setup()

from django.conf import settings

print(
    Path(
        settings.DATABASES["default"]["NAME"]
    ).resolve()
)
PY
)


echo "Database engine: $DB_ENGINE"
echo "Database path:   $DB_PATH"


if [ "$DB_ENGINE" != "django.db.backends.sqlite3" ]; then
    echo "STOPPED SAFELY:"
    echo "Expected development SQLite database."
    exit 1
fi


if [ ! -f "$DB_PATH" ]; then
    echo "STOPPED SAFELY:"
    echo "SQLite database file not found."
    exit 1
fi


# ============================================================
# 4. PRE-MIGRATION DATABASE INTEGRITY
# ============================================================

echo ""
echo "===== 4. PRE-MIGRATION SQLITE INTEGRITY ====="

DB_PATH="$DB_PATH" python - <<'PY'
import os
import sqlite3

path = os.environ["DB_PATH"]

connection = sqlite3.connect(path)

integrity = connection.execute(
    "PRAGMA integrity_check"
).fetchone()[0]

foreign_keys = connection.execute(
    "PRAGMA foreign_key_check"
).fetchall()

connection.close()

print(
    "integrity_check:",
    integrity,
)

print(
    "foreign_key_violations:",
    len(foreign_keys),
)

if integrity != "ok":
    raise SystemExit(
        "STOPPED SAFELY: SQLite integrity check failed."
    )

if foreign_keys:
    raise SystemExit(
        "STOPPED SAFELY: existing foreign-key "
        "violations detected."
    )

print(
    "PASS: pre-migration database integrity is clean."
)
PY


# ============================================================
# 5. SAVE PRE-MIGRATION TOOLKIT TABLE COUNTS
# ============================================================

echo ""
echo "===== 5. PRE-MIGRATION TOOLKIT COUNTS ====="

DB_PATH="$DB_PATH" python - <<'PY'
import json
import os
import sqlite3
from pathlib import Path

db = os.environ["DB_PATH"]

connection = sqlite3.connect(db)

tables = [
    row[0]
    for row in connection.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type='table'
          AND name LIKE 'toolkit_%'
        ORDER BY name
        """
    ).fetchall()
]

counts = {}

for table in tables:
    safe = table.replace('"', '""')

    count = connection.execute(
        f'SELECT COUNT(*) FROM "{safe}"'
    ).fetchone()[0]

    counts[table] = count

connection.close()


output = Path(
    "confidential_source/audit/"
    "pre_0004_toolkit_counts.json"
)

output.write_text(
    json.dumps(
        counts,
        indent=2,
        sort_keys=True,
    ),
    encoding="utf-8",
)


for table, count in counts.items():
    print(
        f"{table}: {count}"
    )


print("")
print(
    f"Saved: {output}"
)
PY


# ============================================================
# 6. CREATE VERIFIED SQLITE BACKUP
# ============================================================

echo ""
echo "===== 6. VERIFIED SQLITE BACKUP ====="

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

BACKUP_DIR="confidential_source/audit/db_backups"
mkdir -p "$BACKUP_DIR"

BACKUP_PATH="$BACKUP_DIR/db_before_0004_${TIMESTAMP}.sqlite3"


DB_PATH="$DB_PATH" BACKUP_PATH="$BACKUP_PATH" python - <<'PY'
import os
import sqlite3
import hashlib
from pathlib import Path

source_path = Path(
    os.environ["DB_PATH"]
)

backup_path = Path(
    os.environ["BACKUP_PATH"]
)


source = sqlite3.connect(
    str(source_path)
)

destination = sqlite3.connect(
    str(backup_path)
)

source.backup(destination)

destination.commit()


integrity = destination.execute(
    "PRAGMA integrity_check"
).fetchone()[0]

foreign_keys = destination.execute(
    "PRAGMA foreign_key_check"
).fetchall()


destination.close()
source.close()


if integrity != "ok":
    backup_path.unlink(
        missing_ok=True
    )

    raise SystemExit(
        "STOPPED SAFELY: backup integrity check failed."
    )


if foreign_keys:
    backup_path.unlink(
        missing_ok=True
    )

    raise SystemExit(
        "STOPPED SAFELY: backup contains "
        "foreign-key violations."
    )


digest = hashlib.sha256()

with backup_path.open("rb") as file:
    for chunk in iter(
        lambda: file.read(1024 * 1024),
        b"",
    ):
        digest.update(chunk)


print(
    f"Backup created: {backup_path}"
)

print(
    f"Backup size: {backup_path.stat().st_size} bytes"
)

print(
    f"Backup SHA-256: {digest.hexdigest()}"
)

print(
    "Backup integrity_check: ok"
)

print(
    "Backup foreign_key_check: 0 violations"
)
PY


chmod 600 "$BACKUP_PATH" || true


# ============================================================
# 7. SHOW MIGRATION PLAN
# ============================================================

echo ""
echo "===== 7. MIGRATION PLAN ====="

python manage.py migrate toolkit 0004 \
    --plan


# ============================================================
# 8. APPLY ONLY TOOLKIT 0004
# ============================================================

echo ""
echo "===== 8. APPLY TOOLKIT MIGRATION 0004 ====="

python manage.py migrate toolkit 0004 \
    --noinput


# ============================================================
# 9. DJANGO CHECKS
# ============================================================

echo ""
echo "===== 9. DJANGO SYSTEM CHECK ====="

python manage.py check


echo ""
echo "===== 10. MODEL ↔ MIGRATION CHECK ====="

python manage.py makemigrations \
    --check \
    --dry-run


# ============================================================
# 11. POST-MIGRATION SQLITE INTEGRITY
# ============================================================

echo ""
echo "===== 11. POST-MIGRATION SQLITE INTEGRITY ====="

DB_PATH="$DB_PATH" python - <<'PY'
import os
import sqlite3

connection = sqlite3.connect(
    os.environ["DB_PATH"]
)

integrity = connection.execute(
    "PRAGMA integrity_check"
).fetchone()[0]

foreign_keys = connection.execute(
    "PRAGMA foreign_key_check"
).fetchall()

connection.close()


print(
    "integrity_check:",
    integrity,
)

print(
    "foreign_key_violations:",
    len(foreign_keys),
)


if integrity != "ok":
    raise SystemExit(
        "POST-MIGRATION FAILURE: "
        "SQLite integrity check failed."
    )


if foreign_keys:
    raise SystemExit(
        "POST-MIGRATION FAILURE: "
        "foreign-key violations detected."
    )


print(
    "PASS: post-migration database integrity is clean."
)
PY


# ============================================================
# 12. VERIFY EXISTING TOOLKIT ROW COUNTS WERE PRESERVED
# ============================================================

echo ""
echo "===== 12. EXISTING TOOLKIT DATA PRESERVATION CHECK ====="

DB_PATH="$DB_PATH" python - <<'PY'
import json
import os
import sqlite3
from pathlib import Path


before_path = Path(
    "confidential_source/audit/"
    "pre_0004_toolkit_counts.json"
)

before = json.loads(
    before_path.read_text(
        encoding="utf-8"
    )
)


connection = sqlite3.connect(
    os.environ["DB_PATH"]
)


problems = []


for table, old_count in sorted(
    before.items()
):

    safe = table.replace(
        '"',
        '""',
    )

    exists = connection.execute(
        """
        SELECT 1
        FROM sqlite_master
        WHERE type='table'
          AND name=?
        """,
        (table,),
    ).fetchone()


    if not exists:

        problems.append(
            f"{table}: TABLE MISSING"
        )

        continue


    new_count = connection.execute(
        f'SELECT COUNT(*) FROM "{safe}"'
    ).fetchone()[0]


    status = (
        "PASS"
        if new_count == old_count
        else "MISMATCH"
    )


    print(
        f"{status}: "
        f"{table}: "
        f"{old_count} -> {new_count}"
    )


    if new_count != old_count:
        problems.append(
            f"{table}: "
            f"{old_count} -> {new_count}"
        )


connection.close()


if problems:

    raise SystemExit(
        "\nPOST-MIGRATION DATA COUNT "
        "MISMATCH:\n"
        + "\n".join(problems)
    )


print("")
print(
    "PASS: every pre-existing Toolkit table "
    "preserved its row count."
)
PY


# ============================================================
# 13. VERIFY NEW TABLES
# ============================================================

echo ""
echo "===== 13. NEW ARCHITECTURE TABLE CHECK ====="

DB_PATH="$DB_PATH" python - <<'PY'
import os
import sqlite3


expected = [
    "toolkit_importrow",
    "toolkit_importchange",
    "toolkit_serviceclassification",
    "toolkit_servicecommercial",
    "toolkit_servicecontentsection",
    "toolkit_referenceitem",
    "toolkit_comparisonmatrix",
    "toolkit_comparisonentry",
    "toolkit_communicationtemplate",
]


connection = sqlite3.connect(
    os.environ["DB_PATH"]
)


for table in expected:

    row = connection.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type='table'
          AND name=?
        """,
        (table,),
    ).fetchone()


    if not row:
        raise SystemExit(
            f"MISSING TABLE: {table}"
        )


    safe = table.replace(
        '"',
        '""',
    )

    count = connection.execute(
        f'SELECT COUNT(*) FROM "{safe}"'
    ).fetchone()[0]


    print(
        f"PASS: {table} exists | rows={count}"
    )


connection.close()


print("")
print(
    "PASS: all new architecture tables exist."
)
PY


# ============================================================
# 14. FINAL MIGRATION STATE
# ============================================================

echo ""
echo "===== 14. FINAL MIGRATION STATE ====="

python manage.py showmigrations toolkit


echo ""
echo "================================================================"
echo "STEP 8E SUCCESS"
echo "================================================================"

echo ""
echo "Migration 0004 has been applied."
echo "Existing Toolkit table counts were preserved."
echo "SQLite integrity checks passed."
echo "Verified pre-migration backup exists at:"
echo "$BACKUP_PATH"
echo ""
echo "NO EXCEL WORKBOOK DATA WAS IMPORTED."
