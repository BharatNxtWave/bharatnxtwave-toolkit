import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

project_root = str(Path.cwd())

if project_root not in sys.path:
    sys.path.insert(0, project_root)

import django
django.setup()


from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    SavedService,
    SearchEvent,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

EXPECTED_ROWS = 478
EXPECTED_SCHEME_ROWS = 113


# ============================================================
# LOCATE EXACT STAGING BATCH
# ============================================================

batches = list(
    ImportBatch.objects
    .filter(
        file_sha256=EXPECTED_SHA256
    )
    .order_by("-id")
)

batch = None

for candidate in batches:

    metadata = (
        candidate.metadata
        if isinstance(
            candidate.metadata,
            dict,
        )
        else {}
    )

    if metadata.get(
        "operation"
    ) == "workbook_staging":
        batch = candidate
        break


if batch is None:
    raise SystemExit(
        "STOPPED SAFELY: workbook staging batch not found."
    )


rows = list(
    ImportRow.objects
    .filter(
        import_batch=batch
    )
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


if len(rows) != EXPECTED_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        f"{EXPECTED_ROWS} staged rows, "
        f"found {len(rows)}."
    )


# ============================================================
# HELPERS
# ============================================================

def payload_has_content(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return False

    value = payload.get(
        "value"
    )

    if value is not None:

        text = str(value).strip()

        if text:
            return True

    if payload.get(
        "hyperlink_target"
    ):
        return True

    if payload.get(
        "hyperlink_location"
    ):
        return True

    return False


def get_meta(row):

    raw = (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )

    meta = raw.get(
        "_meta",
        {}
    )

    return (
        meta
        if isinstance(meta, dict)
        else {}
    )


def get_fields(row):

    raw = (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )

    fields = raw.get(
        "fields",
        {}
    )

    return (
        fields
        if isinstance(fields, dict)
        else {}
    )


# ============================================================
# GENERAL COUNTS
# ============================================================

family_counts = Counter()
validation_counts = Counter()
action_counts = Counter()
sheet_counts = Counter()

warning_codes = Counter()
error_codes = Counter()

invalid_locations = []

scheme_rows = []


for row in rows:

    meta = get_meta(
        row
    )

    family = meta.get(
        "family",
        "UNKNOWN",
    )

    family_counts[
        family
    ] += 1

    validation_counts[
        row.validation_status
    ] += 1

    action_counts[
        row.candidate_action
    ] += 1

    sheet_counts[
        row.sheet_name
    ] += 1


    for warning in (
        row.validation_warnings
        or []
    ):
        warning_codes[
            str(warning)
        ] += 1


    for error in (
        row.validation_errors
        or []
    ):
        error_codes[
            str(error)
        ] += 1


    if (
        row.validation_status
        == "INVALID"
    ):
        invalid_locations.append(
            (
                row.sheet_name,
                row.source_row_number,
            )
        )


    if family == "SCHEME_TABLE":
        scheme_rows.append(
            row
        )


if len(scheme_rows) != EXPECTED_SCHEME_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        f"{EXPECTED_SCHEME_ROWS} scheme rows, "
        f"found {len(scheme_rows)}."
    )


# ============================================================
# STRUCTURED FIELD COVERAGE
# ============================================================

field_names = [
    "scheme_name",
    "benefits",
    "focus_sectors",
    "eligibility",
    "deadline",
    "funding_organisation",
    "scheme_type",
    "applicable_for",
    "portal_link",
    "minimum_charge",
    "government_charge",
    "additional_info",
    "flyer",
]


field_stats = {
    field: {
        "mapped": 0,
        "populated": 0,
        "blank": 0,
        "hyperlink_target": 0,
        "hyperlink_location": 0,
        "formula": 0,
        "merged_from": 0,
    }
    for field in field_names
}


deadline_cell_types = Counter()
all_scheme_cell_types = Counter()


for row in scheme_rows:

    fields = get_fields(
        row
    )

    for field in field_names:

        if field not in fields:
            continue

        stats = field_stats[
            field
        ]

        stats[
            "mapped"
        ] += 1

        payload = fields.get(
            field
        )

        if not isinstance(
            payload,
            dict,
        ):
            stats[
                "blank"
            ] += 1
            continue


        if payload_has_content(
            payload
        ):
            stats[
                "populated"
            ] += 1
        else:
            stats[
                "blank"
            ] += 1


        if payload.get(
            "hyperlink_target"
        ):
            stats[
                "hyperlink_target"
            ] += 1


        if payload.get(
            "hyperlink_location"
        ):
            stats[
                "hyperlink_location"
            ] += 1


        if payload.get(
            "cell_type"
        ) == "f":
            stats[
                "formula"
            ] += 1


        if payload.get(
            "merged_from"
        ):
            stats[
                "merged_from"
            ] += 1


        cell_type = str(
            payload.get(
                "cell_type",
                "UNKNOWN",
            )
        )

        all_scheme_cell_types[
            cell_type
        ] += 1


        if field == "deadline":

            deadline_cell_types[
                cell_type
            ] += 1


# ============================================================
# SCHEME ACTION / VALIDATION BY SHEET
# ============================================================

sheet_action_counts = defaultdict(
    Counter
)

sheet_validation_counts = defaultdict(
    Counter
)


for row in scheme_rows:

    sheet_action_counts[
        row.sheet_name
    ][
        row.candidate_action
    ] += 1

    sheet_validation_counts[
        row.sheet_name
    ][
        row.validation_status
    ] += 1


# ============================================================
# DUPLICATE SOURCE-KEY CHECK
# No names are printed.
# ============================================================

identity_rows = defaultdict(
    list
)

for row in scheme_rows:

    if not row.source_key:
        continue

    identity_rows[
        row.source_key
    ].append(
        row
    )


cross_sheet_groups = []

for identity, identity_group in (
    identity_rows.items()
):

    sheets = {
        row.sheet_name
        for row in identity_group
    }

    if len(sheets) > 1:

        cross_sheet_groups.append(
            {
                "sheet_count": len(
                    sheets
                ),
                "row_count": len(
                    identity_group
                ),
            }
        )


duplicate_group_sizes = Counter(
    group[
        "sheet_count"
    ]
    for group
    in cross_sheet_groups
)


duplicate_row_occurrences = sum(
    group[
        "row_count"
    ]
    for group
    in cross_sheet_groups
)


# ============================================================
# RAW-DATA STRUCTURE CHECK
# ============================================================

schema_problems = []


for row in rows:

    raw = row.raw_data

    if not isinstance(
        raw,
        dict,
    ):
        schema_problems.append(
            (
                row.sheet_name,
                row.source_row_number,
                "raw_data_not_dict",
            )
        )

        continue


    if "_meta" not in raw:

        schema_problems.append(
            (
                row.sheet_name,
                row.source_row_number,
                "missing_meta",
            )
        )


    family = get_meta(
        row
    ).get(
        "family"
    )


    if family == "SCHEME_TABLE":

        if not isinstance(
            raw.get("fields"),
            dict,
        ):
            schema_problems.append(
                (
                    row.sheet_name,
                    row.source_row_number,
                    "missing_fields_object",
                )
            )

    else:

        if not isinstance(
            raw.get("cells"),
            dict,
        ):
            schema_problems.append(
                (
                    row.sheet_name,
                    row.source_row_number,
                    "missing_cells_object",
                )
            )


# ============================================================
# ROW HASH / SOURCE COORDINATE CHECK
# ============================================================

hash_counts = Counter(
    row.row_hash
    for row in rows
)

duplicate_hash_groups = sum(
    1
    for count
    in hash_counts.values()
    if count > 1
)


coordinate_counts = Counter(
    (
        row.sheet_name,
        row.source_row_number,
    )
    for row in rows
)

duplicate_coordinates = sum(
    1
    for count
    in coordinate_counts.values()
    if count > 1
)


# ============================================================
# NON-STANDARD SAFETY
# ============================================================

nonstandard_rows = [
    row
    for row in rows
    if get_meta(row).get(
        "family"
    ) != "SCHEME_TABLE"
]


nonstandard_pending = sum(
    1
    for row in nonstandard_rows
    if (
        row.validation_status
        == "PENDING"
        and row.candidate_action
        == "UNDECIDED"
    )
)


# ============================================================
# LIVE TABLE COUNTS
# ============================================================

live_counts = {
    "Service": (
        Service.objects.count()
    ),
    "SavedService": (
        SavedService.objects.count()
    ),
    "SearchEvent": (
        SearchEvent.objects.count()
    ),
    "ImportChange": (
        ImportChange.objects.count()
    ),
    "ServiceClassification": (
        ServiceClassification.objects
        .count()
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects
        .count()
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects
        .count()
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count()
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count()
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count()
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects
        .count()
    ),
}


# ============================================================
# HARD SAFETY ASSERTIONS
# ============================================================

if live_counts[
    "ImportChange"
] != 0:
    raise SystemExit(
        "STOPPED: ImportChange should still be zero."
    )


for model_name in [
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if live_counts[
        model_name
    ] != 0:
        raise SystemExit(
            "STOPPED: "
            f"{model_name} unexpectedly contains data."
        )


if len(
    nonstandard_rows
) != 365:
    raise SystemExit(
        "STOPPED: expected 365 "
        "non-standard staged rows."
    )


if nonstandard_pending != 365:
    raise SystemExit(
        "STOPPED: a non-standard row "
        "has already been assigned a live action."
    )


if schema_problems:
    raise SystemExit(
        "STOPPED: staged raw-data schema "
        f"problems detected: {len(schema_problems)}"
    )


if duplicate_coordinates:
    raise SystemExit(
        "STOPPED: duplicate source coordinates detected."
    )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step9e_staging_quality_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 9E STAGING QUALITY AUDIT"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    "Workbook SHA-256 matches approved source: YES"
)

lines.append(
    f"Staged rows inspected: {len(rows)}"
)

lines.append(
    f"Structured scheme rows inspected: {len(scheme_rows)}"
)

lines.append(
    f"Non-standard rows inspected: {len(nonstandard_rows)}"
)

lines.append("")

lines.append(
    "1. VALIDATION"
)

for key, value in sorted(
    validation_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "2. CANDIDATE ACTIONS"
)

for key, value in sorted(
    action_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "3. WARNING CODES"
)

if warning_codes:

    for key, value in sorted(
        warning_codes.items()
    ):
        lines.append(
            f"  {key}: {value}"
        )

else:
    lines.append(
        "  NONE"
    )


lines.append("")

lines.append(
    "4. ERROR CODES"
)

if error_codes:

    for key, value in sorted(
        error_codes.items()
    ):
        lines.append(
            f"  {key}: {value}"
        )

else:
    lines.append(
        "  NONE"
    )


lines.append("")

lines.append(
    "5. INVALID SOURCE LOCATIONS"
)

if invalid_locations:

    for sheet_name, row_number in (
        invalid_locations
    ):
        lines.append(
            f"  {sheet_name}: row {row_number}"
        )

else:
    lines.append(
        "  NONE"
    )


lines.append("")

lines.append(
    "6. STRUCTURED FIELD COVERAGE"
)

for field in field_names:

    stats = field_stats[
        field
    ]

    lines.append(
        f"  {field}: "
        f"mapped={stats['mapped']} | "
        f"populated={stats['populated']} | "
        f"blank={stats['blank']} | "
        f"hyperlink_target={stats['hyperlink_target']} | "
        f"formula={stats['formula']} | "
        f"merged_from={stats['merged_from']}"
    )


lines.append("")

lines.append(
    "7. DEADLINE SOURCE CELL TYPES"
)

for key, value in sorted(
    deadline_cell_types.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "8. STRUCTURED SCHEME ROWS BY SHEET"
)

for sheet_name in sorted(
    sheet_action_counts
):

    actions = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            sheet_action_counts[
                sheet_name
            ].items()
        )
    )

    validations = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            sheet_validation_counts[
                sheet_name
            ].items()
        )
    )

    lines.append(
        f"  {sheet_name}: "
        f"actions[{actions}] | "
        f"validation[{validations}]"
    )


lines.append("")

lines.append(
    "9. CROSS-SHEET DUPLICATE STRUCTURE"
)

lines.append(
    f"  Duplicate groups: "
    f"{len(cross_sheet_groups)}"
)

lines.append(
    f"  Duplicate row occurrences: "
    f"{duplicate_row_occurrences}"
)

for sheet_count, group_count in sorted(
    duplicate_group_sizes.items()
):
    lines.append(
        f"  Groups appearing across "
        f"{sheet_count} sheets: "
        f"{group_count}"
    )


lines.append("")

lines.append(
    "10. STAGING STRUCTURE"
)

lines.append(
    f"  Raw-data schema problems: "
    f"{len(schema_problems)}"
)

lines.append(
    f"  Duplicate source coordinates: "
    f"{duplicate_coordinates}"
)

lines.append(
    f"  Duplicate row-hash groups: "
    f"{duplicate_hash_groups}"
)

lines.append(
    f"  Non-standard rows still "
    f"PENDING + UNDECIDED: "
    f"{nonstandard_pending}"
)


lines.append("")

lines.append(
    "11. LIVE TOOLKIT TABLES"
)

for key, value in live_counts.items():
    lines.append(
        f"  {key}: {value}"
    )


lines.append("")

lines.append(
    "12. SAFETY RESULT"
)

lines.append(
    "  Service records created by this audit: 0"
)

lines.append(
    "  Service records updated by this audit: 0"
)

lines.append(
    "  ImportRow records changed by this audit: 0"
)

lines.append(
    "  Workbook accessed by this audit: NO"
)

lines.append(
    "  Confidential cell values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 9E AUDIT COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
