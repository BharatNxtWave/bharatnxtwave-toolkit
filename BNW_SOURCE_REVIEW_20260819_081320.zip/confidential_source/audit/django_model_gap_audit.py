from pathlib import Path
from collections import defaultdict
import json
import os
import re
import sys


# ============================================================
# BHARATNXT WAVE
# STEP 6 — DJANGO MODEL / WORKBOOK GAP AUDIT
#
# READ ONLY
# NO DATABASE ROWS READ
# NO MIGRATIONS
# NO MODEL MODIFICATION
# NO EXCEL ACCESS
# ============================================================


PROJECT_ROOT = Path.cwd()

# Ensure Django project packages such as "config"
# are importable when this audit script is executed
# from confidential_source/audit/.
project_root_text = str(PROJECT_ROOT)

if project_root_text not in sys.path:
    sys.path.insert(0, project_root_text)

AUDIT_DIR = (
    PROJECT_ROOT
    / "confidential_source"
    / "audit"
)

ARCHITECTURE_FILE = (
    AUDIT_DIR
    / "workbook_architecture_SAFE_TO_SHARE.txt"
)

OUTPUT_JSON = (
    AUDIT_DIR
    / "django_model_gap_private.json"
)

OUTPUT_TEXT = (
    AUDIT_DIR
    / "django_model_gap_SAFE_TO_SHARE.txt"
)


# ============================================================
# SAFETY CHECK
# ============================================================

if not (PROJECT_ROOT / "manage.py").exists():

    raise SystemExit(
        "STOPPED SAFELY: manage.py was not found in the "
        "current directory."
    )


if not ARCHITECTURE_FILE.exists():

    raise SystemExit(
        "STOPPED SAFELY: Step 5 architecture report "
        "was not found."
    )


# ============================================================
# FIND DJANGO SETTINGS MODULE FROM manage.py
# ============================================================

manage_text = (
    PROJECT_ROOT
    / "manage.py"
).read_text(
    encoding="utf-8",
    errors="ignore",
)


settings_match = re.search(
    r"DJANGO_SETTINGS_MODULE[\"']?\s*,\s*[\"']([^\"']+)[\"']",
    manage_text,
)


if not settings_match:

    settings_match = re.search(
        r"os\.environ\.setdefault\(\s*[\"']DJANGO_SETTINGS_MODULE[\"']"
        r"\s*,\s*[\"']([^\"']+)[\"']",
        manage_text,
    )


if not settings_match:

    raise SystemExit(
        "STOPPED SAFELY: could not determine "
        "DJANGO_SETTINGS_MODULE from manage.py."
    )


settings_module = settings_match.group(1)


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    settings_module,
)


# ============================================================
# START DJANGO
# ============================================================

try:

    import django

    django.setup()

except Exception as exc:

    raise SystemExit(
        "STOPPED SAFELY: Django could not initialise.\n"
        f"{type(exc).__name__}: {exc}"
    )


from django.apps import apps


# ============================================================
# HELPERS
# ============================================================

def safe_default(field):

    if not field.has_default():
        return None

    default = field.default

    if callable(default):

        return (
            "<callable:"
            + getattr(
                default,
                "__name__",
                default.__class__.__name__,
            )
            + ">"
        )

    # We deliberately avoid printing arbitrary default
    # values because defaults could theoretically contain
    # sensitive configuration.

    if default in (
        None,
        "",
        True,
        False,
    ):
        return repr(default)

    if isinstance(
        default,
        (int, float),
    ):
        return repr(default)

    return "<configured>"


def field_type(field):

    try:
        return field.get_internal_type()

    except Exception:
        return field.__class__.__name__


def relation_target(field):

    remote = getattr(
        field,
        "remote_field",
        None,
    )

    if not remote:
        return None

    model = getattr(
        remote,
        "model",
        None,
    )

    if model is None:
        return None

    if isinstance(model, str):
        return model

    return (
        model._meta.app_label
        + "."
        + model.__name__
    )


def normalize(value):

    value = str(
        value or ""
    ).casefold()

    value = re.sub(
        r"[^a-z0-9]+",
        "_",
        value,
    )

    value = re.sub(
        r"_+",
        "_",
        value,
    )

    return value.strip("_")


# ============================================================
# WORKBOOK REQUIREMENTS
#
# These come from the REAL workbook architecture established
# in Steps 2–5.
#
# We are not inventing source values here.
# ============================================================

REQUIRED_CAPABILITIES = [

    {
        "key": "canonical_name",
        "description": "Canonical scheme/service name",
        "expected_names": [
            "name",
            "scheme_name",
            "title",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "benefits",
        "description": "Scheme benefits",
        "expected_names": [
            "benefits",
            "benefit",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "focus_sectors",
        "description": "Focus sectors / industries",
        "expected_names": [
            "focus_sectors",
            "sectors",
            "sector",
            "industries",
            "industry",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "eligibility",
        "description": "Eligibility criteria",
        "expected_names": [
            "eligibility",
            "eligibility_criteria",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "funding_organisation",
        "description": "Funding organisation / organisation",
        "expected_names": [
            "funding_organisation",
            "funding_organization",
            "organisation",
            "organization",
        ],
        "importance": "HIGH",
    },

    {
        "key": "scheme_type",
        "description": "Type of scheme/service",
        "expected_names": [
            "scheme_type",
            "type_of_scheme",
            "service_type",
        ],
        "importance": "HIGH",
    },

    {
        "key": "applicable_for",
        "description": "Applicable for / application for",
        "expected_names": [
            "applicable_for",
            "application_for",
        ],
        "importance": "HIGH",
    },

    {
        "key": "deadline_raw",
        "description": "Original source deadline text",
        "expected_names": [
            "deadline_raw",
            "deadline_text",
            "application_deadline_text",
            "last_date_text",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "deadline_date",
        "description": "Normalized application deadline date",
        "expected_names": [
            "application_deadline",
            "deadline",
            "deadline_date",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "deadline_status",
        "description": "Rolling/Ongoing/Open/etc. deadline state",
        "expected_names": [
            "deadline_status",
            "application_status",
        ],
        "importance": "HIGH",
    },

    {
        "key": "portal_link",
        "description": "Official portal hyperlink target",
        "expected_names": [
            "portal_link",
            "portal_url",
            "official_url",
            "source_url",
            "website",
            "url",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "minimum_upfront_charge",
        "description": "BharatNXT minimum upfront charge",
        "expected_names": [
            "minimum_upfront_charge",
            "min_charge",
            "minimum_charge",
            "upfront_charge",
        ],
        "importance": "HIGH",
    },

    {
        "key": "government_charge",
        "description": "Government/vendor/registration charge",
        "expected_names": [
            "government_charge",
            "govt_charge",
            "government_fees",
            "vendor_cost",
        ],
        "importance": "HIGH",
    },

    {
        "key": "additional_info",
        "description": "Additional scheme information",
        "expected_names": [
            "additional_info",
            "additional_information",
            "notes",
        ],
        "importance": "MEDIUM",
    },

    {
        "key": "flyer",
        "description": "Flyer/document reference",
        "expected_names": [
            "flyer",
            "flyer_url",
            "document",
            "document_url",
        ],
        "importance": "MEDIUM",
    },

    {
        "key": "classification",
        "description": "Multiple classifications/tags per Service",
        "expected_names": [
            "categories",
            "category",
            "classifications",
            "tags",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "source_batch",
        "description": "Import/source event lineage",
        "expected_names": [
            "import_batch",
            "source_batch",
            "import_event",
            "source_event",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "source_sheet",
        "description": "Original Excel sheet name",
        "expected_names": [
            "source_sheet",
            "sheet_name",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "source_row",
        "description": "Original Excel row number",
        "expected_names": [
            "source_row",
            "row_number",
            "source_row_number",
        ],
        "importance": "CRITICAL",
    },

    {
        "key": "source_raw_data",
        "description": "Raw normalized source values for traceability",
        "expected_names": [
            "raw_data",
            "source_data",
            "raw_payload",
            "source_payload",
        ],
        "importance": "HIGH",
    },

    {
        "key": "source_row_hash",
        "description": "Row fingerprint for change detection",
        "expected_names": [
            "row_hash",
            "source_hash",
            "content_hash",
        ],
        "importance": "HIGH",
    },

    {
        "key": "commercial_visibility",
        "description": "Access control for sensitive commercial data",
        "expected_names": [
            "visibility",
            "is_internal",
            "internal_only",
            "access_level",
        ],
        "importance": "HIGH",
    },
]


# ============================================================
# INSPECT TOOLKIT MODELS
# ============================================================

try:

    toolkit_config = apps.get_app_config(
        "toolkit"
    )

except LookupError:

    raise SystemExit(
        "STOPPED SAFELY: Django app 'toolkit' "
        "was not found."
    )


model_reports = []


for model in toolkit_config.get_models():

    meta = model._meta

    fields = []


    for field in meta.get_fields():

        field_info = {
            "name": field.name,
            "type": field_type(field),
            "relation": bool(
                getattr(
                    field,
                    "is_relation",
                    False,
                )
            ),
            "relation_target": relation_target(
                field
            ),
            "many_to_many": bool(
                getattr(
                    field,
                    "many_to_many",
                    False,
                )
            ),
            "one_to_many": bool(
                getattr(
                    field,
                    "one_to_many",
                    False,
                )
            ),
            "many_to_one": bool(
                getattr(
                    field,
                    "many_to_one",
                    False,
                )
            ),
            "one_to_one": bool(
                getattr(
                    field,
                    "one_to_one",
                    False,
                )
            ),
            "null": getattr(
                field,
                "null",
                None,
            ),
            "blank": getattr(
                field,
                "blank",
                None,
            ),
            "primary_key": getattr(
                field,
                "primary_key",
                False,
            ),
            "unique": getattr(
                field,
                "unique",
                False,
            ),
            "editable": getattr(
                field,
                "editable",
                None,
            ),
            "default": (
                safe_default(field)
                if hasattr(
                    field,
                    "has_default",
                )
                else None
            ),
        }


        max_length = getattr(
            field,
            "max_length",
            None,
        )


        if max_length is not None:
            field_info[
                "max_length"
            ] = max_length


        fields.append(
            field_info
        )


    constraints = []


    for constraint in meta.constraints:

        constraints.append(
            {
                "name": getattr(
                    constraint,
                    "name",
                    None,
                ),
                "type": (
                    constraint
                    .__class__
                    .__name__
                ),
            }
        )


    indexes = []


    for index in meta.indexes:

        indexes.append(
            {
                "name": getattr(
                    index,
                    "name",
                    None,
                ),
                "fields": list(
                    getattr(
                        index,
                        "fields",
                        [],
                    )
                ),
            }
        )


    model_reports.append({
        "model": model.__name__,
        "table": meta.db_table,
        "fields": fields,
        "constraints": constraints,
        "indexes": indexes,
    })


# ============================================================
# FIND SERVICE MODEL
# ============================================================

service_model = None


for model in toolkit_config.get_models():

    if model.__name__.casefold() == "service":

        service_model = model

        break


service_field_names = set()


if service_model:

    service_field_names = {
        normalize(field.name)
        for field
        in service_model._meta.get_fields()
    }


# ============================================================
# FIND ALL TOOLKIT FIELD NAMES
# ============================================================

all_fields = defaultdict(list)


for model in toolkit_config.get_models():

    for field in model._meta.get_fields():

        all_fields[
            normalize(field.name)
        ].append(
            f"{model.__name__}.{field.name}"
        )


# ============================================================
# GAP MATCHING
#
# Exact known aliases only.
# We deliberately do NOT pretend semantically different
# fields are equivalent.
# ============================================================

gap_results = []


for requirement in REQUIRED_CAPABILITIES:

    expected = {
        normalize(name)
        for name
        in requirement[
            "expected_names"
        ]
    }


    service_matches = []


    for name in expected:

        if name in service_field_names:

            service_matches.append(
                f"Service.{name}"
            )


    toolkit_matches = []


    for name in expected:

        toolkit_matches.extend(
            all_fields.get(
                name,
                []
            )
        )


    toolkit_matches = sorted(
        set(
            toolkit_matches
        )
    )


    if service_matches:

        status = "FOUND_ON_SERVICE"

    elif toolkit_matches:

        status = "FOUND_ELSEWHERE"

    else:

        status = "NOT_FOUND"


    gap_results.append({
        "key": requirement["key"],
        "description": requirement[
            "description"
        ],
        "importance": requirement[
            "importance"
        ],
        "status": status,
        "service_matches": sorted(
            service_matches
        ),
        "toolkit_matches": (
            toolkit_matches
        ),
    })


# ============================================================
# SPECIAL WORKBOOK CAPABILITY CHECKS
# ============================================================

model_names = {
    model.__name__.casefold()
    for model
    in toolkit_config.get_models()
}


def model_exists(*names):

    return any(
        name.casefold()
        in model_names
        for name in names
    )


special_capabilities = [

    {
        "capability":
            "Source row staging",
        "status":
            "PRESENT"
            if model_exists(
                "ImportRow",
                "StagedService",
                "StagedRow",
            )
            else "NOT FOUND",
    },

    {
        "capability":
            "Service source lineage/version model",
        "status":
            "PRESENT"
            if model_exists(
                "ServiceSource",
                "ServiceVersion",
                "SourceRecord",
            )
            else "NOT FOUND",
    },

    {
        "capability":
            "Multiple Service classifications",
        "status":
            "PRESENT"
            if model_exists(
                "ServiceClassification",
                "Classification",
                "Tag",
            )
            else "NEEDS FIELD/RELATION REVIEW",
    },

    {
        "capability":
            "Structured commercial pricing model",
        "status":
            "PRESENT"
            if model_exists(
                "ServiceCommercial",
                "ServicePricing",
                "CommercialTerm",
                "Pricing",
            )
            else "NOT FOUND",
    },

    {
        "capability":
            "Reference-data model",
        "status":
            "PRESENT"
            if model_exists(
                "ReferenceData",
                "ReferenceItem",
                "Benefit",
            )
            else "NOT FOUND",
    },

    {
        "capability":
            "Comparison-matrix model",
        "status":
            "PRESENT"
            if model_exists(
                "Comparison",
                "ComparisonMatrix",
                "SchemeComparison",
            )
            else "NOT FOUND",
    },

    {
        "capability":
            "Knowledge/process content model",
        "status":
            "PRESENT"
            if model_exists(
                "Knowledge",
                "KnowledgeArticle",
                "KnowledgeEntry",
                "ProcessGuide",
            )
            else "NOT FOUND",
    },
]


# ============================================================
# MACHINE REPORT
# ============================================================

machine_report = {
    "django_settings_module":
        settings_module,

    "toolkit_models":
        model_reports,

    "service_model_found":
        service_model is not None,

    "gap_results":
        gap_results,

    "special_capabilities":
        special_capabilities,
}


OUTPUT_JSON.write_text(
    json.dumps(
        machine_report,
        indent=2,
        ensure_ascii=False,
    ),
    encoding="utf-8",
)


# ============================================================
# SAFE TEXT REPORT
# ============================================================

lines = []


def add(text=""):

    lines.append(
        str(text)
    )


add("=" * 80)

add(
    "BHARATNXT WAVE — DJANGO MODEL GAP AUDIT"
)

add("=" * 80)

add()

add(
    f"Django settings: {settings_module}"
)

add(
    f"Toolkit models found: {len(model_reports)}"
)

add(
    f"Service model found: "
    f"{'YES' if service_model else 'NO'}"
)

add()

add(
    "NO DATABASE RECORD VALUES WERE READ."
)

add()


# ============================================================
# MODEL INVENTORY
# ============================================================

add("1. CURRENT TOOLKIT MODELS")

add("-" * 80)


for model in model_reports:

    add(
        f"\n{model['model']}"
    )

    add(
        f"Database table: "
        f"{model['table']}"
    )

    add(
        f"Fields: "
        f"{len(model['fields'])}"
    )


    for field in model[
        "fields"
    ]:

        relation = ""

        if field[
            "relation_target"
        ]:

            relation = (
                " → "
                + field[
                    "relation_target"
                ]
            )


        flags = []


        if field[
            "primary_key"
        ]:

            flags.append(
                "PK"
            )


        if field[
            "unique"
        ]:

            flags.append(
                "UNIQUE"
            )


        if field[
            "null"
        ]:

            flags.append(
                "NULL"
            )


        if field[
            "blank"
        ]:

            flags.append(
                "BLANK"
            )


        if field[
            "many_to_many"
        ]:

            flags.append(
                "M2M"
            )


        flag_text = (
            " [" + ", ".join(flags) + "]"
            if flags
            else ""
        )


        length = ""

        if field.get(
            "max_length"
        ):

            length = (
                f"({field['max_length']})"
            )


        add(
            f"  • {field['name']}: "
            f"{field['type']}{length}"
            f"{relation}{flag_text}"
        )


add()


# ============================================================
# STRUCTURED SCHEME GAP ANALYSIS
# ============================================================

add(
    "2. REAL WORKBOOK → CURRENT DJANGO CAPABILITY"
)

add("-" * 80)


for result in gap_results:

    symbol = {

        "FOUND_ON_SERVICE": "✓",
        "FOUND_ELSEWHERE": "~",
        "NOT_FOUND": "✗",

    }[
        result["status"]
    ]


    add(
        f"{symbol} "
        f"{result['description']}"
    )

    add(
        f"    Importance: "
        f"{result['importance']}"
    )

    add(
        f"    Status: "
        f"{result['status']}"
    )


    if result[
        "service_matches"
    ]:

        add(
            "    Service match: "
            + ", ".join(
                result[
                    "service_matches"
                ]
            )
        )


    if (
        not result[
            "service_matches"
        ]
        and result[
            "toolkit_matches"
        ]
    ):

        add(
            "    Other model match: "
            + ", ".join(
                result[
                    "toolkit_matches"
                ]
            )
        )


    add()


# ============================================================
# SPECIAL STRUCTURES
# ============================================================

add(
    "3. NON-STANDARD WORKBOOK DATA REQUIREMENTS"
)

add("-" * 80)


for item in special_capabilities:

    add(
        f"• {item['capability']}: "
        f"{item['status']}"
    )


add()


# ============================================================
# RULES
# ============================================================

add(
    "4. INTERPRETATION RULES"
)

add("-" * 80)

add(
    "FOUND_ON_SERVICE"
)

add(
    "  A field with a known equivalent name exists "
    "directly on Service."
)

add()

add(
    "FOUND_ELSEWHERE"
)

add(
    "  A known equivalent exists somewhere in the Toolkit,"
)

add(
    "  but its relationship to Service must be inspected."
)

add()

add(
    "NOT_FOUND"
)

add(
    "  No known equivalent field was found."
)

add(
    "  This does NOT automatically mean we should add one."
)

add(
    "  We first decide the correct normalized model structure."
)

add()


# ============================================================
# SAFETY
# ============================================================

add(
    "5. MIGRATION STATUS"
)

add("-" * 80)

add(
    "No models were changed."
)

add(
    "No migrations were created."
)

add(
    "No migrations were applied."
)

add(
    "No database rows were queried."
)

add(
    "No Excel workbook was accessed by this script."
)

add()

add(
    "NEXT:"
)

add(
    "Use this report to design the FINAL normalized database"
)

add(
    "architecture before touching models.py."
)

add()

add("=" * 80)


OUTPUT_TEXT.write_text(
    "\n".join(
        lines
    ),
    encoding="utf-8",
)


print("")
print("=" * 80)

print(
    "STEP 6 — DJANGO MODEL GAP AUDIT COMPLETE"
)

print("=" * 80)

print("")

print(
    f"Toolkit models found: "
    f"{len(model_reports)}"
)

print(
    "Service model found: "
    f"{'YES' if service_model else 'NO'}"
)

print("")

missing = sum(
    1
    for item in gap_results
    if item["status"] == "NOT_FOUND"
)

elsewhere = sum(
    1
    for item in gap_results
    if item["status"] == "FOUND_ELSEWHERE"
)

on_service = sum(
    1
    for item in gap_results
    if item["status"] == "FOUND_ON_SERVICE"
)


print(
    f"Capabilities found on Service: "
    f"{on_service}"
)

print(
    f"Capabilities found elsewhere: "
    f"{elsewhere}"
)

print(
    f"Capabilities not found: "
    f"{missing}"
)

print("")

print(
    "SAFE REPORT:"
)

print(
    OUTPUT_TEXT
)

print("")

print(
    "PRIVATE MACHINE REPORT:"
)

print(
    OUTPUT_JSON
)

print("")

print(
    "NO MODEL FILES WERE MODIFIED."
)

print(
    "NO DATABASE ROWS WERE READ OR CHANGED."
)

print(
    "NO MIGRATIONS WERE CREATED."
)
