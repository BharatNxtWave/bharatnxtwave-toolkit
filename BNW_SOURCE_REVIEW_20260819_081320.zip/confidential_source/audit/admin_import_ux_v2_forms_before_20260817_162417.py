from pathlib import Path

from django import forms


class ToolkitImportUploadForm(forms.Form):
    file = forms.FileField(
        label="Upload Excel or CSV",
        help_text="Supported formats: .xlsx and .csv. Maximum size: 20 MB."
    )

    def clean_file(self):
        uploaded_file = self.cleaned_data["file"]

        max_size = 20 * 1024 * 1024

        if uploaded_file.size > max_size:
            raise forms.ValidationError(
                "File is larger than the 20 MB limit."
            )

        extension = (
            Path(uploaded_file.name)
            .suffix
            .lower()
        )

        allowed_extensions = {
            ".xlsx",
            ".csv",
        }

        if extension not in allowed_extensions:
            raise forms.ValidationError(
                "Only .xlsx and .csv files are supported."
            )

        return uploaded_file
