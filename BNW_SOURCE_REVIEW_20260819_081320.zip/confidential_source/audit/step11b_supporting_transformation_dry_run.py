import os
import sys

from collections import Counter
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.importing.transformation import (
    build_core_transformation_plan,
)

from toolkit.importing.supporting_transformation import (
    build_supporting_transformation_plan,
)

from toolkit.models import (
    Category,
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ServiceDomain,
    ServiceSource,
)


def snapshot():
    return {
        "Service":
            Service.objects.count(),
        "ServiceDomain":
            ServiceDomain.objects.count(),
        "Category":
            Category.objects.count(),
        "ImportRow":
            ImportRow.objects.count(),
        "ImportChange":
            ImportChange.objects.count(),
        "ServiceClassification":
            ServiceClassification.objects.count(),
        "ServiceSource":
            ServiceSource.objects.count(),
        "ServiceCommercial":
            ServiceCommercial.objects.count(),
        "ServiceContentSection":
            ServiceContentSection.objects.count(),
        "ReferenceItem":
            ReferenceItem.objects.count(),
        "ComparisonMatrix":
            ComparisonMatrix.objects.count(),
        "ComparisonEntry":
            ComparisonEntry.objects.count(),
        "CommunicationTemplate":
            CommunicationTemplate.objects.count(),
    }


expected = {
    "Service": 1,
    "ServiceDomain": 8,
    "Category": 32,
    "ImportRow": 478,
    "ImportChange": 0,
    "ServiceClassification": 0,
    "ServiceSource": 0,
    "ServiceCommercial": 0,
    "ServiceContentSection": 0,
    "ReferenceItem": 0,
    "ComparisonMatrix": 0,
    "ComparisonEntry": 0,
    "CommunicationTemplate": 0,
}


before = snapshot()


if before != expected:
    raise SystemExit(
        "STOPPED SAFELY: database state differs "
        "from approved pre-import state."
    )


core = (
    build_core_transformation_plan()
)

support = (
    build_supporting_transformation_plan(
        core
    )
)


sources = support[
    "sources"
]

references = support[
    "references"
]

comparison = support[
    "comparison"
]

knowledge = support[
    "knowledge"
]

communication = support[
    "communication"
]


# ============================================================
# STATISTICS
# ============================================================

source_kind_counts = Counter(
    item[
        "source_kind"
    ]
    for item in (
        sources[
            "plans"
        ]
    )
)

source_method_counts = Counter(
    item[
        "extraction_method"
    ]
    for item in (
        sources[
            "plans"
        ]
    )
)

reference_family_counts = Counter(
    item[
        "source_family"
    ]
    for item in references
)

reference_visibility_counts = Counter(
    item[
        "visibility"
    ]
    for item in references
)

knowledge_sheet_counts = Counter(
    item[
        "source_sheet"
    ]
    for item in (
        knowledge[
            "plans"
        ]
    )
)

knowledge_type_counts = Counter(
    item[
        "section_type"
    ]
    for item in (
        knowledge[
            "plans"
        ]
    )
)

anchor_method_counts = Counter(
    result[
        "method"
    ]
    for result in (
        knowledge[
            "anchors"
        ].values()
    )
)

distinct_anchor_services = len(
    {
        result[
            "service_identity"
        ]
        for result in (
            knowledge[
                "anchors"
            ].values()
        )
    }
)


# ============================================================
# HARD GATES
# ============================================================

if (
    len(references)
    < 44
):
    raise SystemExit(
        "STOPPED SAFELY: ReferenceItem plan "
        "is unexpectedly too small."
    )


if (
    reference_family_counts[
        "BENEFITS"
    ]
    != 44
):
    raise SystemExit(
        "STOPPED SAFELY: BENEFITS reference "
        "count is not 44."
    )


if (
    len(
        comparison[
            "entries"
        ]
    )
    <= 0
):
    raise SystemExit(
        "STOPPED SAFELY: comparison matrix "
        "contains no entries."
    )


if (
    len(
        knowledge[
            "plans"
        ]
    )
    != 207
):
    raise SystemExit(
        "STOPPED SAFELY: knowledge plan "
        "does not cover 207 rows."
    )


if (
    len(
        knowledge[
            "anchors"
        ]
    )
    != 5
):
    raise SystemExit(
        "STOPPED SAFELY: expected five "
        "knowledge anchors."
    )


if (
    anchor_method_counts[
        "FUZZY_HIGH_CONFIDENCE"
    ]
    != 3
    or anchor_method_counts[
        "CONTENT_EVIDENCE"
    ]
    != 2
):
    raise SystemExit(
        "STOPPED SAFELY: knowledge anchor "
        "resolution differs from approved audits."
    )


if not communication:
    raise SystemExit(
        "STOPPED SAFELY: communication "
        "template was not planned."
    )


# ============================================================
# DATABASE MUST STILL BE UNCHANGED
# ============================================================

after = snapshot()


if after != before:
    raise SystemExit(
        "STOPPED SAFELY: supporting dry-run "
        "changed database counts."
    )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step11b_supporting_transformation_SAFE_TO_SHARE.txt"
)


lines = [
    "=" * 80,
    (
        "BHARATNXT WAVE — "
        "STEP 11B SUPPORTING TRANSFORMATION DRY RUN"
    ),
    "=" * 80,
    "",
    (
        f"Mapping Contract version: "
        f"{support['contract_version']}"
    ),
    (
        f"Import Batch ID: "
        f"{support['batch_id']}"
    ),
    "Database writes performed: NO",
    "",
    "1. SERVICE SOURCE PLAN",
    (
        f"  Planned ServiceSource records: "
        f"{len(sources['plans'])}"
    ),
]


for key, value in sorted(
    source_kind_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.append(
    (
        "  Populated portal/flyer fields "
        "without verified http/https URL: "
        f"{sources['unresolved_portal_or_flyer']}"
    )
)

lines.append(
    (
        "  Additional-info text rows "
        "retained outside ServiceSource: "
        f"{sources['additional_text_only']}"
    )
)


lines.extend(
    [
        "",
        "  EXTRACTION METHODS",
    ]
)


for key, value in sorted(
    source_method_counts.items()
):
    lines.append(
        f"    {key}: {value}"
    )


lines.extend(
    [
        "",
        "2. REFERENCE ITEM PLAN",
        (
            f"  Total ReferenceItems: "
            f"{len(references)}"
        ),
    ]
)


for key, value in sorted(
    reference_family_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


for key, value in sorted(
    reference_visibility_counts.items()
):
    lines.append(
        f"  Visibility {key}: {value}"
    )


lines.extend(
    [
        "",
        "3. LOAN COMPARISON PLAN",
        "  ComparisonMatrix records: 1",
        (
            f"  ComparisonEntry records: "
            f"{len(comparison['entries'])}"
        ),
        "  Source title rows: 1",
        "  Source header rows: 1",
        "  Source data rows: 21",
        "  Missing source headers: 0",
        "  Numeric auto-parsing: NO",
        "",
        "4. KNOWLEDGE PLAN",
        (
            f"  Source documents: "
            f"{len(knowledge['anchors'])}"
        ),
        (
            f"  Source content rows covered: "
            f"{len(knowledge['plans'])}"
        ),
        (
            f"  Planned ServiceContentSection records: "
            f"{len(knowledge['plans'])}"
        ),
        (
            f"  Formatting heading rows detected: "
            f"{knowledge['heading_count']}"
        ),
        (
            f"  Distinct Service anchors: "
            f"{distinct_anchor_services}"
        ),
        (
            "  Workbook hash verified for "
            "formatting metadata: YES"
        ),
        "",
        "  ANCHOR RESOLUTION",
    ]
)


for key, value in sorted(
    anchor_method_counts.items()
):
    lines.append(
        f"    {key}: {value}"
    )


lines.append(
    ""
)

lines.append(
    "  CONTENT ROWS BY SOURCE DOCUMENT"
)


for key, value in sorted(
    knowledge_sheet_counts.items()
):
    lines.append(
        f"    {key}: {value}"
    )


lines.append(
    ""
)

lines.append(
    "  SECTION TYPES"
)


for key, value in sorted(
    knowledge_type_counts.items()
):
    lines.append(
        f"    {key}: {value}"
    )


lines.extend(
    [
        "",
        "5. COMMUNICATION PLAN",
        "  CommunicationTemplate records: 1",
        "  Status: DRAFT",
        "  Visibility: ADMIN_ONLY",
        "  Source sheet: ONBOARDING_MAIL",
        "  Subject lines detected: 1",
        "  Source content lines: 20",
        "",
        "6. COMPLETE IN-MEMORY PLAN",
        (
            f"  Services: "
            f"{len(core['services'])}"
        ),
        (
            f"  Categories: "
            f"{len(core['categories'])}"
        ),
        (
            f"  ServiceClassifications: "
            f"{len(core['classifications'])}"
        ),
        (
            f"  ServiceCommercial: "
            f"{len(core['commercial'])}"
        ),
        (
            f"  ServiceSource: "
            f"{len(sources['plans'])}"
        ),
        (
            f"  ReferenceItem: "
            f"{len(references)}"
        ),
        "  ComparisonMatrix: 1",
        (
            f"  ComparisonEntry: "
            f"{len(comparison['entries'])}"
        ),
        (
            f"  ServiceContentSection: "
            f"{len(knowledge['plans'])}"
        ),
        "  CommunicationTemplate: 1",
        "",
        "7. DATABASE SAFETY",
    ]
)


for key, value in after.items():
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "8. CONFIDENTIALITY",
        "  Service names printed: NO",
        "  URLs printed: NO",
        "  Benefit values printed: NO",
        "  Commercial values printed: NO",
        "  BDM deductions printed: NO",
        "  Knowledge content printed: NO",
        "  Email content printed: NO",
        "  Detailed transformation plan persisted: NO",
        "",
        "9. RESULT",
        "  CORE TRANSFORMATION ENGINE: PASS",
        "  SUPPORTING TRANSFORMATION ENGINE: PASS",
        "  WHOLE-WORKBOOK IN-MEMORY PLAN: COMPLETE",
        "  LIVE DATABASE IMPORT: NOT STARTED",
    ]
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 11B SUPPORTING TRANSFORMATION DRY RUN COMPLETE"
)

print(
    f"ServiceSource plans: "
    f"{len(sources['plans'])}"
)

print(
    f"ReferenceItem plans: "
    f"{len(references)}"
)

print(
    f"ComparisonEntry plans: "
    f"{len(comparison['entries'])}"
)

print(
    f"Knowledge section plans: "
    f"{len(knowledge['plans'])}"
)

print(
    "CommunicationTemplate plans: 1"
)

print(
    f"SAFE REPORT: {output}"
)
