#!/usr/bin/env bash
set -euo pipefail

cd "/mnt/d/BharatNXT Wave/BharatNXTwave Toolkit"
source .venv/bin/activate

echo ""
echo "============================================================"
echo "STEP 10L — FREEZE WHOLE-WORKBOOK MAPPING CONTRACT V2"
echo "============================================================"


# ============================================================
# 1. PRE-FREEZE SAFETY GATE
# ============================================================

echo ""
echo "===== PRE-FREEZE DATABASE STATE ====="

python manage.py shell <<'PY'
from toolkit.models import (
    Service,
    ServiceDomain,
    Category,
    ImportBatch,
    ImportRow,
    ImportChange,
    ServiceClassification,
    ServiceSource,
    ServiceCommercial,
    ServiceContentSection,
    ReferenceItem,
    ComparisonMatrix,
    ComparisonEntry,
    CommunicationTemplate,
)

expected = {
    "Service": (
        Service.objects.count(),
        1,
    ),
    "ServiceDomain": (
        ServiceDomain.objects.count(),
        8,
    ),
    "Category": (
        Category.objects.count(),
        32,
    ),
    "ImportRow": (
        ImportRow.objects.count(),
        478,
    ),
    "ImportChange": (
        ImportChange.objects.count(),
        0,
    ),
    "ServiceClassification": (
        ServiceClassification.objects.count(),
        0,
    ),
    "ServiceSource": (
        ServiceSource.objects.count(),
        0,
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects.count(),
        0,
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects.count(),
        0,
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count(),
        0,
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count(),
        0,
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count(),
        0,
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects.count(),
        0,
    ),
}

failed = False

for name, (actual, wanted) in expected.items():
    print(f"{name}: {actual}")

    if actual != wanted:
        failed = True

batch = ImportBatch.objects.get(pk=5)

print(
    "ImportBatch #5 rows:",
    batch.rows.count(),
)

if batch.rows.count() != 478:
    failed = True

if failed:
    raise SystemExit(
        "STOPPED SAFELY: database state "
        "does not match approved pre-import state."
    )

print(
    "PASS: pre-freeze database state verified."
)
PY


echo ""
echo "===== DJANGO CHECK ====="

python manage.py check


echo ""
echo "===== MIGRATION CHECK ====="

python manage.py makemigrations \
    --check \
    --dry-run


# ============================================================
# 2. CREATE IMMUTABLE V2 CONTRACT + MANIFEST
# ============================================================

python - <<'PY'
import hashlib
import json
from pathlib import Path


AUDIT_DIR = Path(
    "confidential_source/audit"
)

V1_PATH = (
    AUDIT_DIR
    / "step10_mapping_contract_v1.json"
)

V2_PATH = (
    AUDIT_DIR
    / "step10_mapping_contract_v2.json"
)

V2_HASH_PATH = (
    AUDIT_DIR
    / "step10_mapping_contract_v2.json.sha256"
)

MANIFEST_PATH = (
    AUDIT_DIR
    / "step10l_final_import_plan_manifest.json"
)

MANIFEST_HASH_PATH = (
    AUDIT_DIR
    / "step10l_final_import_plan_manifest.json.sha256"
)

SAFE_REPORT = (
    AUDIT_DIR
    / "step10l_contract_v2_SAFE_TO_SHARE.txt"
)


EXPECTED_V1_HASH = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)

SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


def sha256_bytes(data):
    return hashlib.sha256(
        data
    ).hexdigest()


def canonical_json(data):
    return (
        json.dumps(
            data,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
        )
        + "\n"
    ).encode(
        "utf-8"
    )


# ------------------------------------------------------------
# Verify v1
# ------------------------------------------------------------

if not V1_PATH.exists():
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 missing."
    )


v1_bytes = V1_PATH.read_bytes()

v1_hash = sha256_bytes(
    v1_bytes
)


if v1_hash != EXPECTED_V1_HASH:
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 changed."
    )


# ============================================================
# MAPPING CONTRACT V2
# ============================================================

contract = {

    "contract": {
        "name": (
            "BharatNXT Wave Whole-Workbook "
            "Mapping Contract"
        ),
        "version": 2,
        "supersedes_version": 1,
        "previous_contract_sha256": (
            EXPECTED_V1_HASH
        ),
        "purpose": (
            "Deterministic transformation of "
            "approved BharatNXT Wave workbook "
            "staging data into Toolkit models."
        ),
    },


    # ========================================================
    # APPROVED SOURCE
    # ========================================================

    "source": {
        "import_batch_id": 5,
        "approved_workbook_sha256": (
            SOURCE_SHA256
        ),
        "total_staged_rows": 478,
        "structured_rows": 113,
        "nonstandard_rows": 365,
        "original_workbook_retained_by_toolkit": False,
        "staged_source_payload_retained": True,
        "import_requires_exact_source_hash": True,
    },


    # ========================================================
    # FINAL SERVICE UNIVERSE
    # ========================================================

    "service_universe": {

        "planned_new_unique_services": 162,

        "structured_canonical_services": 100,

        "commercial_unique_labels": 61,

        "structured_commercial_overlap": 1,

        "additional_commercial_services": 60,

        "new_rolling_grant_services": 2,

        "benefit_keys_promoted_to_services": 0,

        "knowledge_rows_promoted_to_services": 0,

        "existing_live_title_collisions": 0,

        "initial_service_status": "DRAFT",

        "activation_policy": (
            "Services remain DRAFT until "
            "full import QA, permissions QA, "
            "search QA and browser runtime QA pass."
        ),
    },


    # ========================================================
    # SERVICE IDENTITY
    # ========================================================

    "identity": {

        "normalization": [
            "casefold",
            "ampersand_to_and",
            "underscore_and_slash_to_space",
            "non_alphanumeric_to_space",
            "collapse_whitespace",
        ],

        "structured_identity_field": (
            "scheme_name"
        ),

        "commercial_identity_column": (
            "AMOUNT DEDUCTIONS!A"
        ),

        "rolling_identity_column": (
            "Rolling_Grants!A"
        ),

        "blank_structured_identity_policy": (
            "RETAIN_IMPORT_ROW_AND_EXCLUDE_SERVICE"
        ),

        "structured_blank_identity_count": 1,

        "duplicate_structured_policy": (
            "ONE_CANONICAL_SERVICE_MULTIPLE_LINEAGE_ROWS"
        ),

        "structured_duplicate_groups": 9,

        "structured_duplicate_source_rows": 21,

        "service_id_algorithm": (
            "BNXT-SVC- + first 12 uppercase hex "
            "characters of SHA256(normalized_identity)"
        ),

        "slug_policy": (
            "slugify source title; append deterministic "
            "identity hash suffix if required for uniqueness"
        ),
    },


    # ========================================================
    # PRIMARY SERVICE KIND
    # ========================================================

    "service_kind": {

        "structured_result_counts": {
            "CERTIFICATION": 5,
            "EQUITY": 14,
            "GOVT_SCHEME": 47,
            "GRANT": 31,
            "LOAN": 2,
            "SUBSIDY": 1,
        },

        "commercial_additional_result_counts": {
            "CERTIFICATION": 10,
            "REGISTRATION": 10,
            "OTHER": 40,
        },

        "rolling_grant_result_counts": {
            "GRANT": 2,
        },

        "structured_resolution": {
            "single_source_semantic_signal": (
                "use exact recognized service kind"
            ),
            "unanimous_source_sheet_fallback": (
                "use approved source-family primary kind"
            ),
            "mixed_source_family": (
                "GOVT_SCHEME with component classifications"
            ),
        },

        "commercial_resolution": {
            "certificate_or_certification_signal": (
                "CERTIFICATION"
            ),
            "registration_or_incorporation_signal": (
                "REGISTRATION"
            ),
            "no_trustworthy_signal": (
                "OTHER"
            ),
            "no_invented_subtype": True,
        },

        "rolling_grant_resolution": "GRANT",
    },


    # ========================================================
    # EXISTING DOMAIN VOCABULARY
    # ========================================================

    "domains": {

        "create_new_domains": False,

        "required_existing_slugs": [
            "business-incorporation-and-launch",
            "compliance-management",
            "licenses-registrations-and-certifications",
            "government-schemes-and-grants",
            "funding-and-equity-support",
            "legal-drafting-and-contracts",
            "branding-website-and-digital-presence",
            "business-strategy-and-growth-consulting",
        ],
    },


    # ========================================================
    # CATEGORY CREATION PLAN
    # ========================================================

    "categories": {

        "existing_before_import": 32,

        "new_categories_to_create": [

            {
                "name": "Agriculture Schemes",
                "slug": "agriculture-schemes",
                "domain": (
                    "government-schemes-and-grants"
                ),
                "display_order": 5,
            },

            {
                "name": "NGO-Focused Schemes",
                "slug": "ngo-focused-schemes",
                "domain": (
                    "government-schemes-and-grants"
                ),
                "display_order": 6,
            },

            {
                "name": "Women-Focused Schemes",
                "slug": "women-focused-schemes",
                "domain": (
                    "government-schemes-and-grants"
                ),
                "display_order": 7,
            },

            {
                "name": "Equity Funding",
                "slug": "equity-funding",
                "domain": (
                    "funding-and-equity-support"
                ),
                "display_order": 5,
            },

            {
                "name": "Debt Funding",
                "slug": "debt-funding",
                "domain": (
                    "funding-and-equity-support"
                ),
                "display_order": 6,
            },

            {
                "name": "Funding Programs",
                "slug": "funding-programs",
                "domain": (
                    "funding-and-equity-support"
                ),
                "display_order": 7,
            },

            {
                "name": "Mixed Finance",
                "slug": "mixed-finance",
                "domain": (
                    "funding-and-equity-support"
                ),
                "display_order": 8,
            },

            {
                "name": "Other Business Services",
                "slug": "other-business-services",
                "domain": (
                    "business-strategy-and-growth-consulting"
                ),
                "display_order": 5,
            },
        ],

        "new_category_count": 8,

        "expected_category_count_after_creation": 40,
    },


    # ========================================================
    # STRUCTURED PRIMARY DOMAIN/CATEGORY
    # ========================================================

    "structured_primary_mapping": {

        "CERTIFICATION": {
            "domain": (
                "licenses-registrations-and-certifications"
            ),
            "category": "certifications",
        },

        "EQUITY": {
            "domain": (
                "funding-and-equity-support"
            ),
            "category": "equity-funding",
        },

        "GOVT_SCHEME": {
            "domain": (
                "government-schemes-and-grants"
            ),
            "category": "sector-specific-schemes",
        },

        "GRANT": {
            "domain": (
                "government-schemes-and-grants"
            ),
            "category": "government-grants",
        },

        "LOAN": {
            "domain": (
                "government-schemes-and-grants"
            ),
            "category": (
                "credit-and-guarantee-schemes"
            ),
        },

        "SUBSIDY": {
            "domain": (
                "government-schemes-and-grants"
            ),
            "category": "state-subsidies",
        },

        "DEBT": {
            "domain": (
                "funding-and-equity-support"
            ),
            "category": "debt-funding",
        },
    },


    # ========================================================
    # COMMERCIAL PRIMARY CATEGORY
    # ========================================================

    "commercial_primary_category": {

        "additional_commercial_services": 60,

        "title_signal_resolved": 26,

        "generic_category_required": 34,

        "generic_fallback": {
            "service_kind": "OTHER",
            "domain": (
                "business-strategy-and-growth-consulting"
            ),
            "category": "other-business-services",
        },

        "multiple_category_signal_count": 2,

        "multiple_signal_policy": (
            "Apply fixed most-specific category precedence "
            "for primary category and retain every additional "
            "matched category as ServiceClassification."
        ),

        "precedence": [
            "trademark-and-intellectual-property",
            "gst-and-tax-compliance",
            "annual-and-roc-compliance",
            "labour-law-compliance",
            "audit-and-reporting",
            "certifications",
            "licenses",
            "company-incorporation",
            "startup-and-msme-recognition",
            "trade-and-business-registrations",
            "pitch-deck-and-financial-model",
            "valuation",
            "data-room-and-fundraise-readiness",
            "investor-connect",
            "government-grants",
            "credit-and-guarantee-schemes",
            "state-subsidies",
            "founder-agreements",
            "ndas-and-commercial-contracts",
            "vendor-and-partnership-agreements",
            "hr-and-employment-policies",
            "seo",
            "social-media",
            "website-development",
            "branding-and-identity",
            "digital-marketing",
            "hiring-and-hr-systems",
            "pricing-strategy",
            "go-to-market-strategy",
            "scaling-and-growth",
            "business-registrations",
        ],
    },


    # ========================================================
    # SECONDARY CLASSIFICATIONS
    # ========================================================

    "classifications": {

        "reuse_existing": {
            "Grant": "government-grants",
            "Loan": "credit-and-guarantee-schemes",
            "Subsidy": "state-subsidies",
            "Certification": "certifications",
        },

        "new": {
            "Agriculture": "agriculture-schemes",
            "Debt": "debt-funding",
            "Equity": "equity-funding",
            "Funding": "funding-programs",
            "Mixed Finance": "mixed-finance",
            "NGO": "ngo-focused-schemes",
            "Women": "women-focused-schemes",
        },

        "source_sheet_taxonomy": {

            "GRANT": [
                "Grant"
            ],

            "Women_GRANT": [
                "Grant",
                "Women"
            ],

            "Agriculture_FUND": [
                "Agriculture",
                "Funding"
            ],

            "NGO_GRANT": [
                "Grant",
                "NGO"
            ],

            "EQUITY": [
                "Equity"
            ],

            "GRANTDEBTEQUITY": [
                "Grant",
                "Debt",
                "Equity",
                "Mixed Finance"
            ],

            "DEBTEQUITY": [
                "Debt",
                "Equity",
                "Mixed Finance"
            ],

            "LOAN ONLY": [
                "Loan"
            ],

            "LOANSUBSIDY": [
                "Loan",
                "Subsidy",
                "Mixed Finance"
            ],

            "CERTGEM": [
                "Certification"
            ],
        },

        "do_not_duplicate_primary_category_as_classification": True,
    },


    # ========================================================
    # STRUCTURED FIELD MAPPING
    # ========================================================

    "structured_fields": {

        "scheme_name": "Service.title",

        "benefits": "Service.benefits",

        "eligibility": (
            "Service.eligibility_summary"
        ),

        "funding_organisation": (
            "Service.funding_organisation"
        ),

        "applicable_for": (
            "Service.applicable_for_raw"
        ),

        "deadline": [
            "Service.application_deadline_raw",
            "Service.application_deadline",
            "Service.deadline_status",
        ],

        "focus_sectors": (
            "taxonomy/source preservation; "
            "do not blindly convert to industries JSON"
        ),

        "scheme_type": (
            "service-kind resolution input; "
            "raw source remains in ImportRow"
        ),

        "portal_link": (
            "ServiceSource"
        ),

        "flyer": (
            "ServiceSource"
        ),

        "minimum_charge": (
            "ServiceCommercial.minimum_charge_raw"
        ),

        "government_charge": (
            "ServiceCommercial.government_fee_raw "
            "only where source header semantics are unambiguous"
        ),

        "additional_info": (
            "hyperlink -> ServiceSource; "
            "text -> source/content review"
        ),
    },


    # ========================================================
    # DEADLINE POLICY
    # ========================================================

    "deadlines": {

        "always_preserve_raw": True,

        "excel_date": {
            "deadline_status": "DATED",
            "normalize_date": True,
        },

        "rolling_text": {
            "deadline_status": "ROLLING",
            "normalize_date": False,
        },

        "ongoing_text": {
            "deadline_status": "ONGOING",
            "normalize_date": False,
        },

        "open_text": {
            "deadline_status": "OPEN",
            "normalize_date": False,
        },

        "closed_text": {
            "deadline_status": "CLOSED",
            "normalize_date": False,
        },

        "no_deadline_text": {
            "deadline_status": "NO_DEADLINE",
            "normalize_date": False,
        },

        "date_like_text": {
            "deadline_status": "OTHER",
            "normalize_date": False,
        },

        "other_text": {
            "deadline_status": "OTHER",
            "normalize_date": False,
        },

        "never_invent_deadline": True,
    },


    # ========================================================
    # CERTGEM EXCEPTION
    # ========================================================

    "known_structural_exceptions": {

        "CERTGEM_source_row_7": {
            "issue": (
                "deadline and funding organisation "
                "resolve to same source coordinate"
            ),
            "service_creation": "ALLOWED",
            "funding_organisation": (
                "DO_NOT_POPULATE_FROM_COLLIDING_CELL"
            ),
            "source_lineage": "RETAIN",
            "review_flag": (
                "funding_organisation_coordinate_collision"
            ),
        },

        "GRANT_source_row_7": {
            "issue": "scheme name missing",
            "service_creation": "EXCLUDED",
            "source_lineage": "RETAIN",
            "review_flag": (
                "missing_scheme_name"
            ),
        },
    },


    # ========================================================
    # ROLLING GRANTS
    # ========================================================

    "rolling_grants": {

        "rows": 7,

        "existing_structured_matches": 5,

        "new_services": 2,

        "new_service_kind": "GRANT",

        "new_service_domain": (
            "government-schemes-and-grants"
        ),

        "new_service_category": (
            "government-grants"
        ),

        "column_mapping": {
            "A": "title",
            "B": "benefits",
            "C": "focus_sectors",
            "E": "eligibility_summary",
        },

        "new_candidate_completeness": (
            "A_B_C_E_ALL_PRESENT"
        ),
    },


    # ========================================================
    # COMMERCIAL DATA
    # ========================================================

    "commercial": {

        "source_sheet": (
            "AMOUNT DEDUCTIONS"
        ),

        "data_rows": 62,

        "unique_labels": 61,

        "all_rows_have_commercial_evidence": True,

        "destination": (
            "ServiceCommercial"
        ),

        "one_record_per_source_row": True,

        "default_visibility": (
            "ADMIN_ONLY"
        ),

        "column_mapping": {

            "A": (
                "service identity / label"
            ),

            "B": (
                "minimum_charge_raw"
            ),

            "C": (
                "vendor_cost_raw as RAW COMBINED "
                "'Govt. Fees / Vendor Cost' source bucket"
            ),

            "D": (
                "bdm_deduction_raw"
            ),

            "E": (
                "remarks"
            ),
        },

        "column_c_semantic_warning": (
            "Do not interpret AMOUNT DEDUCTIONS "
            "Column C as vendor-only or government-only. "
            "It is a combined raw source field."
        ),

        "numeric_auto_parse": False,

        "minimum_charge_numeric": None,

        "government_fee_numeric": None,

        "vendor_cost_numeric": None,

        "bdm_deduction_numeric": None,

        "never_copy_commercial_values_to_legacy_Service_fee_fields": True,

        "bde_visibility_requires_explicit_future_approval": True,
    },


    # ========================================================
    # AMOUNT DEDUCTIONS REFERENCE SIDE
    # ========================================================

    "commercial_reference_side": {

        "source_sheet": (
            "AMOUNT DEDUCTIONS"
        ),

        "columns": {
            "G": "STANDARDS",
            "H": "SHORT_OR_FULL_NAME",
            "I": "INDUSTRIES",
            "J": "IAF_IAS",
            "K": "NON_IAF",
        },

        "destination": "ReferenceItem",

        "record_policy": (
            "one ReferenceItem per nonblank source cell"
        ),

        "default_visibility": (
            "ADMIN_ONLY"
        ),

        "retain_source_import_row": True,
    },


    # ========================================================
    # BENEFITS
    # ========================================================

    "benefits_reference": {

        "source_sheet": "BENEFITS",

        "data_rows": 44,

        "destination": "ReferenceItem",

        "dataset_name": (
            "BENEFITS"
        ),

        "key_column": "A",

        "value_column": "B",

        "default_visibility": "BDE",

        "create_service_from_key": False,

        "retain_source_import_row": True,
    },


    # ========================================================
    # LOAN COMPARISON MATRIX
    # ========================================================

    "loan_comparison": {

        "source_sheet": "LOAN",

        "title_rows": 1,

        "header_rows": 1,

        "data_rows": 21,

        "matrix_destination": (
            "ComparisonMatrix"
        ),

        "entry_destination": (
            "ComparisonEntry"
        ),

        "entry_policy": (
            "create one entry for each nonblank "
            "data-cell using source header as column_name"
        ),

        "retain_raw_values": True,

        "numeric_auto_parse": False,

        "retain_source_import_row": True,
    },


    # ========================================================
    # KNOWLEDGE
    # ========================================================

    "knowledge": {

        "source_sheets": {
            "START_UP INDIA": 43,
            "TAX_CERT": 22,
            "SEED FUND": 41,
            "PVT": 62,
            "LLP": 39,
        },

        "total_rows": 207,

        "destination": (
            "ServiceContentSection"
        ),

        "anchor_result": {
            "high_confidence_direct": 3,
            "resolved_by_content_evidence": 2,
            "unresolved": 0,
        },

        "anchor_identity_storage": (
            "detailed import manifest uses deterministic "
            "identity hashes; names are not logged"
        ),

        "section_heading_source": (
            "hash-verified workbook formatting metadata"
        ),

        "content_source": (
            "staged ImportRow payload"
        ),

        "display_order": (
            "source row order"
        ),

        "default_visibility": "BDE",

        "retain_source_import_row": True,
    },


    # ========================================================
    # ONBOARDING MAIL
    # ========================================================

    "onboarding_mail": {

        "source_sheet": (
            "ONBOARDING_MAIL"
        ),

        "content_rows": 20,

        "destination": (
            "CommunicationTemplate"
        ),

        "template_count": 1,

        "subject_prefix_rows_detected": 1,

        "body_reconstruction": (
            "preserve source row ordering and "
            "blank-line gaps from source row numbers"
        ),

        "initial_status": "DRAFT",

        "initial_visibility": (
            "ADMIN_ONLY"
        ),

        "activation_requires_qa": True,
    },


    # ========================================================
    # SOURCES / LINEAGE
    # ========================================================

    "service_sources": {

        "destination": (
            "ServiceSource"
        ),

        "portal": {
            "source_kind": "APPLICATION",
            "prefer_excel_hyperlink_target": True,
            "formula_hyperlink_requires_safe_parse": True,
            "plain_url_requires_validation": True,
        },

        "flyer": {
            "source_kind": "FLYER",
            "prefer_excel_hyperlink_target": True,
        },

        "additional_info_hyperlink": {
            "source_kind": "REFERENCE",
        },

        "multiple_urls_allowed": True,

        "all_sources_link_to_import_row": True,

        "never_invent_url": True,
    },


    # ========================================================
    # SECURITY / VISIBILITY
    # ========================================================

    "security": {

        "commercial_default": "ADMIN_ONLY",

        "amount_deductions_reference_default": (
            "ADMIN_ONLY"
        ),

        "benefits_reference_default": "BDE",

        "knowledge_default": "BDE",

        "communication_initial_visibility": (
            "ADMIN_ONLY"
        ),

        "import_row_payload_exposed_to_bde": False,

        "original_workbook_exposed_to_bde": False,

        "bdm_deduction_exposed_to_bde": False,
    },


    # ========================================================
    # IMPORT TRANSACTION / ROLLBACK
    # ========================================================

    "transaction": {

        "database_transaction": (
            "transaction.atomic"
        ),

        "pre_import_database_backup_required": True,

        "pre_import_integrity_check_required": True,

        "import_batch_status_during_write": (
            "IMPORTING"
        ),

        "import_batch_status_on_success": (
            "IMPORTED"
        ),

        "record_every_created_or_changed_object": (
            "ImportChange"
        ),

        "rollback_supported": True,

        "rollback_must_reverse_import_changes": True,

        "delete_imported_batch_directly": False,

        "activation_separate_from_import": True,
    },


    # ========================================================
    # NON-INVENTION GUARANTEES
    # ========================================================

    "non_invention_guarantees": [
        "Do not invent Service titles.",
        "Do not invent eligibility.",
        "Do not invent benefits.",
        "Do not invent deadlines.",
        "Do not invent source URLs.",
        "Do not infer numeric fees from mixed text.",
        "Do not expose BDM deduction data to BDE users.",
        "Do not discard conflicting source rows.",
        "Do not convert ambiguous focus sector text into industries automatically.",
        "Do not silently merge different Service identities.",
    ],
}


contract_bytes = canonical_json(
    contract
)

contract_hash = sha256_bytes(
    contract_bytes
)


if V2_PATH.exists():

    existing = (
        V2_PATH.read_bytes()
    )

    if existing != contract_bytes:

        raise SystemExit(
            "STOPPED SAFELY: Mapping Contract v2 "
            "already exists with different content. "
            "Do not overwrite a frozen contract."
        )

else:

    V2_PATH.write_bytes(
        contract_bytes
    )


V2_HASH_PATH.write_text(
    f"{contract_hash}  "
    f"{V2_PATH.name}\n",
    encoding="utf-8",
)


# ============================================================
# FINAL IMPORT PLAN MANIFEST
# ============================================================

manifest = {

    "manifest": {
        "name": (
            "BharatNXT Wave Final Import Plan"
        ),
        "version": 1,
        "mapping_contract_version": 2,
        "mapping_contract_sha256": (
            contract_hash
        ),
    },

    "source": {
        "import_batch_id": 5,
        "workbook_sha256": (
            SOURCE_SHA256
        ),
        "staged_rows": 478,
    },

    "planned_database_changes": {

        "Service": {
            "create": 162,
            "update_existing": 0,
            "existing_untouched": 1,
            "expected_total_if_existing_retained": 163,
            "initial_status": "DRAFT",
        },

        "ServiceDomain": {
            "create": 0,
            "expected_total": 8,
        },

        "Category": {
            "create": 8,
            "expected_total": 40,
        },

        "ServiceClassification": {
            "create": (
                "calculated by transformation engine "
                "from source taxonomy; duplicates suppressed"
            ),
        },

        "ServiceSource": {
            "create": (
                "calculated from verified portal, flyer "
                "and reference hyperlinks"
            ),
        },

        "ServiceCommercial": {
            "create_from_source_rows": 62,
            "visibility": "ADMIN_ONLY",
        },

        "ReferenceItem": {
            "benefits_rows": 44,
            "additional_amount_deduction_reference_cells": (
                "calculated from nonblank G-K source cells"
            ),
        },

        "ComparisonMatrix": {
            "create": 1,
        },

        "ComparisonEntry": {
            "create": (
                "one per nonblank LOAN matrix data cell"
            ),
        },

        "ServiceContentSection": {
            "source_content_rows": 207,
            "source_documents": 5,
            "create": (
                "calculated after heading-based section parsing"
            ),
        },

        "CommunicationTemplate": {
            "create": 1,
            "initial_status": "DRAFT",
            "initial_visibility": "ADMIN_ONLY",
        },

        "ImportChange": {
            "create": (
                "one audit record per reversible imported change"
            ),
        },
    },

    "service_breakdown": {

        "structured": 100,

        "commercial_additional": 60,

        "rolling_grants_additional": 2,

        "final_unique_services": 162,

        "kind_totals": {
            "CERTIFICATION": 15,
            "EQUITY": 14,
            "GOVT_SCHEME": 47,
            "GRANT": 33,
            "LOAN": 2,
            "SUBSIDY": 1,
            "REGISTRATION": 10,
            "OTHER": 40,
        },
    },

    "new_categories": [
        "agriculture-schemes",
        "ngo-focused-schemes",
        "women-focused-schemes",
        "equity-funding",
        "debt-funding",
        "funding-programs",
        "mixed-finance",
        "other-business-services",
    ],

    "hard_preconditions": [
        "Mapping Contract v2 SHA-256 must match.",
        "Source workbook SHA-256 must match.",
        "Import Batch #5 must contain 478 ImportRows.",
        "Service count must remain 1 before live import.",
        "ServiceDomain count must remain 8.",
        "Category count must remain 32.",
        "Destination import tables must remain empty.",
        "A verified SQLite backup must exist before write.",
        "SQLite integrity_check must return ok.",
        "foreign_key_check must return zero rows.",
    ],

    "post_import_gate": {
        "activate_services": False,
        "next_phase": (
            "full database verification and browser QA"
        ),
    },
}


manifest_bytes = canonical_json(
    manifest
)

manifest_hash = sha256_bytes(
    manifest_bytes
)


if MANIFEST_PATH.exists():

    existing = (
        MANIFEST_PATH.read_bytes()
    )

    if existing != manifest_bytes:

        raise SystemExit(
            "STOPPED SAFELY: final import plan "
            "manifest already exists with "
            "different content."
        )

else:

    MANIFEST_PATH.write_bytes(
        manifest_bytes
    )


MANIFEST_HASH_PATH.write_text(
    f"{manifest_hash}  "
    f"{MANIFEST_PATH.name}\n",
    encoding="utf-8",
)


# ============================================================
# SAFE REPORT
# ============================================================

lines = [

    "=" * 80,

    (
        "BHARATNXT WAVE — "
        "STEP 10L CONTRACT V2 FREEZE"
    ),

    "=" * 80,

    "",

    (
        "Mapping Contract v1 "
        "SHA-256 verified: YES"
    ),

    (
        f"Mapping Contract v2 SHA-256: "
        f"{contract_hash}"
    ),

    (
        f"Final Import Plan SHA-256: "
        f"{manifest_hash}"
    ),

    "",

    "1. FINAL SERVICE UNIVERSE",

    "  Structured Services: 100",

    "  Additional commercial Services: 60",

    "  New Rolling Grant Services: 2",

    "  Final unique Services planned: 162",

    "  Existing title collisions: 0",

    "",

    "2. PRIMARY SERVICE KIND TOTALS",

    "  CERTIFICATION: 15",

    "  EQUITY: 14",

    "  GOVT_SCHEME: 47",

    "  GRANT: 33",

    "  LOAN: 2",

    "  SUBSIDY: 1",

    "  REGISTRATION: 10",

    "  OTHER: 40",

    "",

    "3. CATEGORY PLAN",

    "  Existing domains reused: 8",

    "  New domains: 0",

    "  Existing categories before import: 32",

    "  New categories planned: 8",

    "  Expected categories after import: 40",

    "  Generic Other Business Services used by: 34 commercial Services",

    "",

    "4. SUPPORTING WORKBOOK DATA",

    "  BENEFITS ReferenceItem rows: 44",

    "  AMOUNT DEDUCTIONS commercial rows: 62",

    "  LOAN comparison matrices: 1",

    "  LOAN comparison data rows: 21",

    "  Knowledge source documents: 5",

    "  Knowledge source rows: 207",

    "  ONBOARDING_MAIL templates planned: 1",

    "",

    "5. SECURITY",

    "  Commercial visibility: ADMIN_ONLY",

    "  BDM deduction visible to BDE: NO",

    "  ImportRow raw payload visible to BDE: NO",

    "  Original workbook visible to BDE: NO",

    "",

    "6. IMPORT BEHAVIOUR",

    "  Live Service writes performed now: 0",

    "  Category writes performed now: 0",

    "  ImportRow writes performed now: 0",

    "  Transactional import required: YES",

    "  Pre-import database backup required: YES",

    "  ImportChange rollback ledger required: YES",

    "  Imported Services initially DRAFT: YES",

    "  BDE activation during import: NO",

    "",

    "7. CONTRACT STATUS",

    "  Mapping Contract v2: FROZEN",

    "  Final Import Plan: FROZEN",

    "  General workbook architecture discovery: COMPLETE",

    "  Next phase: BUILD TRANSACTIONAL TRANSFORMATION / IMPORT ENGINE",
]


SAFE_REPORT.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "MAPPING CONTRACT V2 FROZEN"
)

print(
    f"Contract SHA-256: "
    f"{contract_hash}"
)

print(
    f"Manifest SHA-256: "
    f"{manifest_hash}"
)

print(
    f"SAFE REPORT: "
    f"{SAFE_REPORT}"
)
PY


# Best-effort read-only flags.
# SHA-256 remains the real integrity guard on /mnt/d.

chmod 444 \
    confidential_source/audit/step10_mapping_contract_v2.json \
    confidential_source/audit/step10_mapping_contract_v2.json.sha256 \
    confidential_source/audit/step10l_final_import_plan_manifest.json \
    confidential_source/audit/step10l_final_import_plan_manifest.json.sha256 \
    confidential_source/audit/step10l_contract_v2_SAFE_TO_SHARE.txt \
    2>/dev/null || true


echo ""
echo "===== CONTRACT V2 HASH ====="

cat \
    confidential_source/audit/step10_mapping_contract_v2.json.sha256


echo ""
echo "===== IMPORT PLAN HASH ====="

cat \
    confidential_source/audit/step10l_final_import_plan_manifest.json.sha256


echo ""
echo "===== SAFE REPORT ====="

cat \
    confidential_source/audit/step10l_contract_v2_SAFE_TO_SHARE.txt


echo ""
echo "===== FINAL DJANGO CHECK ====="

python manage.py check


echo ""
echo "===== FINAL MIGRATION CHECK ====="

python manage.py makemigrations \
    --check \
    --dry-run


echo ""
echo "============================================================"
echo "STEP 10L SUCCESS"
echo "============================================================"
