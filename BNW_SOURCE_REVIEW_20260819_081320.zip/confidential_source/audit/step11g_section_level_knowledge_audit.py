import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.importing.transformation import (
    build_core_transformation_plan,
    load_verified_context,
    normalize_identity,
)

from toolkit.importing.supporting_transformation import (
    find_verified_workbook,
    knowledge_heading_rows,
    row_text,
)

from toolkit.models import (
    Category,
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ServiceDomain,
    ServiceSource,
)


KNOWLEDGE_SHEETS = (
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
)


def anonymous_id(identity):
    return (
        "SVC-"
        + hashlib.sha256(
            identity.encode("utf-8")
        ).hexdigest()[:10].upper()
    )


def tokens(value):
    return set(
        normalize_identity(
            value
        ).split()
    )


def candidate_score(
    heading,
    section_rows,
    identity,
):
    heading_normalized = normalize_identity(
        heading
    )

    identity_normalized = normalize_identity(
        identity
    )

    if not heading_normalized:
        return 0

    if (
        heading_normalized
        == identity_normalized
    ):
        return 1200

    heading_tokens = tokens(
        heading
    )

    identity_tokens = tokens(
        identity
    )

    if not (
        heading_tokens
        and identity_tokens
    ):
        return 0

    shared = (
        heading_tokens
        & identity_tokens
    )

    title_coverage = (
        len(shared)
        / len(identity_tokens)
    )

    heading_coverage = (
        len(shared)
        / len(heading_tokens)
    )

    union = (
        heading_tokens
        | identity_tokens
    )

    jaccard = (
        len(shared)
        / len(union)
        if union
        else 0
    )

    sequence = SequenceMatcher(
        None,
        heading_normalized,
        identity_normalized,
    ).ratio()

    score = 0

    # Strong multi-token containment.
    if (
        len(identity_tokens) >= 2
        and identity_tokens.issubset(
            heading_tokens
        )
    ):
        score += 850

    elif (
        len(heading_tokens) >= 2
        and heading_tokens.issubset(
            identity_tokens
        )
    ):
        score += 825

    score += int(
        title_coverage
        * 300
    )

    score += int(
        heading_coverage
        * 220
    )

    score += int(
        jaccard
        * 180
    )

    score += int(
        sequence
        * 120
    )

    # Body evidence.
    body_hits = 0

    if len(
        identity_tokens
    ) >= 2:

        for row in section_rows:

            text_tokens = tokens(
                row_text(
                    row
                )
            )

            if identity_tokens.issubset(
                text_tokens
            ):
                body_hits += 1

    score += min(
        160,
        body_hits * 20,
    )

    # Discourage generic single-word identities.
    if len(
        identity_tokens
    ) == 1:
        score -= 100

    return score


def snapshot():
    return {
        "Service":
            Service.objects.count(),

        "ServiceDomain":
            ServiceDomain.objects.count(),

        "Category":
            Category.objects.count(),

        "ImportRow":
            ImportRow.objects.count(),

        "ImportChange":
            ImportChange.objects.count(),

        "ServiceClassification":
            ServiceClassification.objects.count(),

        "ServiceSource":
            ServiceSource.objects.count(),

        "ServiceCommercial":
            ServiceCommercial.objects.count(),

        "ServiceContentSection":
            ServiceContentSection.objects.count(),

        "ReferenceItem":
            ReferenceItem.objects.count(),

        "ComparisonMatrix":
            ComparisonMatrix.objects.count(),

        "ComparisonEntry":
            ComparisonEntry.objects.count(),

        "CommunicationTemplate":
            CommunicationTemplate.objects.count(),
    }


EXPECTED_DB = {
    "Service": 1,
    "ServiceDomain": 8,
    "Category": 32,
    "ImportRow": 478,
    "ImportChange": 0,
    "ServiceClassification": 0,
    "ServiceSource": 0,
    "ServiceCommercial": 0,
    "ServiceContentSection": 0,
    "ReferenceItem": 0,
    "ComparisonMatrix": 0,
    "ComparisonEntry": 0,
    "CommunicationTemplate": 0,
}


before = snapshot()

if before != EXPECTED_DB:
    raise SystemExit(
        "STOPPED SAFELY: database state changed."
    )


contract, batch, staged_rows = (
    load_verified_context()
)

core = (
    build_core_transformation_plan()
)

services = core[
    "services"
]

if len(services) != 162:
    raise SystemExit(
        "STOPPED SAFELY: expected 162 Services."
    )


workbook_path = (
    find_verified_workbook()
)

heading_map = (
    knowledge_heading_rows(
        workbook_path,
        staged_rows,
    )
)


all_results = {}

total_sections = 0
total_rows = 0

status_counts = Counter()


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    rows = sorted(
        [
            row
            for row in staged_rows
            if row.sheet_name
            == sheet_name
        ],
        key=lambda row: (
            row.source_row_number,
            row.id,
        ),
    )

    total_rows += len(
        rows
    )

    heading_numbers = (
        heading_map[
            sheet_name
        ]
    )

    sections = []

    current = None

    for row in rows:

        is_heading = (
            row.source_row_number
            in heading_numbers
        )

        if (
            is_heading
            or current is None
        ):

            if current:
                sections.append(
                    current
                )

            current = {
                "heading_row":
                    (
                        row.source_row_number
                        if is_heading
                        else None
                    ),

                "heading":
                    (
                        row_text(row)
                        if is_heading
                        else ""
                    ),

                "rows": [],
            }

        current[
            "rows"
        ].append(
            row
        )

    if current:
        sections.append(
            current
        )

    total_sections += len(
        sections
    )

    sheet_results = []

    for section_number, section in enumerate(
        sections,
        start=1,
    ):

        heading = section[
            "heading"
        ]

        # If content appears before the first
        # detected heading, use first row only
        # as a matching hint.
        if not heading:
            heading = row_text(
                section[
                    "rows"
                ][0]
            )

        ranked = []

        for identity, plan in (
            services.items()
        ):

            score = candidate_score(
                heading,
                section[
                    "rows"
                ],
                identity,
            )

            ranked.append(
                (
                    score,
                    identity,
                    plan,
                )
            )

        ranked.sort(
            key=lambda item: (
                item[0],
                len(
                    tokens(
                        item[1]
                    )
                ),
            ),
            reverse=True,
        )

        top_score = ranked[
            0
        ][0]

        second_score = ranked[
            1
        ][0]

        gap = (
            top_score
            - second_score
        )

        if (
            top_score >= 1050
            and gap >= 100
        ):
            status = (
                "HIGH_CONFIDENCE"
            )

        elif (
            top_score >= 800
            and gap >= 120
        ):
            status = (
                "HIGH_CONFIDENCE"
            )

        elif top_score >= 450:
            status = (
                "AMBIGUOUS"
            )

        else:
            status = (
                "UNMATCHED"
            )

        status_counts[
            status
        ] += 1

        sheet_results.append(
            {
                "section_number":
                    section_number,

                "source_rows":
                    len(
                        section[
                            "rows"
                        ]
                    ),

                "status":
                    status,

                "top_id":
                    anonymous_id(
                        ranked[
                            0
                        ][1]
                    ),

                "top_score":
                    top_score,

                "runner_id":
                    anonymous_id(
                        ranked[
                            1
                        ][1]
                    ),

                "runner_score":
                    second_score,

                "gap":
                    gap,
            }
        )

    all_results[
        sheet_name
    ] = sheet_results


# ============================================================
# MULTI-SERVICE SIGNAL
# ============================================================

high_confidence_services_by_sheet = {}

for sheet_name, results in (
    all_results.items()
):

    high_confidence_services_by_sheet[
        sheet_name
    ] = {
        result[
            "top_id"
        ]
        for result in results
        if result[
            "status"
        ]
        == "HIGH_CONFIDENCE"
    }


after = snapshot()

if after != before:
    raise SystemExit(
        "STOPPED SAFELY: audit changed database."
    )


output = Path(
    "confidential_source/audit/"
    "step11g_section_level_knowledge_SAFE_TO_SHARE.txt"
)


lines = [
    "=" * 80,
    (
        "BHARATNXT WAVE — "
        "STEP 11G SECTION-LEVEL KNOWLEDGE AUDIT"
    ),
    "=" * 80,
    "",
    (
        f"Mapping Contract version: "
        f"{contract['contract']['version']}"
    ),
    (
        f"Import Batch ID: "
        f"{batch.id}"
    ),
    (
        f"Knowledge rows audited: "
        f"{total_rows}"
    ),
    (
        f"Detected knowledge sections: "
        f"{total_sections}"
    ),
    "Database writes performed: NO",
    "",
    "1. SECTION RESOLUTION SUMMARY",
]


for status, count in sorted(
    status_counts.items()
):
    lines.append(
        f"  {status}: {count}"
    )


lines.extend(
    [
        "",
        "2. SHEET-LEVEL STRUCTURE",
    ]
)


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    results = (
        all_results[
            sheet_name
        ]
    )

    high = sum(
        1
        for item in results
        if item[
            "status"
        ]
        == "HIGH_CONFIDENCE"
    )

    ambiguous = sum(
        1
        for item in results
        if item[
            "status"
        ]
        == "AMBIGUOUS"
    )

    unmatched = sum(
        1
        for item in results
        if item[
            "status"
        ]
        == "UNMATCHED"
    )

    distinct_high_services = len(
        high_confidence_services_by_sheet[
            sheet_name
        ]
    )

    lines.append(
        f"  {sheet_name}"
    )

    lines.append(
        f"    sections: "
        f"{len(results)}"
    )

    lines.append(
        f"    high_confidence: "
        f"{high}"
    )

    lines.append(
        f"    ambiguous: "
        f"{ambiguous}"
    )

    lines.append(
        f"    unmatched: "
        f"{unmatched}"
    )

    lines.append(
        (
            "    distinct high-confidence "
            f"Service targets: "
            f"{distinct_high_services}"
        )
    )


lines.extend(
    [
        "",
        "3. ANONYMOUS SECTION RESULTS",
    ]
)


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    lines.append(
        f"  {sheet_name}"
    )

    for item in (
        all_results[
            sheet_name
        ]
    ):

        lines.append(
            (
                f"    section "
                f"{item['section_number']}: "
                f"{item['status']} | "
                f"rows={item['source_rows']} | "
                f"top={item['top_id']} | "
                f"score={item['top_score']} | "
                f"gap={item['gap']}"
            )
        )


lines.extend(
    [
        "",
        "4. ARCHITECTURE TEST",
        (
            "  Whole-sheet single-Service assumption "
            "required: NO"
        ),
        (
            "  Section-level Service mapping supported: YES"
        ),
        (
            "  Ambiguous sections automatically imported: NO"
        ),
        (
            "  Unmatched sections automatically discarded: NO"
        ),
        (
            "  Source ImportRows retained: YES"
        ),
        "",
        "5. DATABASE SAFETY",
    ]
)


for key, value in (
    after.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "6. RESULT",
        (
            "  SECTION-LEVEL KNOWLEDGE "
            "AUDIT COMPLETE"
        ),
        (
            "  LIVE DATABASE IMPORT: BLOCKED"
        ),
    ]
)


output.write_text(
    "\n".join(
        lines
    ),
    encoding="utf-8",
)


print(
    "STEP 11G SECTION AUDIT COMPLETE"
)

print(
    f"Knowledge rows: "
    f"{total_rows}"
)

print(
    f"Detected sections: "
    f"{total_sections}"
)

print(
    f"High confidence: "
    f"{status_counts['HIGH_CONFIDENCE']}"
)

print(
    f"Ambiguous: "
    f"{status_counts['AMBIGUOUS']}"
)

print(
    f"Unmatched: "
    f"{status_counts['UNMATCHED']}"
)

print(
    f"SAFE REPORT: {output}"
)
