import json
from pathlib import Path

SOURCE = Path(
    "confidential_source/audit/"
    "step11d_knowledge_candidates_PRIVATE.json"
)

PRIVATE_OUTPUT = Path(
    "confidential_source/audit/"
    "step11e_knowledge_anchor_selection_PRIVATE.json"
)

SAFE_OUTPUT = Path(
    "confidential_source/audit/"
    "step11e_knowledge_anchor_selection_SAFE_TO_SHARE.txt"
)

SHEETS = [
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
]

if not SOURCE.exists():
    raise SystemExit(
        "STOPPED: Step 11D candidate file is missing."
    )

data = json.loads(
    SOURCE.read_text(
        encoding="utf-8"
    )
)

rankings = data.get(
    "rankings",
    {}
)

selections = {}

print()
print("=" * 72)
print("BHARATNXT WAVE — GUIDED KNOWLEDGE MAPPING")
print("=" * 72)
print()
print("For each section:")
print("  Type 1-5 to select the correct Service.")
print("  Type 0 if none of the five is correct.")
print()


for sheet in SHEETS:

    candidates = rankings.get(
        sheet,
        []
    )

    if len(candidates) != 5:
        raise SystemExit(
            f"STOPPED: {sheet} does not have 5 candidates."
        )

    print()
    print("=" * 72)
    print(sheet)
    print("=" * 72)

    for candidate in candidates:

        print()
        print(
            f"{candidate['rank']}. "
            f"{candidate['title']}"
        )

        print(
            f"   Type: "
            f"{candidate['service_kind']}"
        )

        print(
            f"   Category: "
            f"{candidate['category_slug']}"
        )

    while True:

        print()

        answer = input(
            f"Choose the correct Service for "
            f"{sheet} [1-5, 0=STOP]: "
        ).strip()

        if answer == "0":

            print()
            print("STOPPED SAFELY.")
            print(
                "No final mapping was saved."
            )

            raise SystemExit(0)

        if answer not in {
            "1",
            "2",
            "3",
            "4",
            "5",
        }:

            print(
                "Please type only "
                "1, 2, 3, 4, 5 or 0."
            )

            continue

        chosen_rank = int(
            answer
        )

        selected = next(
            candidate
            for candidate in candidates
            if candidate["rank"]
            == chosen_rank
        )

        print()
        print(
            "Selected:"
        )

        print(
            selected["title"]
        )

        confirm = input(
            "Confirm this Service? [Y/N]: "
        ).strip().lower()

        if confirm in {
            "y",
            "yes",
        }:

            selections[sheet] = {
                "rank":
                    chosen_rank,

                "identity":
                    selected[
                        "identity"
                    ],

                "service_id":
                    selected[
                        "service_id"
                    ],

                "anonymous_id":
                    selected[
                        "anonymous_id"
                    ],

                "title":
                    selected[
                        "title"
                    ],
            }

            break

        print()
        print(
            "Selection cancelled. "
            "Choose again."
        )


# ============================================================
# SAVE PRIVATE SELECTION
# ============================================================

PRIVATE_OUTPUT.write_text(
    json.dumps(
        {
            "warning": (
                "CONFIDENTIAL — contains "
                "actual Service identities."
            ),
            "source": (
                "Step 11E human semantic selection"
            ),
            "selections":
                selections,
        },
        indent=2,
        ensure_ascii=False,
    )
    + "\n",
    encoding="utf-8",
)


# ============================================================
# SAFE REPORT
# ============================================================

selected_ids = [
    item["anonymous_id"]
    for item in selections.values()
]

lines = [
    "=" * 72,
    (
        "BHARATNXT WAVE — "
        "STEP 11E KNOWLEDGE ANCHOR SELECTION"
    ),
    "=" * 72,
    "",
    "Human semantic review completed: YES",
    "Database writes performed: NO",
    "",
]

for sheet in SHEETS:

    item = selections[
        sheet
    ]

    lines.append(
        f"{sheet} = "
        f"RANK {item['rank']} | "
        f"{item['anonymous_id']}"
    )

lines.extend(
    [
        "",
        (
            "Distinct selected Services: "
            f"{len(set(selected_ids))}"
        ),
        (
            "Repeated Service selections: "
            f"{len(selected_ids) - len(set(selected_ids))}"
        ),
        "",
        "Private mapping saved locally: YES",
        "Actual Service names in safe report: NO",
        "",
        "LIVE DATABASE IMPORT: NOT STARTED",
    ]
)

SAFE_OUTPUT.write_text(
    "\n".join(
        lines
    ),
    encoding="utf-8",
)

print()
print("=" * 72)
print("ALL 5 SELECTIONS COMPLETE")
print("=" * 72)
print()
print(
    SAFE_OUTPUT.read_text(
        encoding="utf-8"
    )
)
