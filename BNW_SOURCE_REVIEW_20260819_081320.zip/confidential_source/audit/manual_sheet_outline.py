from pathlib import Path
from hashlib import sha256
import re

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell


SOURCE_DIR = Path("confidential_source")
AUDIT_DIR = SOURCE_DIR / "audit"

EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

TARGET_SHEETS = [
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
    "ONBOARDING_MAIL",
    "Rolling_Grants",
]


# ============================================================
# FIND FILE
# ============================================================

files = [
    p for p in SOURCE_DIR.glob("*.xlsx")
    if p.is_file()
    and not p.name.startswith("~$")
]

if len(files) != 1:
    raise SystemExit(
        f"STOPPED SAFELY: expected 1 XLSX, found {len(files)}"
    )

source = files[0]


# ============================================================
# VERIFY ORIGINAL FILE
# ============================================================

digest = sha256()

with source.open("rb") as f:
    for chunk in iter(
        lambda: f.read(1024 * 1024),
        b"",
    ):
        digest.update(chunk)

actual = digest.hexdigest()

if actual != EXPECTED_SHA256:
    raise SystemExit(
        "STOPPED SAFELY: workbook fingerprint changed."
    )


# ============================================================
# HELPERS
# ============================================================

def clean(value):
    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def sensitive_or_detailed(text):

    if not text:
        return True

    # Long text likely contains real process/content,
    # not merely a heading.
    if len(text) > 90:
        return True

    if re.search(
        r"https?://|www\.",
        text,
        re.I,
    ):
        return True

    if re.search(
        r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b",
        text,
    ):
        return True

    # Rupee / explicit commercial amount
    if "₹" in text:
        return True

    # Long phone-like numeric sequences
    digits = re.sub(
        r"\D",
        "",
        text,
    )

    if len(digits) >= 9:
        return True

    return False


def heading_score(cell, text):

    score = 0

    font = cell.font

    if getattr(font, "bold", False):
        score += 4

    size = getattr(
        font,
        "sz",
        None,
    )

    if size and size >= 12:
        score += 2

    if text.isupper() and len(text) >= 3:
        score += 2

    if len(text) <= 45:
        score += 1

    # Colon often indicates section labels.
    if text.endswith(":"):
        score += 1

    return score


# ============================================================
# OPEN READ-ONLY IN PRACTICE
# no save() is ever called
# ============================================================

wb = load_workbook(
    source,
    read_only=False,
    data_only=False,
    keep_links=True,
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — MANUAL SHEET SAFE OUTLINE"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Only short heading-like labels are shown."
)

lines.append(
    "Long content, URLs, emails, phone-like values and ₹ amounts are excluded."
)

lines.append("")


for sheet_name in TARGET_SHEETS:

    if sheet_name not in wb.sheetnames:
        continue

    ws = wb[sheet_name]

    candidates = []


    for row in ws.iter_rows():

        for cell in row:

            if isinstance(
                cell,
                MergedCell,
            ):
                continue

            if cell.data_type == "f":
                continue

            text = clean(
                cell.value
            )

            if sensitive_or_detailed(
                text
            ):
                continue

            score = heading_score(
                cell,
                text,
            )

            if score >= 2:

                candidates.append(
                    (
                        cell.coordinate,
                        score,
                        text,
                    )
                )


    # De-duplicate same visible text
    seen = set()
    filtered = []

    for coordinate, score, text in candidates:

        key = text.casefold()

        if key in seen:
            continue

        seen.add(key)

        filtered.append(
            (
                coordinate,
                score,
                text,
            )
        )


    lines.append(
        "-" * 80
    )

    lines.append(
        sheet_name
    )

    lines.append(
        "-" * 80
    )

    lines.append(
        f"Used rows: {ws.max_row}"
    )

    lines.append(
        f"Used columns: {ws.max_column}"
    )

    lines.append(
        f"Safe heading candidates: {len(filtered)}"
    )

    lines.append("")


    if not filtered:

        lines.append(
            "  No safe heading candidates detected."
        )

    else:

        for coordinate, score, text in filtered[:80]:

            lines.append(
                f"  {coordinate:<7} {text}"
            )


    if len(filtered) > 80:

        lines.append(
            f"  ... {len(filtered) - 80} more omitted"
        )

    lines.append("")


wb.close()


output = (
    AUDIT_DIR
    / "manual_sheet_outline_SAFE_TO_SHARE.txt"
)

output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print("")
print(
    "STEP 7B — MANUAL SHEET OUTLINE COMPLETE"
)

print("")

print(
    f"Workbook SHA-256 verified: YES"
)

print(
    f"Sheets inspected: {len(TARGET_SHEETS)}"
)

print("")

print(
    "SAFE REPORT:"
)

print(
    output
)

print("")

print(
    "NO EXCEL CELLS WERE MODIFIED."
)

print(
    "NO DJANGO DATA WAS ACCESSED."
)

print(
    "NO DATABASE CHANGES WERE MADE."
)
