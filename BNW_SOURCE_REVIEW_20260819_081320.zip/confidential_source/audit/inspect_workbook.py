from pathlib import Path
from collections import Counter
from hashlib import sha256
from datetime import datetime
import json
import re
import zipfile
import xml.etree.ElementTree as ET


SOURCE_DIR = Path("confidential_source")
AUDIT_DIR = SOURCE_DIR / "audit"

AUDIT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 1. FIND EXACTLY ONE XLSX
# ============================================================

xlsx_files = [
    p for p in SOURCE_DIR.glob("*.xlsx")
    if p.is_file()
    and not p.name.startswith("~$")
]

if len(xlsx_files) != 1:
    raise SystemExit(
        f"STOPPED SAFELY: expected exactly one .xlsx file, "
        f"found {len(xlsx_files)}:\n"
        + "\n".join(str(p) for p in xlsx_files)
    )

source = xlsx_files[0]


# ============================================================
# 2. FILE FINGERPRINT
# ============================================================

digest = sha256()

with source.open("rb") as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b""):
        digest.update(chunk)

fingerprint = digest.hexdigest()


# ============================================================
# 3. XLSX NAMESPACES
# ============================================================

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"

ns = {
    "m": NS_MAIN,
    "r": NS_REL,
}


# ============================================================
# 4. HELPERS
# ============================================================

def xml_root(zf, name):
    try:
        with zf.open(name) as f:
            return ET.parse(f).getroot()
    except KeyError:
        return None


def column_number(cell_ref):
    match = re.match(r"([A-Z]+)", cell_ref or "")
    if not match:
        return None

    result = 0

    for char in match.group(1):
        result = result * 26 + (ord(char) - 64)

    return result


def column_letter(number):
    result = ""

    while number:
        number, rem = divmod(number - 1, 26)
        result = chr(65 + rem) + result

    return result


def parse_dimension(ref):
    if not ref:
        return None, None, None, None

    parts = ref.split(":")

    start = parts[0]
    end = parts[-1]

    start_col = column_number(start)
    end_col = column_number(end)

    start_row_match = re.search(r"(\d+)", start)
    end_row_match = re.search(r"(\d+)", end)

    start_row = int(start_row_match.group(1)) if start_row_match else None
    end_row = int(end_row_match.group(1)) if end_row_match else None

    return start_col, start_row, end_col, end_row


# ============================================================
# 5. INSPECT ZIP STRUCTURE
# ============================================================

try:
    zf = zipfile.ZipFile(source, "r")
except zipfile.BadZipFile:
    raise SystemExit(
        "STOPPED SAFELY: this file is not a valid XLSX/ZIP workbook."
    )


with zf:

    bad_member = zf.testzip()

    if bad_member:
        raise SystemExit(
            f"STOPPED SAFELY: corrupt XLSX member detected: {bad_member}"
        )


    workbook_root = xml_root(
        zf,
        "xl/workbook.xml"
    )

    if workbook_root is None:
        raise SystemExit(
            "STOPPED SAFELY: xl/workbook.xml is missing."
        )


    rel_root = xml_root(
        zf,
        "xl/_rels/workbook.xml.rels"
    )

    relationships = {}

    if rel_root is not None:
        for rel in rel_root:
            relationships[rel.attrib.get("Id")] = rel.attrib.get("Target")


    # --------------------------------------------------------
    # Workbook-level flags
    # --------------------------------------------------------

    workbook_props = {}

    calc_pr = workbook_root.find("m:calcPr", ns)

    if calc_pr is not None:
        workbook_props["calculation_mode"] = calc_pr.attrib.get("calcMode")
        workbook_props["full_calc_on_load"] = calc_pr.attrib.get("fullCalcOnLoad")
        workbook_props["force_full_calc"] = calc_pr.attrib.get("forceFullCalc")


    workbook_protection = workbook_root.find(
        "m:workbookProtection",
        ns
    )

    workbook_props["workbook_protected"] = (
        workbook_protection is not None
    )


    # --------------------------------------------------------
    # Defined names
    # --------------------------------------------------------

    defined_names = []

    defined_names_root = workbook_root.find(
        "m:definedNames",
        ns
    )

    if defined_names_root is not None:

        for item in defined_names_root:

            defined_names.append({
                "name": item.attrib.get("name"),
                "local_sheet_id": item.attrib.get("localSheetId"),
                "hidden": item.attrib.get("hidden"),
            })


    # --------------------------------------------------------
    # Sheets
    # --------------------------------------------------------

    sheets_result = []

    sheets_node = workbook_root.find(
        "m:sheets",
        ns
    )

    if sheets_node is None:
        raise SystemExit(
            "STOPPED SAFELY: workbook contains no sheets."
        )


    for index, sheet in enumerate(sheets_node, start=1):

        sheet_name = sheet.attrib.get("name")

        state = sheet.attrib.get(
            "state",
            "visible"
        )

        rel_id = sheet.attrib.get(
            f"{{{NS_REL}}}id"
        )

        target = relationships.get(rel_id)

        if target is None:

            sheets_result.append({
                "index": index,
                "name": sheet_name,
                "state": state,
                "error": "Worksheet relationship target missing",
            })

            continue


        if target.startswith("/"):
            worksheet_path = target.lstrip("/")
        else:
            worksheet_path = "xl/" + target.lstrip("./")


        ws_root = xml_root(
            zf,
            worksheet_path
        )

        if ws_root is None:

            sheets_result.append({
                "index": index,
                "name": sheet_name,
                "state": state,
                "error": f"Worksheet XML missing: {worksheet_path}",
            })

            continue


        # ----------------------------------------------------
        # Dimension
        # ----------------------------------------------------

        dimension_node = ws_root.find(
            "m:dimension",
            ns
        )

        dimension_ref = (
            dimension_node.attrib.get("ref")
            if dimension_node is not None
            else None
        )

        (
            start_col,
            start_row,
            end_col,
            end_row,
        ) = parse_dimension(
            dimension_ref
        )


        # ----------------------------------------------------
        # Sheet protection
        # ----------------------------------------------------

        protected = (
            ws_root.find(
                "m:sheetProtection",
                ns
            )
            is not None
        )


        # ----------------------------------------------------
        # Merged cells
        # ----------------------------------------------------

        merged_cells_node = ws_root.find(
            "m:mergeCells",
            ns
        )

        merged_count = 0

        if merged_cells_node is not None:
            merged_count = len(
                list(merged_cells_node)
            )


        # ----------------------------------------------------
        # Hyperlinks
        # ----------------------------------------------------

        hyperlinks_node = ws_root.find(
            "m:hyperlinks",
            ns
        )

        hyperlink_count = 0

        if hyperlinks_node is not None:
            hyperlink_count = len(
                list(hyperlinks_node)
            )


        # ----------------------------------------------------
        # Hidden rows + formulas + cell types
        # ----------------------------------------------------

        hidden_rows = 0
        non_empty_cells = 0
        formula_cells = 0

        type_counter = Counter()

        sheet_data = ws_root.find(
            "m:sheetData",
            ns
        )

        actual_min_row = None
        actual_max_row = 0
        actual_min_col = None
        actual_max_col = 0


        if sheet_data is not None:

            for row in sheet_data.findall(
                "m:row",
                ns
            ):

                row_number = int(
                    row.attrib.get(
                        "r",
                        "0"
                    )
                )

                if row.attrib.get("hidden") == "1":
                    hidden_rows += 1


                row_has_content = False

                for cell in row.findall(
                    "m:c",
                    ns
                ):

                    ref = cell.attrib.get("r")

                    col_num = column_number(ref)

                    formula = cell.find(
                        "m:f",
                        ns
                    )

                    value = cell.find(
                        "m:v",
                        ns
                    )

                    inline = cell.find(
                        "m:is",
                        ns
                    )


                    if (
                        formula is not None
                        or value is not None
                        or inline is not None
                    ):

                        non_empty_cells += 1
                        row_has_content = True

                        if formula is not None:
                            formula_cells += 1


                        cell_type = cell.attrib.get(
                            "t",
                            "numeric_or_general"
                        )

                        type_counter[cell_type] += 1


                        if col_num:

                            if actual_min_col is None:
                                actual_min_col = col_num

                            actual_min_col = min(
                                actual_min_col,
                                col_num
                            )

                            actual_max_col = max(
                                actual_max_col,
                                col_num
                            )


                if row_has_content:

                    if actual_min_row is None:
                        actual_min_row = row_number

                    actual_min_row = min(
                        actual_min_row,
                        row_number
                    )

                    actual_max_row = max(
                        actual_max_row,
                        row_number
                    )


        # ----------------------------------------------------
        # Hidden columns
        # ----------------------------------------------------

        hidden_column_ranges = []

        cols_node = ws_root.find(
            "m:cols",
            ns
        )

        if cols_node is not None:

            for col in cols_node.findall(
                "m:col",
                ns
            ):

                if col.attrib.get("hidden") == "1":

                    minimum = int(
                        col.attrib.get("min")
                    )

                    maximum = int(
                        col.attrib.get("max")
                    )

                    hidden_column_ranges.append(
                        f"{column_letter(minimum)}:{column_letter(maximum)}"
                    )


        # ----------------------------------------------------
        # Auto filters
        # ----------------------------------------------------

        auto_filter = ws_root.find(
            "m:autoFilter",
            ns
        )

        auto_filter_ref = (
            auto_filter.attrib.get("ref")
            if auto_filter is not None
            else None
        )


        # ----------------------------------------------------
        # Tables
        # ----------------------------------------------------

        table_parts = ws_root.find(
            "m:tableParts",
            ns
        )

        table_count = 0

        if table_parts is not None:
            table_count = len(
                list(table_parts)
            )


        sheets_result.append({
            "index": index,
            "name": sheet_name,
            "state": state,
            "worksheet_xml": worksheet_path,

            "reported_dimension": dimension_ref,

            "reported_start_row": start_row,
            "reported_end_row": end_row,
            "reported_start_column": (
                column_letter(start_col)
                if start_col
                else None
            ),
            "reported_end_column": (
                column_letter(end_col)
                if end_col
                else None
            ),

            "actual_first_nonempty_row": actual_min_row,
            "actual_last_nonempty_row": actual_max_row or None,

            "actual_first_nonempty_column": (
                column_letter(actual_min_col)
                if actual_min_col
                else None
            ),

            "actual_last_nonempty_column": (
                column_letter(actual_max_col)
                if actual_max_col
                else None
            ),

            "non_empty_cells": non_empty_cells,
            "formula_cells": formula_cells,
            "hyperlink_count": hyperlink_count,
            "merged_range_count": merged_count,

            "hidden_rows": hidden_rows,
            "hidden_column_ranges": hidden_column_ranges,

            "sheet_protected": protected,

            "auto_filter_range": auto_filter_ref,
            "table_count": table_count,

            "cell_storage_types": dict(
                type_counter
            ),
        })


# ============================================================
# 6. CREATE SAFE AUDIT REPORT
# ============================================================

stat = source.stat()

report = {
    "audit_generated_at": datetime.now().isoformat(
        timespec="seconds"
    ),

    "source_filename": source.name,

    "source_size_bytes": stat.st_size,

    "source_modified_at": datetime.fromtimestamp(
        stat.st_mtime
    ).isoformat(
        timespec="seconds"
    ),

    "sha256": fingerprint,

    "workbook": workbook_props,

    "defined_name_count": len(
        defined_names
    ),

    "defined_names": defined_names,

    "sheet_count": len(
        sheets_result
    ),

    "sheets": sheets_result,
}


json_path = (
    AUDIT_DIR
    / "workbook_structure_audit.json"
)

json_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
    ),
    encoding="utf-8",
)


# ============================================================
# 7. HUMAN-READABLE SAFE REPORT
# ============================================================

lines = []

lines.append(
    "=" * 72
)

lines.append(
    "BHARATNXT WAVE — CONFIDENTIAL WORKBOOK STRUCTURAL AUDIT"
)

lines.append(
    "=" * 72
)

lines.append("")

lines.append(
    f"File: {source.name}"
)

lines.append(
    f"Size: {stat.st_size:,} bytes"
)

lines.append(
    f"SHA-256: {fingerprint}"
)

lines.append(
    f"Sheets: {len(sheets_result)}"
)

lines.append(
    f"Workbook protected: "
    f"{workbook_props.get('workbook_protected', False)}"
)

lines.append(
    f"Defined names: {len(defined_names)}"
)

lines.append("")

lines.append(
    "IMPORTANT: No scheme row contents were printed by this audit."
)

lines.append("")


for item in sheets_result:

    lines.append(
        "-" * 72
    )

    lines.append(
        f"SHEET {item['index']}: {item['name']}"
    )

    lines.append(
        "-" * 72
    )

    lines.append(
        f"Visibility: {item.get('state')}"
    )


    if item.get("error"):

        lines.append(
            f"ERROR: {item['error']}"
        )

        lines.append("")

        continue


    lines.append(
        f"Reported range: {item.get('reported_dimension')}"
    )

    lines.append(
        "Actual populated rows: "
        f"{item.get('actual_first_nonempty_row')} "
        f"to {item.get('actual_last_nonempty_row')}"
    )

    lines.append(
        "Actual populated columns: "
        f"{item.get('actual_first_nonempty_column')} "
        f"to {item.get('actual_last_nonempty_column')}"
    )

    lines.append(
        f"Non-empty cells: "
        f"{item.get('non_empty_cells', 0):,}"
    )

    lines.append(
        f"Formula cells: "
        f"{item.get('formula_cells', 0):,}"
    )

    lines.append(
        f"Hyperlinks: "
        f"{item.get('hyperlink_count', 0):,}"
    )

    lines.append(
        f"Merged ranges: "
        f"{item.get('merged_range_count', 0):,}"
    )

    lines.append(
        f"Hidden rows: "
        f"{item.get('hidden_rows', 0):,}"
    )

    hidden_cols = (
        ", ".join(
            item.get(
                "hidden_column_ranges",
                []
            )
        )
        or "None"
    )

    lines.append(
        f"Hidden columns: {hidden_cols}"
    )

    lines.append(
        f"Protected: "
        f"{item.get('sheet_protected')}"
    )

    lines.append(
        f"Auto-filter: "
        f"{item.get('auto_filter_range') or 'None'}"
    )

    lines.append(
        f"Excel tables: "
        f"{item.get('table_count', 0)}"
    )

    lines.append(
        f"Cell storage types: "
        f"{item.get('cell_storage_types', {})}"
    )

    lines.append("")


text_path = (
    AUDIT_DIR
    / "workbook_structure_audit.txt"
)

text_path.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print("")
print(
    "READ-ONLY STRUCTURAL AUDIT COMPLETE"
)
print("")

print(
    f"Workbook: {source.name}"
)

print(
    f"SHA-256: {fingerprint}"
)

print(
    f"Sheets found: {len(sheets_result)}"
)

print("")

for item in sheets_result:

    if item.get("error"):

        print(
            f"[{item['index']}] "
            f"{item['name']} — ERROR"
        )

        continue

    print(
        f"[{item['index']}] "
        f"{item['name']} | "
        f"state={item['state']} | "
        f"rows="
        f"{item.get('actual_first_nonempty_row')}-"
        f"{item.get('actual_last_nonempty_row')} | "
        f"cols="
        f"{item.get('actual_first_nonempty_column')}-"
        f"{item.get('actual_last_nonempty_column')} | "
        f"formulas={item.get('formula_cells')} | "
        f"links={item.get('hyperlink_count')} | "
        f"hidden_rows={item.get('hidden_rows')}"
    )


print("")
print(
    "Safe report:"
)

print(
    text_path
)

print("")
print(
    "Machine report:"
)

print(
    json_path
)

print("")
print(
    "NO CELLS WERE MODIFIED."
)
print(
    "NO DATA WAS IMPORTED INTO DJANGO."
)
print(
    "NO WORKBOOK CONTENT WAS UPLOADED."
)
