import hashlib
import json
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

if str(Path.cwd()) not in sys.path:
    sys.path.insert(
        0,
        str(Path.cwd()),
    )

import django
django.setup()

from toolkit.models import (
    ImportBatch,
    ImportRow,
    Service,
    ImportChange,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ReferenceItem,
    ComparisonMatrix,
    ComparisonEntry,
    CommunicationTemplate,
)


BATCH_ID = 5

CONTRACT = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


# ============================================================
# CONTRACT INTEGRITY
# ============================================================

actual_contract_hash = hashlib.sha256(
    CONTRACT.read_bytes()
).hexdigest()

if (
    actual_contract_hash
    != EXPECTED_CONTRACT_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 changed."
    )


# ============================================================
# BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)

if (
    batch.file_sha256
    != EXPECTED_SOURCE_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: source SHA-256 mismatch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
)


def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def fields(row):

    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    data = payload.get(
        "value"
    )

    if data is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(data),
    ).strip()


# ============================================================
# SAME SERVICE-KIND LOGIC AS CONTRACT V1
# ============================================================

SERVICE_KIND_KEYWORDS = {

    "REGISTRATION": (
        "registration",
    ),

    "COMPLIANCE": (
        "compliance",
    ),

    "CERTIFICATION": (
        "certification",
        "certificate",
    ),

    "GOVT_SCHEME": (
        "government scheme",
        "govt scheme",
    ),

    "GRANT": (
        "grant",
    ),

    "LOAN": (
        "loan",
    ),

    "DEBT": (
        "debt",
    ),

    "EQUITY": (
        "equity",
    ),

    "VC": (
        "venture capital",
        " vc ",
    ),

    "SUBSIDY": (
        "subsidy",
    ),

    "LEGAL": (
        "legal",
    ),

    "DIGITAL": (
        "digital",
    ),

    "CONSULTING": (
        "consulting",
        "consultancy",
    ),
}


def kind_candidates(text):

    padded = (
        " "
        + text.casefold()
        + " "
    )

    matches = set()

    for kind, keywords in (
        SERVICE_KIND_KEYWORDS.items()
    ):

        for keyword in keywords:

            if keyword in padded:

                matches.add(
                    kind
                )

                break

    return matches


def kind_result(group):

    raw_types = []

    for row in group:

        source_type = value(
            fields(row).get(
                "scheme_type",
                {},
            )
        )

        if source_type:
            raw_types.append(
                source_type
            )


    if not raw_types:

        return (
            "NO_SOURCE_TYPE",
            None,
        )


    unique_raw_types = {
        item.casefold()
        for item in raw_types
    }


    if len(
        unique_raw_types
    ) > 1:

        return (
            "CONFLICTING_SOURCE_TYPES",
            None,
        )


    all_matches = set()

    for item in raw_types:

        matches = kind_candidates(
            item
        )

        if not matches:

            return (
                "UNRECOGNISED_TYPE",
                None,
            )

        if len(matches) > 1:

            return (
                "AMBIGUOUS_TYPE",
                None,
            )

        all_matches.update(
            matches
        )


    if len(all_matches) != 1:

        return (
            "CONFLICTING_KIND_MAPPING",
            None,
        )


    return (
        "RESOLVED",
        next(iter(all_matches)),
    )


def coordinate_collision(row):

    row_fields = fields(
        row
    )

    deadline = row_fields.get(
        "deadline",
        {},
    )

    funding = row_fields.get(
        "funding_organisation",
        {},
    )

    if not isinstance(
        deadline,
        dict,
    ):
        return False

    if not isinstance(
        funding,
        dict,
    ):
        return False

    d = deadline.get(
        "coordinate"
    )

    f = funding.get(
        "coordinate"
    )

    return bool(
        d
        and f
        and d == f
    )


# ============================================================
# CANONICAL GROUPS
# ============================================================

scheme_rows = [
    row
    for row in rows
    if meta(row).get(
        "family"
    ) == "SCHEME_TABLE"
    and row.source_key
]


groups = defaultdict(
    list
)

for row in scheme_rows:

    groups[
        row.source_key
    ].append(
        row
    )


if len(groups) != 100:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 canonical identities."
    )


blocker_counts = Counter()

blocker_by_sheet = defaultdict(
    Counter
)

blocker_combinations = Counter()

ready_by_sheet = Counter()

review_by_sheet = Counter()

kind_result_counts = Counter()

resolved_kind_counts = Counter()

source_sheet_combinations = Counter()


for identity, group in (
    groups.items()
):

    blockers = []

    result, resolved_kind = (
        kind_result(
            group
        )
    )

    kind_result_counts[
        result
    ] += 1

    if resolved_kind:

        resolved_kind_counts[
            resolved_kind
        ] += 1

    else:

        blockers.append(
            "service_kind_"
            + result.casefold()
        )


    if any(
        coordinate_collision(row)
        for row in group
    ):

        blockers.append(
            "source_coordinate_collision"
        )


    blockers = sorted(
        set(blockers)
    )

    sheets = tuple(
        sorted(
            {
                row.sheet_name
                for row in group
            }
        )
    )

    source_sheet_combinations[
        sheets
    ] += 1


    primary_sheet_label = (
        " + ".join(sheets)
    )


    if blockers:

        review_by_sheet[
            primary_sheet_label
        ] += 1

    else:

        ready_by_sheet[
            primary_sheet_label
        ] += 1


    blocker_combinations[
        tuple(blockers)
    ] += 1


    for blocker in blockers:

        blocker_counts[
            blocker
        ] += 1

        for sheet in sheets:

            blocker_by_sheet[
                blocker
            ][
                sheet
            ] += 1


# ============================================================
# SAFETY TABLE CHECK
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if destination_counts[
    "Service"
] != 1:
    raise SystemExit(
        "STOPPED SAFELY: Service count changed."
    )


for name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if destination_counts[
        name
    ] != 0:

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} unexpectedly contains data."
        )


# ============================================================
# REPORT
# ============================================================

report = Path(
    "confidential_source/audit/"
    "step10b_blocker_anatomy_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10B BLOCKER ANATOMY"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    f"Contract SHA-256: "
    f"{actual_contract_hash}"
)

lines.append(
    f"Canonical identities inspected: "
    f"{len(groups)}"
)

lines.append("")


lines.append(
    "1. BLOCKER OCCURRENCES"
)

for key, count in sorted(
    blocker_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append("")


lines.append(
    "2. UNIQUE BLOCKER COMBINATIONS"
)

for blockers, count in sorted(
    blocker_combinations.items(),
    key=lambda item:
        (
            -item[1],
            str(item[0]),
        ),
):

    label = (
        "READY"
        if not blockers
        else " + ".join(blockers)
    )

    lines.append(
        f"  {label}: {count}"
    )


lines.append("")


lines.append(
    "3. BLOCKERS BY SOURCE SHEET"
)

for blocker in sorted(
    blocker_by_sheet
):

    lines.append(
        f"  {blocker}"
    )

    for sheet, count in sorted(
        blocker_by_sheet[
            blocker
        ].items()
    ):

        lines.append(
            f"    {sheet}: {count}"
        )


lines.append("")


lines.append(
    "4. READY CANDIDATES BY SOURCE SHEET COMBINATION"
)

for sheets, count in sorted(
    ready_by_sheet.items()
):

    lines.append(
        f"  {sheets}: {count}"
    )


lines.append("")


lines.append(
    "5. REVIEW CANDIDATES BY SOURCE SHEET COMBINATION"
)

for sheets, count in sorted(
    review_by_sheet.items()
):

    lines.append(
        f"  {sheets}: {count}"
    )


lines.append("")


lines.append(
    "6. SERVICE KIND RESULT"
)

for key, count in sorted(
    kind_result_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append("")

lines.append(
    "  RESOLVED MODEL KINDS"
)

for key, count in sorted(
    resolved_kind_counts.items()
):

    lines.append(
        f"    {key}: {count}"
    )


lines.append("")


lines.append(
    "7. SAFETY"
)

for key, count in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {count}"
    )


lines.append(
    "  ImportRow records changed: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Confidential cell values printed: NO"
)


report.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


# Sidecar hash for contract integrity.
sidecar = CONTRACT.with_suffix(
    CONTRACT.suffix + ".sha256"
)

sidecar.write_text(
    f"{actual_contract_hash}  "
    f"{CONTRACT.name}\n",
    encoding="utf-8",
)


print(
    "STEP 10B AUDIT COMPLETE"
)

print(
    f"SAFE REPORT: {report}"
)

print(
    f"Contract hash sidecar: {sidecar}"
)
