from django.conf import settings
from django.db import models


# =========================================================
# SERVICE DOMAIN
# Examples:
# Government Schemes & Grants
# Business Incorporation & Launch
# Compliance Management
# Funding & Equity Support
# =========================================================

class ServiceDomain(models.Model):
    name = models.CharField(
        max_length=150,
        unique=True
    )

    slug = models.SlugField(
        max_length=170,
        unique=True
    )

    description = models.TextField(
        blank=True
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    class Meta:
        ordering = ["display_order", "name"]

    def __str__(self):
        return self.name


# =========================================================
# CATEGORY
# Examples:
# Company Registration
# Government Grants
# MSME Loans
# Certifications
# =========================================================

class Category(models.Model):
    domain = models.ForeignKey(
        ServiceDomain,
        on_delete=models.PROTECT,
        related_name="categories"
    )

    name = models.CharField(
        max_length=150
    )

    slug = models.SlugField(
        max_length=170
    )

    description = models.TextField(
        blank=True
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    class Meta:
        ordering = ["display_order", "name"]

        constraints = [
            models.UniqueConstraint(
                fields=["domain", "slug"],
                name="unique_category_slug_per_domain"
            )
        ]

    def __str__(self):
        return f"{self.domain.name} → {self.name}"


# =========================================================
# MAIN SERVICE / SCHEME
# Examples:
# Startup India
# PMEGP
# CGTMSE
# Pvt Ltd Registration
# ISO Certification
# FSSAI Licence
# =========================================================

class Service(models.Model):

    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("UNDER_REVIEW", "Under Review"),
        ("APPROVED", "Approved"),
        ("PUBLISHED", "Published"),
        ("EXPIRING", "Expiring"),
        ("ARCHIVED", "Archived"),
    ]

    SERVICE_KIND_CHOICES = [
        ("REGISTRATION", "Registration"),
        ("COMPLIANCE", "Compliance"),
        ("CERTIFICATION", "Certification"),
        ("GOVT_SCHEME", "Government Scheme"),
        ("GRANT", "Grant"),
        ("LOAN", "Loan"),
        ("DEBT", "Debt Funding"),
        ("EQUITY", "Equity Funding"),
        ("VC", "VC Funding"),
        ("SUBSIDY", "Subsidy"),
        ("LEGAL", "Legal Service"),
        ("DIGITAL", "Digital Service"),
        ("CONSULTING", "Consulting"),
        ("OTHER", "Other"),
    ]

    PRIORITY_CHOICES = [
        ("LOW", "Low"),
        ("NORMAL", "Normal"),
        ("HIGH", "High"),
        ("CRITICAL", "Critical"),
    ]

    # -----------------------------
    # Identity
    # -----------------------------

    service_id = models.CharField(
        max_length=40,
        unique=True
    )

    title = models.CharField(
        max_length=255
    )

    slug = models.SlugField(
        max_length=280,
        unique=True
    )

    domain = models.ForeignKey(
        ServiceDomain,
        on_delete=models.PROTECT,
        related_name="services"
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        related_name="services"
    )

    service_kind = models.CharField(
        max_length=30,
        choices=SERVICE_KIND_CHOICES
    )

    status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default="DRAFT"
    )

    priority = models.CharField(
        max_length=20,
        choices=PRIORITY_CHOICES,
        default="NORMAL"
    )

    # -----------------------------
    # BDE-facing information
    # -----------------------------

    bde_summary = models.TextField(
        blank=True,
        help_text="Short explanation BDE can quickly read during a call."
    )

    overview = models.TextField(
        blank=True
    )

    benefits = models.TextField(
        blank=True
    )

    restrictions = models.TextField(
        blank=True
    )

    important_notes = models.TextField(
        blank=True
    )

    # -----------------------------
    # Eligibility information
    # -----------------------------

    eligibility_summary = models.TextField(
        blank=True
    )

    business_types = models.JSONField(
        default=list,
        blank=True
    )

    business_stages = models.JSONField(
        default=list,
        blank=True
    )

    industries = models.JSONField(
        default=list,
        blank=True
    )

    applicable_states = models.JSONField(
        default=list,
        blank=True
    )

    founder_categories = models.JSONField(
        default=list,
        blank=True
    )

    min_business_age_months = models.PositiveIntegerField(
        null=True,
        blank=True
    )

    max_business_age_months = models.PositiveIntegerField(
        null=True,
        blank=True
    )

    min_turnover = models.DecimalField(
        max_digits=16,
        decimal_places=2,
        null=True,
        blank=True
    )

    max_turnover = models.DecimalField(
        max_digits=16,
        decimal_places=2,
        null=True,
        blank=True
    )

    # -----------------------------
    # Funding / financial details
    # -----------------------------

    funding_min = models.DecimalField(
        max_digits=16,
        decimal_places=2,
        null=True,
        blank=True
    )

    funding_max = models.DecimalField(
        max_digits=16,
        decimal_places=2,
        null=True,
        blank=True
    )

    funding_type = models.CharField(
        max_length=120,
        blank=True
    )

    interest_rate_min = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        null=True,
        blank=True
    )

    interest_rate_max = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        null=True,
        blank=True
    )

    collateral_required = models.BooleanField(
        null=True,
        blank=True
    )

    tenure = models.CharField(
        max_length=150,
        blank=True
    )

    subsidy_details = models.TextField(
        blank=True
    )

    # -----------------------------
    # BharatNXT commercial info
    # -----------------------------

    government_fee = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True
    )

    bharatnxt_fee = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True
    )

    pricing_notes = models.TextField(
        blank=True
    )

    # -----------------------------
    # Timeline
    # -----------------------------

    estimated_processing_time = models.CharField(
        max_length=150,
        blank=True
    )

    effective_from = models.DateField(
        null=True,
        blank=True,
        help_text="Date from which BDEs should start pitching this service."
    )

    pitch_until = models.DateField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Internal last date until which BDEs should pitch this service."
    )

    application_deadline = models.DateField(
        null=True,
        blank=True
    )

    # -----------------------------
    # Internal company information
    # -----------------------------

    internal_notes = models.TextField(
        blank=True
    )

    sales_pitch = models.TextField(
        blank=True
    )

    escalation_notes = models.TextField(
        blank=True
    )

    # -----------------------------
    # Verification
    # -----------------------------

    version = models.PositiveIntegerField(
        default=1
    )

    last_verified_at = models.DateTimeField(
        null=True,
        blank=True
    )

    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="verified_services"
    )

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_services"
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    class Meta:
        ordering = ["title"]

        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["service_kind"]),
            models.Index(fields=["domain"]),
            models.Index(fields=["category"]),
            models.Index(fields=["updated_at"]),
            models.Index(fields=["last_verified_at"]),
        ]

    def __str__(self):
        return f"{self.service_id} - {self.title}"


# =========================================================
# ELIGIBILITY RULE
# Allows multiple clean eligibility conditions
# instead of one giant paragraph.
# =========================================================

class EligibilityRule(models.Model):

    RULE_TYPE_CHOICES = [
        ("REQUIRED", "Required"),
        ("OPTIONAL", "Optional"),
        ("DISQUALIFIER", "Disqualifier"),
        ("INFORMATION", "Information"),
    ]

    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="eligibility_rules"
    )

    rule_type = models.CharField(
        max_length=20,
        choices=RULE_TYPE_CHOICES,
        default="REQUIRED"
    )

    title = models.CharField(
        max_length=200
    )

    description = models.TextField()

    display_order = models.PositiveIntegerField(
        default=0
    )

    class Meta:
        ordering = ["display_order", "id"]

    def __str__(self):
        return f"{self.service.title} - {self.title}"


# =========================================================
# DOCUMENT REQUIREMENTS
# =========================================================

class DocumentRequirement(models.Model):

    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="document_requirements"
    )

    name = models.CharField(
        max_length=200
    )

    description = models.TextField(
        blank=True
    )

    is_mandatory = models.BooleanField(
        default=True
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    class Meta:
        ordering = ["display_order", "name"]

    def __str__(self):
        return f"{self.service.title} - {self.name}"


# =========================================================
# PROCESS STEPS
# Example:
# 1. Eligibility check
# 2. Document collection
# 3. Application
# 4. Approval
# =========================================================

class ProcessStep(models.Model):

    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="process_steps"
    )

    step_number = models.PositiveIntegerField()

    title = models.CharField(
        max_length=200
    )

    description = models.TextField(
        blank=True
    )

    estimated_time = models.CharField(
        max_length=120,
        blank=True
    )

    class Meta:
        ordering = ["step_number"]

        constraints = [
            models.UniqueConstraint(
                fields=["service", "step_number"],
                name="unique_step_number_per_service"
            )
        ]

    def __str__(self):
        return f"{self.service.title} - Step {self.step_number}"


# =========================================================
# SOURCES
# Official links / verification references
# =========================================================

class ServiceSource(models.Model):

    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="sources"
    )

    source_name = models.CharField(
        max_length=255
    )

    source_url = models.URLField(
        blank=True
    )

    source_reference = models.CharField(
        max_length=255,
        blank=True
    )

    is_official = models.BooleanField(
        default=False
    )

    last_checked_at = models.DateTimeField(
        null=True,
        blank=True
    )

    notes = models.TextField(
        blank=True
    )

    def __str__(self):
        return f"{self.service.title} - {self.source_name}"


# =========================================================
# RELATED SERVICES
#
# Example:
# Startup India → Udyam → GST → Funding Scheme
# =========================================================

class RelatedService(models.Model):

    RELATION_CHOICES = [
        ("RECOMMENDED", "Recommended"),
        ("PREREQUISITE", "Prerequisite"),
        ("ALTERNATIVE", "Alternative"),
        ("FOLLOW_UP", "Follow-up Service"),
    ]

    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="related_from"
    )

    related_service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="related_to"
    )

    relation_type = models.CharField(
        max_length=20,
        choices=RELATION_CHOICES,
        default="RECOMMENDED"
    )

    notes = models.TextField(
        blank=True
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=[
                    "service",
                    "related_service",
                    "relation_type"
                ],
                name="unique_service_relationship"
            )
        ]

    def __str__(self):
        return (
            f"{self.service.title} → "
            f"{self.related_service.title}"
        )


# =========================================================
# SEARCH EVENT
# Structured search analytics for BDE dashboards.
# This is separate from ActivityLog because analytics
# should not depend on parsing human-readable audit text.
# =========================================================

class SearchEvent(models.Model):

    EVENT_CHOICES = [
        ("SEARCH", "Search"),
        ("SUGGESTION_CLICK", "Suggestion Click"),
        ("FILTER", "Filter"),
        ("CLIENT_MATCH", "Client Match"),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="toolkit_search_events"
    )

    event_type = models.CharField(
        max_length=30,
        choices=EVENT_CHOICES,
        default="SEARCH"
    )

    query = models.CharField(
        max_length=255,
        blank=True
    )

    filters = models.JSONField(
        default=dict,
        blank=True
    )

    result_count = models.PositiveIntegerField(
        default=0
    )

    selected_service = models.ForeignKey(
        Service,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="search_selections"
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )

    class Meta:
        ordering = ["-created_at"]

        indexes = [
            models.Index(
                fields=["user", "created_at"]
            ),
            models.Index(
                fields=["event_type", "created_at"]
            ),
        ]

    def __str__(self):
        return (
            f"{self.user.username} - "
            f"{self.event_type} - "
            f"{self.query}"
        )


# =========================================================
# SAVED SERVICE
# Personal starred/saved toolkit services for each BDE.
# =========================================================

class SavedService(models.Model):

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="saved_toolkit_services"
    )

    service = models.ForeignKey(
        Service,
        on_delete=models.CASCADE,
        related_name="saved_by_users"
    )

    note = models.CharField(
        max_length=500,
        blank=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = ["-created_at"]

        constraints = [
            models.UniqueConstraint(
                fields=["user", "service"],
                name="unique_saved_service_per_user"
            )
        ]

        indexes = [
            models.Index(
                fields=["user", "created_at"]
            ),
        ]

    def __str__(self):
        return (
            f"{self.user.username} → "
            f"{self.service.service_id}"
        )


# =========================================================
# IMPORT BATCH
# Metadata/audit history for Excel, CSV and Google Sheets.
#
# IMPORTANT:
# This stores import metadata, NOT the original uploaded
# confidential spreadsheet file.
# =========================================================

class ImportBatch(models.Model):

    SOURCE_CHOICES = [
        ("XLSX", "Excel"),
        ("CSV", "CSV"),
        ("GOOGLE_SHEET", "Google Sheet"),
    ]

    STATUS_CHOICES = [
        ("PREVIEWED", "Previewed"),
        ("VALIDATED", "Validated"),
        ("IMPORTED", "Imported"),
        ("FAILED", "Failed"),
    ]

    source_type = models.CharField(
        max_length=30,
        choices=SOURCE_CHOICES
    )

    source_name = models.CharField(
        max_length=255
    )

    source_identifier = models.CharField(
        max_length=500,
        blank=True
    )

    source_modified_at = models.DateTimeField(
        null=True,
        blank=True
    )

    file_sha256 = models.CharField(
        max_length=64,
        blank=True,
        db_index=True
    )

    sheet_count = models.PositiveIntegerField(
        default=0
    )

    row_count = models.PositiveIntegerField(
        default=0
    )

    status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default="PREVIEWED"
    )

    imported_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="toolkit_import_batches"
    )

    metadata = models.JSONField(
        default=dict,
        blank=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )

    imported_at = models.DateTimeField(
        null=True,
        blank=True
    )

    class Meta:
        ordering = ["-created_at"]

        indexes = [
            models.Index(
                fields=["source_type", "created_at"]
            ),
            models.Index(
                fields=["status", "created_at"]
            ),
        ]

    def __str__(self):
        return (
            f"{self.source_type} - "
            f"{self.source_name} - "
            f"{self.created_at}"
        )
