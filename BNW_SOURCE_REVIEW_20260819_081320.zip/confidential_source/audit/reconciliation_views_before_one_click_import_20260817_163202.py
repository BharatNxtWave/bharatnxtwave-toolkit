from django.contrib import messages
from django.http import HttpResponseForbidden
from django.shortcuts import (
    get_object_or_404,
    redirect,
    render,
)
from django.views.decorators.http import require_http_methods

from toolkit.intelligence.final_import import (
    FinalImportError,
    apply_batch,
    preview_batch,
    rollback_batch,
)
from toolkit.models import ImportBatch


ADMIN_ROLES = {
    "ADMIN",
    "DATA_ADMIN",
    "SECURITY_ADMIN",
    "IT_ADMIN",
    "SUPER_ADMIN",
}


def _allowed(user):

    if not getattr(
        user,
        "is_authenticated",
        False,
    ):
        return False

    if getattr(
        user,
        "is_superuser",
        False,
    ):
        return True

    if getattr(
        user,
        "is_staff",
        False,
    ):
        return True

    role = str(
        getattr(
            user,
            "role",
            "",
        )
        or ""
    ).upper()

    return role in ADMIN_ROLES


@require_http_methods(["GET", "POST"])
def reconciliation_finalize(
    request,
    batch_id,
):

    if not _allowed(
        request.user
    ):
        return HttpResponseForbidden(
            "Permission denied."
        )

    batch = get_object_or_404(
        ImportBatch,
        pk=batch_id,
    )

    metadata = (
        batch.metadata
        if isinstance(
            batch.metadata,
            dict,
        )
        else {}
    )

    if not metadata.get(
        "reconciliation_mode"
    ):

        messages.error(
            request,
            "This is not a reconciliation batch.",
        )

        return redirect(
            "toolkit:import_extraction_review",
            batch_id=batch.pk,
        )

    if request.method == "POST":

        action = str(
            request.POST.get(
                "action",
                "",
            )
        ).strip()

        if action == "final_import":

            try:

                result = apply_batch(
                    batch.pk,
                    user=request.user,
                    reconcile=True,
                )

                messages.success(
                    request,
                    (
                        "Final Import completed. "
                        f"{result.get('changes_created', 0)} "
                        "audited change(s) created."
                    ),
                )

            except Exception as exc:

                messages.error(
                    request,
                    f"Final Import failed: {exc}",
                )

        elif action == "rollback":

            try:

                result = rollback_batch(
                    batch.pk,
                    user=request.user,
                )

                messages.success(
                    request,
                    (
                        "Rollback completed. "
                        f"{result.get('reversed_changes', 0)} "
                        "change(s) reversed."
                    ),
                )

            except Exception as exc:

                messages.error(
                    request,
                    f"Rollback failed: {exc}",
                )

        return redirect(
            "toolkit:reconciliation_finalize",
            batch_id=batch.pk,
        )

    batch.refresh_from_db()

    preview = preview_batch(
        batch.pk
    )

    active_changes = (
        batch.changes
        .filter(
            is_reversed=False
        )
        .count()
    )

    return render(
        request,
        "toolkit/admin/reconciliation_finalize.html",
        {
            "batch":
                batch,

            "preview":
                preview,

            "active_changes":
                active_changes,

            "reconciliation_of":
                metadata.get(
                    "reconciliation_of_batch_id"
                ),
        },
    )
