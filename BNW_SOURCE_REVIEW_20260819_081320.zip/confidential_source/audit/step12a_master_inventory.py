import os
import sys
from pathlib import Path
from collections import Counter

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import django
django.setup()

from django.apps import apps
from django.conf import settings
from django.db import connection
from django.urls import get_resolver

from toolkit.models import ImportRow


print("=" * 80)
print("BHARATNXT WAVE — STEP 12A MASTER TOOLKIT INVENTORY")
print("=" * 80)

print()
print("MODE: READ ONLY")
print("DATABASE WRITES: NO")


# ============================================================
# 1. PROJECT BASICS
# ============================================================

print()
print("=" * 80)
print("1. PROJECT BASICS")
print("=" * 80)

print("Django version:", django.get_version())
print("Debug:", settings.DEBUG)
print("Database engine:", settings.DATABASES["default"]["ENGINE"])

db_name = settings.DATABASES["default"]["NAME"]

print(
    "Database file exists:",
    Path(db_name).exists()
    if isinstance(db_name, (str, Path))
    else "N/A"
)


# ============================================================
# 2. INSTALLED APPS
# ============================================================

print()
print("=" * 80)
print("2. INSTALLED APPS")
print("=" * 80)

for app_config in apps.get_app_configs():
    print(
        app_config.label,
        "|",
        app_config.name,
    )


# ============================================================
# 3. TOOLKIT MODELS
# ============================================================

print()
print("=" * 80)
print("3. TOOLKIT MODELS")
print("=" * 80)

toolkit_app = apps.get_app_config("toolkit")

models = list(toolkit_app.get_models())

print("Toolkit model count:", len(models))

for model in models:

    print()
    print(
        f"[{model.__name__}]"
    )

    print(
        "DB table:",
        model._meta.db_table,
    )

    try:
        print(
            "Current rows:",
            model.objects.count(),
        )
    except Exception as exc:
        print(
            "Current rows: ERROR",
            exc.__class__.__name__,
        )

    concrete_fields = [
        field
        for field in model._meta.get_fields()
        if getattr(field, "concrete", False)
    ]

    print(
        "Concrete fields:",
        len(concrete_fields),
    )

    for field in concrete_fields:

        related_model = None

        remote = getattr(
            field,
            "remote_field",
            None,
        )

        if remote is not None:
            rm = getattr(
                remote,
                "model",
                None,
            )

            if rm is not None:
                related_model = getattr(
                    rm,
                    "__name__",
                    str(rm),
                )

        print(
            "  -",
            field.name,
            "|",
            field.__class__.__name__,
            "| null=",
            getattr(field, "null", False),
            "| blank=",
            getattr(field, "blank", False),
            "| unique=",
            getattr(field, "unique", False),
            "| related=",
            related_model,
        )


# ============================================================
# 4. MIGRATION FILES
# ============================================================

print()
print("=" * 80)
print("4. TOOLKIT MIGRATIONS")
print("=" * 80)

migration_dir = (
    ROOT
    / "toolkit"
    / "migrations"
)

migration_files = sorted(
    path.name
    for path in migration_dir.glob("*.py")
    if path.name != "__init__.py"
)

print(
    "Migration file count:",
    len(migration_files),
)

for filename in migration_files:
    print(" ", filename)


# ============================================================
# 5. IMPORT / TRANSFORMATION MODULES
# ============================================================

print()
print("=" * 80)
print("5. IMPORT ENGINE FILES")
print("=" * 80)

import_dir = (
    ROOT
    / "toolkit"
    / "importing"
)

if import_dir.exists():

    python_files = sorted(
        path.name
        for path in import_dir.glob("*.py")
    )

    print(
        "Import module count:",
        len(python_files),
    )

    for filename in python_files:
        print(" ", filename)

else:

    print(
        "toolkit/importing directory: MISSING"
    )


# ============================================================
# 6. IMPORT MODULE FUNCTION INVENTORY
# ============================================================

print()
print("=" * 80)
print("6. IMPORT ENGINE CALLABLES")
print("=" * 80)

modules_to_check = [
    "toolkit.importing.transformation",
    "toolkit.importing.supporting_transformation",
    "toolkit.importing.staging",
    "toolkit.importing.sheet_registry",
    "toolkit.importing.workbook_reader",
]

import importlib
import inspect

for module_name in modules_to_check:

    print()
    print(
        f"[{module_name}]"
    )

    try:
        module = importlib.import_module(
            module_name
        )

    except Exception as exc:

        print(
            "IMPORT ERROR:",
            exc.__class__.__name__,
            str(exc),
        )

        continue

    functions = []

    for name, obj in inspect.getmembers(
        module,
        inspect.isfunction,
    ):

        if obj.__module__ != module.__name__:
            continue

        functions.append(name)

    for name in functions:
        print(" ", name)


# ============================================================
# 7. URL INVENTORY
# ============================================================

print()
print("=" * 80)
print("7. URL INVENTORY")
print("=" * 80)


def walk_urls(
    patterns,
    prefix="",
):

    results = []

    for pattern in patterns:

        if hasattr(
            pattern,
            "url_patterns",
        ):

            nested_prefix = (
                prefix
                + str(
                    pattern.pattern
                )
            )

            results.extend(
                walk_urls(
                    pattern.url_patterns,
                    nested_prefix,
                )
            )

        else:

            results.append(
                (
                    prefix
                    + str(
                        pattern.pattern
                    ),
                    pattern.name,
                )
            )

    return results


resolver = get_resolver()

url_rows = walk_urls(
    resolver.url_patterns
)

print(
    "URL pattern count:",
    len(url_rows),
)

for route, name in url_rows:

    print(
        route,
        "| name=",
        name,
    )


# ============================================================
# 8. TEMPLATE INVENTORY
# ============================================================

print()
print("=" * 80)
print("8. TEMPLATE INVENTORY")
print("=" * 80)

template_roots = [
    ROOT / "templates",
    ROOT / "toolkit" / "templates",
]

template_files = []

for root in template_roots:

    if not root.exists():
        continue

    for path in root.rglob("*.html"):

        try:
            relative = path.relative_to(
                ROOT
            )
        except Exception:
            relative = path

        template_files.append(
            str(relative)
        )

template_files = sorted(
    set(template_files)
)

print(
    "Template file count:",
    len(template_files),
)

for filename in template_files:
    print(" ", filename)


# ============================================================
# 9. STATIC FILE INVENTORY
# ============================================================

print()
print("=" * 80)
print("9. STATIC INVENTORY")
print("=" * 80)

static_roots = [
    ROOT / "static",
    ROOT / "toolkit" / "static",
]

static_files = []

for root in static_roots:

    if not root.exists():
        continue

    for path in root.rglob("*"):

        if not path.is_file():
            continue

        try:
            relative = path.relative_to(
                ROOT
            )
        except Exception:
            relative = path

        static_files.append(
            str(relative)
        )

static_files = sorted(
    set(static_files)
)

print(
    "Static file count:",
    len(static_files),
)

for filename in static_files:
    print(" ", filename)


# ============================================================
# 10. STAGED WORKBOOK ACCOUNTING
# ============================================================

print()
print("=" * 80)
print("10. STAGED WORKBOOK ACCOUNTING")
print("=" * 80)

rows = ImportRow.objects.all()

print(
    "Total ImportRows:",
    rows.count(),
)

sheet_counts = Counter(
    rows.values_list(
        "sheet_name",
        flat=True,
    )
)

print(
    "Distinct staged sheets:",
    len(sheet_counts),
)

for sheet_name, count in sorted(
    sheet_counts.items(),
    key=lambda item: str(item[0]),
):

    print(
        sheet_name,
        ":",
        count,
    )


# ============================================================
# 11. DATABASE TABLES
# ============================================================

print()
print("=" * 80)
print("11. DATABASE TABLE INVENTORY")
print("=" * 80)

table_names = sorted(
    connection.introspection.table_names()
)

print(
    "Database table count:",
    len(table_names),
)

for table_name in table_names:
    print(" ", table_name)


# ============================================================
# 12. AUDIT ARTIFACT INVENTORY
# ============================================================

print()
print("=" * 80)
print("12. AUDIT ARTIFACTS")
print("=" * 80)

audit_dir = (
    ROOT
    / "confidential_source"
    / "audit"
)

if audit_dir.exists():

    audit_files = sorted(
        path.name
        for path in audit_dir.iterdir()
        if path.is_file()
    )

    print(
        "Audit file count:",
        len(audit_files),
    )

    for filename in audit_files:
        print(" ", filename)

else:

    print(
        "Audit directory: MISSING"
    )


# ============================================================
# 13. SQLITE SAFETY CHECK
# ============================================================

print()
print("=" * 80)
print("13. SQLITE SAFETY")
print("=" * 80)

with connection.cursor() as cursor:

    try:

        cursor.execute(
            "PRAGMA integrity_check;"
        )

        integrity = cursor.fetchone()

        print(
            "integrity_check:",
            integrity[0]
            if integrity
            else "NO RESULT"
        )

    except Exception as exc:

        print(
            "integrity_check ERROR:",
            exc.__class__.__name__,
        )


    try:

        cursor.execute(
            "PRAGMA foreign_key_check;"
        )

        fk_rows = cursor.fetchall()

        print(
            "foreign_key_check violations:",
            len(fk_rows),
        )

    except Exception as exc:

        print(
            "foreign_key_check ERROR:",
            exc.__class__.__name__,
        )


print()
print("=" * 80)
print("STEP 12A INVENTORY COMPLETE")
print("DATABASE WRITES: NO")
print("=" * 80)
