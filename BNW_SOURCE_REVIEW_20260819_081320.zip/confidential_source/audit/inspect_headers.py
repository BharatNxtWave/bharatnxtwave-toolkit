from pathlib import Path
from hashlib import sha256
from collections import Counter
import json
import re
import sys


# ============================================================
# CONFIGURATION
# ============================================================

SOURCE_DIR = Path("confidential_source")
AUDIT_DIR = SOURCE_DIR / "audit"

EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

MAX_HEADER_SCAN_ROWS = 15
MAX_HEADER_TEXT_LENGTH = 140


# ============================================================
# LOAD OPENPYXL
# ============================================================

try:
    from openpyxl import load_workbook
except ImportError:
    raise SystemExit(
        "STOPPED SAFELY: openpyxl is not installed."
    )


# ============================================================
# FIND SOURCE
# ============================================================

files = [
    p
    for p in SOURCE_DIR.glob("*.xlsx")
    if p.is_file()
    and not p.name.startswith("~$")
]

if len(files) != 1:
    raise SystemExit(
        "STOPPED SAFELY: expected exactly one XLSX "
        f"inside {SOURCE_DIR}, found {len(files)}."
    )

source = files[0]


# ============================================================
# VERIFY FILE HAS NOT CHANGED
# ============================================================

digest = sha256()

with source.open("rb") as f:

    for chunk in iter(
        lambda: f.read(1024 * 1024),
        b"",
    ):
        digest.update(chunk)


actual_sha256 = digest.hexdigest()


if actual_sha256 != EXPECTED_SHA256:

    raise SystemExit(
        "\nSTOPPED SAFELY.\n\n"
        "The workbook fingerprint has changed since Step 2.\n"
        "We will not inspect a different/modified file "
        "without confirming it first.\n\n"
        f"Expected: {EXPECTED_SHA256}\n"
        f"Actual:   {actual_sha256}\n"
    )


# ============================================================
# HELPERS
# ============================================================

def clean(value):

    if value is None:
        return None

    text = str(value)

    text = re.sub(
        r"\s+",
        " ",
        text,
    ).strip()

    return text or None


def looks_like_header_value(value):

    text = clean(value)

    if not text:
        return False

    if len(text) > MAX_HEADER_TEXT_LENGTH:
        return False

    # Headers are usually descriptive rather than
    # pure numeric/date values.

    if re.fullmatch(
        r"[-+]?\d+(?:\.\d+)?",
        text,
    ):
        return False

    return True


def row_header_score(values):

    cleaned = [
        clean(v)
        for v in values
    ]

    populated = [
        v
        for v in cleaned
        if v
    ]


    if not populated:
        return -1000


    # Single-column sheets are too ambiguous for
    # automatic header guessing.
    if len(populated) == 1:
        return 0


    header_like = sum(
        1
        for value in populated
        if looks_like_header_value(value)
    )


    unique = len(
        {
            value.lower()
            for value in populated
        }
    )


    long_values = sum(
        1
        for value in populated
        if len(value) > 80
    )


    score = 0

    score += len(populated) * 3
    score += header_like * 2
    score += unique

    score -= long_values * 4


    return score


def excel_column_name(number):

    result = ""

    while number:

        number, remainder = divmod(
            number - 1,
            26,
        )

        result = (
            chr(65 + remainder)
            + result
        )

    return result


# ============================================================
# OPEN WORKBOOK READ-ONLY
# ============================================================

try:

    workbook = load_workbook(
        filename=source,
        read_only=True,
        data_only=False,
        keep_links=True,
    )

except Exception as exc:

    raise SystemExit(
        "STOPPED SAFELY: workbook could not be opened "
        f"read-only.\n{type(exc).__name__}: {exc}"
    )


# ============================================================
# INSPECT EACH SHEET
# ============================================================

report = {
    "source_filename": source.name,
    "sha256": actual_sha256,
    "sheet_count": len(workbook.sheetnames),
    "sheets": [],
}


print("")
print("=" * 76)
print("BHARATNXT WAVE — HEADER / SCHEMA AUDIT")
print("=" * 76)

print("")
print(f"Workbook: {source.name}")
print(f"SHA-256 verified: YES")
print(f"Sheets: {len(workbook.sheetnames)}")
print("")


for sheet_index, sheet_name in enumerate(
    workbook.sheetnames,
    start=1,
):

    ws = workbook[sheet_name]


    max_row = ws.max_row or 0
    max_column = ws.max_column or 0


    scan_limit = min(
        max_row,
        MAX_HEADER_SCAN_ROWS,
    )


    scanned_rows = []


    for row_number, row in enumerate(
        ws.iter_rows(
            min_row=1,
            max_row=scan_limit,
            values_only=True,
        ),
        start=1,
    ):

        values = list(row)

        populated_count = sum(
            1
            for value in values
            if clean(value)
        )

        scanned_rows.append({
            "row": row_number,
            "values": values,
            "populated": populated_count,
            "score": row_header_score(values),
        })


    # --------------------------------------------------------
    # Determine structural classification
    # --------------------------------------------------------

    if max_column == 1:

        classification = (
            "SINGLE_COLUMN_REVIEW_REQUIRED"
        )

        header_row = None

    else:

        classification = (
            "STRUCTURED_TABLE_CANDIDATE"
        )


        candidates = [
            row
            for row in scanned_rows
            if row["populated"] >= 2
        ]


        if candidates:

            best = max(
                candidates,
                key=lambda item: (
                    item["score"],
                    -item["row"],
                ),
            )

            header_row = best["row"]

        else:

            header_row = None


    # --------------------------------------------------------
    # Extract candidate column names
    # --------------------------------------------------------

    headers = []


    if header_row is not None:

        raw_header = next(
            ws.iter_rows(
                min_row=header_row,
                max_row=header_row,
                values_only=True,
            )
        )


        for column_number, value in enumerate(
            raw_header,
            start=1,
        ):

            text = clean(value)

            if text:

                headers.append({
                    "column": excel_column_name(
                        column_number
                    ),
                    "name": text,
                })


    # --------------------------------------------------------
    # Detect duplicated header names
    # --------------------------------------------------------

    normalized_headers = [
        item["name"].strip().lower()
        for item in headers
    ]


    counts = Counter(
        normalized_headers
    )


    duplicates = sorted(
        {
            name
            for name, count in counts.items()
            if count > 1
        }
    )


    # --------------------------------------------------------
    # Store
    # --------------------------------------------------------

    item = {
        "index": sheet_index,
        "sheet": sheet_name,
        "max_row": max_row,
        "max_column": max_column,
        "classification": classification,
        "candidate_header_row": header_row,
        "headers": headers,
        "duplicate_headers": duplicates,
    }


    report["sheets"].append(
        item
    )


    # --------------------------------------------------------
    # SAFE TERMINAL OUTPUT
    # --------------------------------------------------------

    print("-" * 76)

    print(
        f"[{sheet_index}] {sheet_name}"
    )

    print(
        f"Range size: "
        f"{max_row} rows × {max_column} columns"
    )

    print(
        f"Classification: {classification}"
    )


    if header_row is None:

        print(
            "Header row: NOT AUTO-DETERMINED"
        )

        print(
            "Reason: sheet requires manual structural review."
        )

    else:

        print(
            f"Candidate header row: {header_row}"
        )

        print("")
        print("Columns:")


        for header in headers:

            print(
                f"  {header['column']:<4} "
                f"{header['name']}"
            )


        if duplicates:

            print("")
            print(
                "WARNING — duplicate header names:"
            )

            for value in duplicates:
                print(
                    f"  - {value}"
                )


    print("")


# ============================================================
# SAVE LOCAL REPORT
# ============================================================

AUDIT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


json_path = (
    AUDIT_DIR
    / "workbook_header_audit.json"
)


json_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
    ),
    encoding="utf-8",
)


text_path = (
    AUDIT_DIR
    / "workbook_header_audit.txt"
)


lines = []

lines.append(
    "BHARATNXT WAVE — WORKBOOK HEADER AUDIT"
)

lines.append(
    "=" * 76
)

lines.append("")

lines.append(
    f"Workbook: {source.name}"
)

lines.append(
    f"SHA-256: {actual_sha256}"
)

lines.append("")


for item in report["sheets"]:

    lines.append(
        "-" * 76
    )

    lines.append(
        f"[{item['index']}] {item['sheet']}"
    )

    lines.append(
        f"Rows: {item['max_row']}"
    )

    lines.append(
        f"Columns: {item['max_column']}"
    )

    lines.append(
        f"Classification: "
        f"{item['classification']}"
    )

    lines.append(
        f"Candidate header row: "
        f"{item['candidate_header_row']}"
    )

    lines.append("")

    for header in item["headers"]:

        lines.append(
            f"{header['column']}: "
            f"{header['name']}"
        )

    lines.append("")


text_path.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


workbook.close()


print("=" * 76)
print("HEADER / SCHEMA AUDIT COMPLETE")
print("=" * 76)

print("")

print(
    "Report saved locally:"
)

print(
    text_path
)

print("")

print(
    "Machine report:"
)

print(
    json_path
)

print("")

print(
    "NO WORKBOOK CELLS WERE MODIFIED."
)

print(
    "NO DATA WAS IMPORTED INTO DJANGO."
)

print(
    "NO FILE WAS UPLOADED ANYWHERE."
)
