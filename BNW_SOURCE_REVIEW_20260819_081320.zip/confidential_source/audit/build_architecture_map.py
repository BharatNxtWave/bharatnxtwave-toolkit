from pathlib import Path
from collections import Counter, defaultdict
import json
import re


# ============================================================
# PATHS
# ============================================================

AUDIT_DIR = Path("confidential_source/audit")

PRIVATE_REPORT = (
    AUDIT_DIR
    / "data_quality_audit_private.json"
)

OUTPUT_REPORT = (
    AUDIT_DIR
    / "workbook_architecture_SAFE_TO_SHARE.txt"
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


# ============================================================
# SAFETY CHECKS
# ============================================================

if not PRIVATE_REPORT.exists():

    raise SystemExit(
        "STOPPED SAFELY: private Step 4 audit does not exist."
    )


try:

    report = json.loads(
        PRIVATE_REPORT.read_text(
            encoding="utf-8"
        )
    )

except Exception as exc:

    raise SystemExit(
        "STOPPED SAFELY: Step 4 audit could not be read.\n"
        f"{type(exc).__name__}: {exc}"
    )


actual_hash = report.get(
    "sha256"
)


if actual_hash != EXPECTED_SHA256:

    raise SystemExit(
        "STOPPED SAFELY: workbook fingerprint mismatch.\n"
        "Architecture analysis was not performed."
    )


if not report.get(
    "sha256_verified"
):

    raise SystemExit(
        "STOPPED SAFELY: Step 4 report did not verify SHA-256."
    )


# ============================================================
# HELPERS
# ============================================================

def normalize_header(value):

    value = str(
        value or ""
    ).casefold()

    value = re.sub(
        r"[^a-z0-9]+",
        " ",
        value,
    )

    return re.sub(
        r"\s+",
        " ",
        value,
    ).strip()


CANONICAL_ALIASES = {

    "serial_number": {
        "sr no",
        "sl no",
        "sr no",
        "sr number",
    },

    "scheme_name": {
        "scheme name",
    },

    "benefits": {
        "benefits",
    },

    "focus_sectors": {
        "focus sectors",
    },

    "eligibility": {
        "eligibility criteria",
    },

    "deadline": {
        "last date",
    },

    "organisation": {
        "funding organisation",
        "organisation",
    },

    "scheme_type": {
        "type of scheme",
    },

    "applicable_for": {
        "applicable for",
        "application for",
    },

    "portal_link": {
        "portal links",
        "portal link",
    },

    "minimum_upfront_charge": {
        "min charge upfront",
        "minimum charges",
    },

    "government_charge": {
        "govt charges if any",
        "govt registration charge",
        "govt fees vendor cost",
    },

    "additional_info": {
        "additional info",
    },

    "flyer": {
        "flyer",
    },

    "service_name": {
        "services",
    },

    "bdm_deduction": {
        "bdm deduction",
    },

    "remark": {
        "remark",
    },

    "standard": {
        "standards",
    },

    "industry": {
        "indutries",
        "industries",
    },

    "short_full_name": {
        "short name full name",
    },

    "iaf_ias": {
        "iaf ias",
    },

    "non_iaf": {
        "non iaf",
    },
}


def canonical_field(header):

    normalized = normalize_header(
        header
    )

    for canonical, aliases in CANONICAL_ALIASES.items():

        if normalized in aliases:
            return canonical

    return (
        "unmapped:"
        + normalized.replace(
            " ",
            "_",
        )
    )


# ============================================================
# GROUP SHEETS
# ============================================================

scheme_sheets = []

reference_sheets = []

matrix_sheets = []

manual_sheets = []


for sheet in report.get(
    "sheets",
    []
):

    classification = sheet.get(
        "classification"
    )


    if classification == "SCHEME_TABLE":

        scheme_sheets.append(
            sheet
        )


    elif classification == "REFERENCE_TABLE":

        reference_sheets.append(
            sheet
        )


    elif classification == "COMPARISON_MATRIX":

        matrix_sheets.append(
            sheet
        )


    else:

        manual_sheets.append(
            sheet
        )


# ============================================================
# STRUCTURED SCHEME FIELD ANALYSIS
# ============================================================

sheet_field_sets = {}

field_presence = Counter()

total_scheme_rows = 0


for sheet in scheme_sheets:

    total_scheme_rows += int(
        sheet.get(
            "record_rows",
            0
        )
        or 0
    )


    fields = set()


    for column in sheet.get(
        "columns",
        []
    ):

        canonical = canonical_field(
            column.get(
                "header"
            )
        )

        fields.add(
            canonical
        )


    sheet_field_sets[
        sheet["sheet"]
    ] = fields


    for field in fields:

        field_presence[
            field
        ] += 1


scheme_sheet_count = len(
    scheme_sheets
)


universal_fields = sorted(
    field
    for field, count
    in field_presence.items()
    if count == scheme_sheet_count
)


partial_fields = sorted(
    (
        field,
        count,
    )
    for field, count
    in field_presence.items()
    if count != scheme_sheet_count
)


# ============================================================
# QUALITY RISK COUNTERS
# ============================================================

total_blank_scheme_names = 0

total_blank_sector = 0

total_blank_eligibility = 0

total_blank_portal = 0

total_unparsed_deadlines = 0

within_sheet_duplicate_groups = 0

exact_duplicate_groups = 0


for sheet in scheme_sheets:

    quality = sheet.get(
        "quality",
        {}
    )


    blanks = quality.get(
        "blank_critical_fields",
        {}
    )


    def blank_count(field):

        item = blanks.get(
            field,
            {}
        )

        value = item.get(
            "blank_count"
        )

        return (
            int(value)
            if isinstance(
                value,
                int
            )
            else 0
        )


    total_blank_scheme_names += blank_count(
        "scheme_name"
    )

    total_blank_sector += blank_count(
        "focus_sectors"
    )

    total_blank_eligibility += blank_count(
        "eligibility"
    )

    total_blank_portal += blank_count(
        "portal_link"
    )


    deadline = quality.get(
        "deadline_quality"
    ) or {}


    total_unparsed_deadlines += len(
        deadline.get(
            "unparsed_rows",
            []
        )
    )


    within_sheet_duplicate_groups += len(
        quality.get(
            "duplicate_scheme_groups",
            []
        )
    )


    exact_duplicate_groups += len(
        quality.get(
            "exact_duplicate_row_groups",
            []
        )
    )


# ============================================================
# CROSS-SHEET DUPLICATE LOCATIONS
#
# Do not output hashes or scheme names.
# Only sheet + row locations.
# ============================================================

duplicate_section = report.get(
    "cross_sheet_scheme_duplicates",
    {}
)


duplicate_groups = duplicate_section.get(
    "locations",
    []
)


safe_duplicate_groups = []


for number, group in enumerate(
    duplicate_groups,
    start=1,
):

    safe_duplicate_groups.append({
        "group": f"DUP-{number:03}",
        "locations": group.get(
            "locations",
            []
        ),
    })


# ============================================================
# REFERENCE / MANUAL ROW COUNTS
# ============================================================

reference_rows = sum(
    int(
        sheet.get(
            "record_rows",
            0
        )
        or 0
    )
    for sheet in reference_sheets
)


matrix_rows = sum(
    int(
        sheet.get(
            "record_rows",
            0
        )
        or 0
    )
    for sheet in matrix_sheets
)


# ============================================================
# BUILD SAFE REPORT
# ============================================================

lines = []


def add(value=""):

    lines.append(
        str(value)
    )


add("=" * 80)

add(
    "BHARATNXT WAVE — WORKBOOK ARCHITECTURE MAP"
)

add("=" * 80)

add()

add(
    "Source fingerprint verified: YES"
)

add(
    f"Total sheets: "
    f"{len(report.get('sheets', []))}"
)

add()


# ============================================================
# OVERVIEW
# ============================================================

add("1. WORKBOOK DATA FAMILIES")

add("-" * 80)

add(
    f"Structured scheme tables: "
    f"{len(scheme_sheets)}"
)

add(
    f"Structured scheme rows: "
    f"{total_scheme_rows}"
)

add()

add(
    f"Reference tables: "
    f"{len(reference_sheets)}"
)

add(
    f"Reference-table active rows: "
    f"{reference_rows}"
)

add()

add(
    f"Comparison matrices: "
    f"{len(matrix_sheets)}"
)

add(
    f"Comparison-matrix active rows: "
    f"{matrix_rows}"
)

add()

add(
    f"Manual/narrative sheets: "
    f"{len(manual_sheets)}"
)

add()


# ============================================================
# SHEET ROLE
# ============================================================

add("2. SHEET-BY-SHEET ROLE")

add("-" * 80)


for sheet in report["sheets"]:

    role = {

        "SCHEME_TABLE":
            "Candidate for structured Service import",

        "REFERENCE_TABLE":
            "Reference/internal supporting data",

        "COMPARISON_MATRIX":
            "Comparison knowledge; do NOT import row-by-row as Services",

        "MANUAL_STRUCTURAL_REVIEW":
            "Narrative/custom structure; inspect separately",

    }.get(
        sheet.get(
            "classification"
        ),
        "Manual review",
    )


    add(
        f"{sheet['sheet']:<24} "
        f"→ {role}"
    )


add()


# ============================================================
# CORE SCHEME SCHEMA
# ============================================================

add("3. COMMON SCHEME DATA MODEL")

add("-" * 80)

add(
    "Fields found in EVERY structured scheme table:"
)

add()


for field in universal_fields:

    add(
        f"  ✓ {field}"
    )


add()

add(
    "Fields present only in SOME structured scheme tables:"
)

add()


for field, count in partial_fields:

    add(
        f"  • {field}: "
        f"{count}/{scheme_sheet_count} sheets"
    )


add()


# ============================================================
# PER SHEET DEVIATIONS
# ============================================================

add("4. SCHEME-TABLE FIELD COVERAGE")

add("-" * 80)


all_scheme_fields = set()

for fields in sheet_field_sets.values():

    all_scheme_fields |= fields


for sheet_name, fields in sheet_field_sets.items():

    missing = sorted(
        all_scheme_fields
        - fields
    )


    add(
        sheet_name
    )


    add(
        f"  Fields detected: "
        f"{len(fields)}"
    )


    if missing:

        add(
            "  Fields not present in this sheet:"
        )

        for field in missing:

            add(
                f"    - {field}"
            )

    else:

        add(
            "  No schema deviations detected."
        )


    add()


# ============================================================
# DATA QUALITY
# ============================================================

add("5. IMPORT RISKS FOUND")

add("-" * 80)


add(
    "Blank scheme-name cells: "
    f"{total_blank_scheme_names}"
)

add(
    "Blank focus-sector cells: "
    f"{total_blank_sector}"
)

add(
    "Blank eligibility cells: "
    f"{total_blank_eligibility}"
)

add(
    "Blank portal-link cells: "
    f"{total_blank_portal}"
)

add(
    "Deadline cells requiring custom parsing/review: "
    f"{total_unparsed_deadlines}"
)

add(
    "Within-sheet duplicate scheme-name groups: "
    f"{within_sheet_duplicate_groups}"
)

add(
    "Exact duplicate-row groups in scheme tables: "
    f"{exact_duplicate_groups}"
)

add(
    "Cross-sheet duplicate scheme names: "
    f"{duplicate_section.get('unique_duplicate_names', 0)}"
)

add(
    "Cross-sheet duplicate occurrences: "
    f"{duplicate_section.get('duplicate_occurrences', 0)}"
)

add()


# ============================================================
# DUPLICATE LOCATIONS
# ============================================================

add("6. CROSS-SHEET DUPLICATE LOCATIONS")

add("-" * 80)

add(
    "Scheme names are intentionally NOT printed."
)

add(
    "These are locations only."
)

add()


if not safe_duplicate_groups:

    add(
        "No cross-sheet duplicate groups found."
    )


for group in safe_duplicate_groups:

    locations = []

    for location in group[
        "locations"
    ]:

        locations.append(
            f"{location.get('sheet')}"
            f":row {location.get('row')}"
        )


    add(
        f"{group['group']} → "
        + ", ".join(
            locations
        )
    )


add()


# ============================================================
# TARGET ARCHITECTURE
# ============================================================

add("7. PROVISIONAL TOOLKIT DATA ARCHITECTURE")

add("-" * 80)

add(
    "A. SERVICE / SCHEME"
)

add(
    "   One canonical record for one real scheme/service."
)

add(
    "   Do NOT create duplicate Service records merely because"
)

add(
    "   the same scheme appears in multiple Excel tabs."
)

add()

add(
    "B. SERVICE CLASSIFICATION"
)

add(
    "   Stores categories/tags such as Grant, Women Grant,"
)

add(
    "   Agriculture Fund, Equity, Loan, Loan Subsidy, etc."
)

add(
    "   One Service may belong to more than one classification."
)

add()

add(
    "C. SERVICE SOURCE"
)

add(
    "   Stores workbook, sheet, row and import-event lineage."
)

add(
    "   This allows every Toolkit record to be traced back"
)

add(
    "   to its original Excel location."
)

add()

add(
    "D. SERVICE LINK"
)

add(
    "   Preserve the real Excel hyperlink TARGET,"
)

add(
    "   not just the text displayed inside the cell."
)

add()

add(
    "E. SERVICE DOCUMENT / FLYER REFERENCE"
)

add(
    "   Preserve flyer references separately from normal text."
)

add()

add(
    "F. DEADLINE"
)

add(
    "   Preserve BOTH:"
)

add(
    "     - original deadline text"
)

add(
    "     - normalized date/status when confidently understood"
)

add(
    "   Never invent a date from unclear source text."
)

add()

add(
    "G. COMMERCIAL / CHARGE INFORMATION"
)

add(
    "   Keep charges separate from public scheme information."
)

add(
    "   Raw Excel text must be retained because the source"
)

add(
    "   is not consistently numeric."
)

add()

add(
    "H. REFERENCE DATA"
)

add(
    "   BENEFITS and AMOUNT DEDUCTIONS should not be imported"
)

add(
    "   as ordinary schemes."
)

add()

add(
    "I. COMPARISON MATRIX"
)

add(
    "   LOAN is a cross-scheme comparison structure."
)

add(
    "   It requires a comparison/knowledge model instead of"
)

add(
    "   one Service record per spreadsheet row."
)

add()

add(
    "J. KNOWLEDGE / PROCESS CONTENT"
)

add(
    "   START_UP INDIA, TAX_CERT, SEED FUND, PVT, LLP,"
)

add(
    "   ONBOARDING_MAIL and Rolling_Grants require separate"
)

add(
    "   structural review before any import mapping."
)

add()


# ============================================================
# SECURITY
# ============================================================

add("8. SECURITY / VISIBILITY CLASSIFICATION")

add("-" * 80)

add(
    "Normal scheme information:"
)

add(
    "  Candidate for BDE visibility after validation."
)

add()

add(
    "Commercial fields such as minimum charges:"
)

add(
    "  ACCESS DECISION REQUIRED before exposing to BDE users."
)

add()

add(
    "Vendor cost / government cost / BDM deduction / remarks:"
)

add(
    "  Treat as sensitive internal commercial information."
)

add(
    "  Do not expose through normal public/BDE search until"
)

add(
    "  an explicit role-access decision is made."
)

add()

add(
    "Source workbook:"
)

add(
    "  Remains local and excluded from Git."
)

add()


# ============================================================
# IMPORT POLICY
# ============================================================

add("9. IMPORT POLICY")

add("-" * 80)

add(
    "The final importer must:"
)

add()

add(
    "  1. Never overwrite the original workbook."
)

add(
    "  2. Never import immediately after upload."
)

add(
    "  3. Preserve source sheet + row lineage."
)

add(
    "  4. Detect cross-sheet duplicate schemes."
)

add(
    "  5. Preserve raw source text before normalization."
)

add(
    "  6. Extract actual hyperlink targets."
)

add(
    "  7. Handle merged cells explicitly."
)

add(
    "  8. Keep commercial/internal fields access-controlled."
)

add(
    "  9. Dry-run before database writes."
)

add(
    " 10. Import a small controlled sample before full import."
)

add(
    " 11. Support rollback/removal by Import Event."
)

add(
    " 12. Never silently discard an Excel field."
)

add()


# ============================================================
# NEXT STEP
# ============================================================

add("10. NEXT ENGINEERING STEP")

add("-" * 80)

add(
    "Compare this real workbook architecture against the"
)

add(
    "CURRENT Django models."
)

add()

add(
    "We must determine:"
)

add(
    "  - which Excel fields already have database fields"
)

add(
    "  - which database fields are missing"
)

add(
    "  - which existing fields are unsuitable"
)

add(
    "  - which relationships/tables must be added"
)

add(
    "  - which data must be BDE-visible vs admin-only"
)

add()

add(
    "NO DATABASE MIGRATIONS SHOULD BE CREATED UNTIL"
)

add(
    "THAT MODEL GAP ANALYSIS IS COMPLETE."
)

add()

add("=" * 80)

add(
    "NO WORKBOOK CELL VALUES ARE INCLUDED IN THIS REPORT."
)

add(
    "NO EXCEL FILE WAS MODIFIED."
)

add(
    "NO DJANGO DATABASE DATA WAS MODIFIED."
)

add("=" * 80)


# ============================================================
# WRITE REPORT
# ============================================================

OUTPUT_REPORT.write_text(
    "\n".join(
        lines
    ),
    encoding="utf-8",
)


print("")
print("=" * 80)

print(
    "STEP 5 — WORKBOOK ARCHITECTURE MAP COMPLETE"
)

print("=" * 80)

print("")

print(
    f"Structured scheme tables: "
    f"{len(scheme_sheets)}"
)

print(
    f"Structured scheme rows: "
    f"{total_scheme_rows}"
)

print(
    f"Reference tables: "
    f"{len(reference_sheets)}"
)

print(
    f"Comparison matrices: "
    f"{len(matrix_sheets)}"
)

print(
    f"Manual/custom sheets: "
    f"{len(manual_sheets)}"
)

print("")

print(
    "Cross-sheet duplicate scheme names: "
    f"{duplicate_section.get('unique_duplicate_names', 0)}"
)

print("")

print(
    "SAFE REPORT:"
)

print(
    OUTPUT_REPORT
)

print("")

print(
    "NO WORKBOOK DATA WAS MODIFIED."
)

print(
    "NO DJANGO DATA WAS MODIFIED."
)
