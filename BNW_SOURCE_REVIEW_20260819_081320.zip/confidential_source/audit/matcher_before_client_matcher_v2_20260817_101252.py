import re
from decimal import Decimal

from django.utils import timezone


STATE_WILDCARDS = {
    "all india",
    "pan india",
    "all states",
    "any state",
    "india",
    "nationwide",
}

GENERIC_WILDCARDS = {
    "all",
    "any",
    "all businesses",
    "all business types",
    "all stages",
    "all sectors",
    "all industries",
    "all founders",
    "all categories",
}


def normalize(value):
    value = str(value or "").strip().lower()

    value = re.sub(
        r"\s+",
        " ",
        value
    )

    return value


def clean_list(values):
    if not isinstance(values, list):
        return []

    return [
        str(value).strip()
        for value in values
        if str(value).strip()
    ]


def display_values(values):
    cleaned = clean_list(values)

    if not cleaned:
        return "Not specified"

    return ", ".join(cleaned)


def categorical_check(
    client_value,
    service_values,
    label,
    wildcard_values=None,
):
    allowed = clean_list(
        service_values
    )

    if not allowed:
        return None

    if not client_value:
        return {
            "state": "unknown",
            "reason": (
                f"{label} is required by this service "
                "but was not provided."
            ),
        }

    client_normalized = normalize(
        client_value
    )

    allowed_normalized = {
        normalize(value)
        for value in allowed
    }

    wildcards = set(
        GENERIC_WILDCARDS
    )

    if wildcard_values:
        wildcards.update(
            wildcard_values
        )

    if (
        allowed_normalized
        & wildcards
    ):
        return {
            "state": "match",
            "reason": (
                f"{label}: applicable broadly."
            ),
        }

    if client_normalized in allowed_normalized:
        return {
            "state": "match",
            "reason": (
                f"{label} matches: "
                f"{client_value}."
            ),
        }

    return {
        "state": "mismatch",
        "reason": (
            f"{label} mismatch. Toolkit allows: "
            f"{display_values(allowed)}."
        ),
    }


def age_check(
    client_age_months,
    minimum,
    maximum,
):
    if (
        minimum is None
        and maximum is None
    ):
        return None

    if client_age_months is None:
        return {
            "state": "unknown",
            "reason": (
                "Business age criteria exists, "
                "but client business age was not provided."
            ),
        }

    if (
        minimum is not None
        and client_age_months < minimum
    ):
        return {
            "state": "mismatch",
            "reason": (
                "Business is too new. "
                f"Minimum age: {minimum} months."
            ),
        }

    if (
        maximum is not None
        and client_age_months > maximum
    ):
        return {
            "state": "mismatch",
            "reason": (
                "Business exceeds the maximum age. "
                f"Maximum age: {maximum} months."
            ),
        }

    return {
        "state": "match",
        "reason": (
            "Business age is within the "
            "toolkit eligibility range."
        ),
    }


def turnover_check(
    client_turnover,
    minimum,
    maximum,
):
    if (
        minimum is None
        and maximum is None
    ):
        return None

    if client_turnover is None:
        return {
            "state": "unknown",
            "reason": (
                "Turnover criteria exists, "
                "but client turnover was not provided."
            ),
        }

    if (
        minimum is not None
        and client_turnover < minimum
    ):
        return {
            "state": "mismatch",
            "reason": (
                "Client turnover is below the "
                f"minimum requirement of ₹{minimum:,.0f}."
            ),
        }

    if (
        maximum is not None
        and client_turnover > maximum
    ):
        return {
            "state": "mismatch",
            "reason": (
                "Client turnover exceeds the "
                f"maximum limit of ₹{maximum:,.0f}."
            ),
        }

    return {
        "state": "match",
        "reason": (
            "Annual turnover is within the "
            "toolkit eligibility range."
        ),
    }


SEARCH_STOPWORDS = {
    "related",
    "relating",
    "for",
    "the",
    "a",
    "an",
    "to",
    "of",
    "and",
    "or",
    "client",
    "company",
    "business",
    "scheme",
    "schemes",
    "service",
    "services",
    "looking",
    "need",
    "needs",
}


def keyword_matches(
    service,
    keyword,
):
    query = normalize(
        keyword
    )

    if not query:
        return True

    searchable_values = [
        service.service_id,
        service.title,
        service.domain.name,
        service.category.name,
        service.bde_summary,
        service.overview,
        service.benefits,
        service.eligibility_summary,
        service.restrictions,
        service.important_notes,
        service.funding_type,
        service.subsidy_details,
    ]

    searchable_values.extend(
        clean_list(
            service.industries
        )
    )

    searchable_values.extend(
        clean_list(
            service.business_types
        )
    )

    searchable_values.extend(
        clean_list(
            service.business_stages
        )
    )

    searchable_text = " ".join(
        normalize(value)
        for value in searchable_values
        if value
    )


    # Exact phrase is strongest.
    if query in searchable_text:
        return True


    # Natural queries such as
    # "technology related schemes"
    # become meaningful terms such as
    # ["technology"].
    tokens = re.findall(
        r"[a-z0-9]+",
        query
    )

    meaningful_tokens = [
        token
        for token in tokens
        if (
            len(token) > 2
            and token
            not in SEARCH_STOPWORDS
        )
    ]


    if not meaningful_tokens:
        meaningful_tokens = [
            token
            for token in tokens
            if len(token) > 2
        ]


    if not meaningful_tokens:
        return False


    # Deterministic matching:
    # every meaningful term must exist
    # somewhere in the actual Toolkit record.
    return all(
        token in searchable_text
        for token in meaningful_tokens
    )


def evaluate_service(
    service,
    profile,
):
    checks = []

    categorical_fields = [
        (
            profile.get(
                "business_type"
            ),
            service.business_types,
            "Business type",
            None,
        ),
        (
            profile.get(
                "business_stage"
            ),
            service.business_stages,
            "Business stage",
            None,
        ),
        (
            profile.get(
                "industry"
            ),
            service.industries,
            "Industry",
            None,
        ),
        (
            profile.get(
                "state"
            ),
            service.applicable_states,
            "State",
            STATE_WILDCARDS,
        ),
        (
            profile.get(
                "founder_category"
            ),
            service.founder_categories,
            "Founder category",
            None,
        ),
    ]

    for (
        client_value,
        service_values,
        label,
        wildcards,
    ) in categorical_fields:

        result = categorical_check(
            client_value,
            service_values,
            label,
            wildcard_values=wildcards,
        )

        if result:
            checks.append(
                result
            )


    age_result = age_check(
        profile.get(
            "business_age_months"
        ),
        service.min_business_age_months,
        service.max_business_age_months,
    )

    if age_result:
        checks.append(
            age_result
        )


    turnover_result = turnover_check(
        profile.get(
            "annual_turnover"
        ),
        service.min_turnover,
        service.max_turnover,
    )

    if turnover_result:
        checks.append(
            turnover_result
        )


    # Current toolkit deadline is treated as an
    # explicit eligibility warning.
    if (
        service.application_deadline
        and (
            service.application_deadline
            < timezone.localdate()
        )
    ):
        checks.append(
            {
                "state": "mismatch",
                "reason": (
                    "Application deadline recorded in "
                    "the toolkit has already passed."
                ),
            }
        )


    matches = [
        item
        for item in checks
        if item["state"] == "match"
    ]

    mismatches = [
        item
        for item in checks
        if item["state"] == "mismatch"
    ]

    unknowns = [
        item
        for item in checks
        if item["state"] == "unknown"
    ]


    if mismatches:
        classification = (
            "NOT_ELIGIBLE"
        )

    elif matches and not unknowns:
        classification = (
            "HIGH"
        )

    else:
        classification = (
            "POSSIBLE"
        )


    return {
        "service": service,

        "classification": (
            classification
        ),

        "matches": matches,
        "mismatches": mismatches,
        "unknowns": unknowns,

        "matched_count": len(
            matches
        ),

        "criteria_count": len(
            checks
        ),

        "unknown_count": len(
            unknowns
        ),
    }


def build_matches(
    services,
    profile,
):
    keyword = profile.get(
        "need_query",
        ""
    )

    requested_kinds = set(
        profile.get(
            "service_kinds",
            []
        )
    )

    high = []
    possible = []
    not_eligible = []

    for service in services:

        if (
            requested_kinds
            and (
                service.service_kind
                not in requested_kinds
            )
        ):
            continue

        if not keyword_matches(
            service,
            keyword
        ):
            continue

        result = evaluate_service(
            service,
            profile,
        )

        if (
            result["classification"]
            == "HIGH"
        ):
            high.append(
                result
            )

        elif (
            result["classification"]
            == "POSSIBLE"
        ):
            possible.append(
                result
            )

        else:
            not_eligible.append(
                result
            )


    def sort_key(item):
        priority_rank = {
            "CRITICAL": 4,
            "HIGH": 3,
            "NORMAL": 2,
            "LOW": 1,
        }

        return (
            item["matched_count"],
            -item["unknown_count"],
            priority_rank.get(
                item["service"].priority,
                0
            ),
        )


    high.sort(
        key=sort_key,
        reverse=True,
    )

    possible.sort(
        key=sort_key,
        reverse=True,
    )

    not_eligible.sort(
        key=lambda item: (
            len(item["mismatches"]),
            -item["matched_count"],
        )
    )


    return {
        "high": high[:50],
        "possible": possible[:50],
        "not_eligible": (
            not_eligible[:50]
        ),

        "high_count": len(
            high
        ),

        "possible_count": len(
            possible
        ),

        "not_eligible_count": len(
            not_eligible
        ),
    }
