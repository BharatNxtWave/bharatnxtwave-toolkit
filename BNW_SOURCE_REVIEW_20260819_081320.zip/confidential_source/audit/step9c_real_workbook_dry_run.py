from pathlib import Path

from toolkit.importing.workbook_reader import (
    file_sha256,
    inspect_workbook,
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


SOURCE_DIR = Path(
    "confidential_source"
)


matches = []

for candidate in SOURCE_DIR.glob(
    "*.xlsx"
):

    if candidate.name.startswith(
        "~$"
    ):
        continue

    try:
        digest = file_sha256(
            candidate
        )
    except OSError:
        continue

    if digest == EXPECTED_SHA256:
        matches.append(
            candidate
        )


if len(matches) != 1:

    raise SystemExit(
        "STOPPED SAFELY: expected exactly one workbook "
        "matching the approved SHA-256; "
        f"found {len(matches)}."
    )


workbook_path = matches[0]

result = inspect_workbook(
    workbook_path
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 9C REAL WORKBOOK DRY RUN"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Workbook SHA-256 verified: YES"
)

lines.append(
    f"Workbook sheets: {result['sheet_count']}"
)

lines.append(
    "Workbook cell values included in this report: NO"
)

lines.append("")

lines.append(
    "STRUCTURED SCHEME TOTAL"
)

lines.append(
    f"Active structured rows: "
    f"{result['structured_scheme_rows']}"
)

lines.append("")

lines.append(
    "CROSS-SHEET DUPLICATE CANDIDATES"
)

lines.append(
    f"Distinct duplicated normalized names: "
    f"{result['cross_sheet_duplicate_names']}"
)

lines.append(
    f"Total cross-sheet occurrences: "
    f"{result['cross_sheet_duplicate_occurrences']}"
)

lines.append("")

lines.append(
    "EXPECTED SHEET CHECK"
)

lines.append(
    "Missing expected sheets: "
    + (
        ", ".join(
            result[
                "missing_expected_sheets"
            ]
        )
        or "NONE"
    )
)

lines.append(
    "Unexpected sheets: "
    + (
        ", ".join(
            result[
                "unexpected_sheets"
            ]
        )
        or "NONE"
    )
)

lines.append("")


for sheet in result["sheets"]:

    lines.append(
        "-" * 80
    )

    lines.append(
        f"{sheet['name']} "
        f"[{sheet['family']}]"
    )

    if (
        sheet["family"]
        == "SCHEME_TABLE"
    ):

        lines.append(
            f"Header row: "
            f"{sheet['header_row']}"
        )

        lines.append(
            "Mapped fields: "
            + (
                ", ".join(
                    sheet["fields"]
                )
                or "NONE"
            )
        )

        lines.append(
            f"Active rows: "
            f"{sheet['active_rows']}"
        )

        lines.append(
            f"Rows missing scheme name: "
            f"{sheet['rows_missing_scheme_name']}"
        )

        lines.append(
            f"Excel hyperlink cells in portal field: "
            f"{sheet['portal_hyperlink_cells']}"
        )

        lines.append(
            f"Merged ranges: "
            f"{sheet['merged_ranges']}"
        )

    else:

        lines.append(
            f"Meaningful rows: "
            f"{sheet['meaningful_rows']}"
        )

        lines.append(
            f"Populated cells: "
            f"{sheet['populated_cells']}"
        )

        lines.append(
            f"Hyperlink cells: "
            f"{sheet['hyperlink_cells']}"
        )

        lines.append(
            f"Merged ranges: "
            f"{sheet['merged_ranges']}"
        )

    lines.append("")


lines.append(
    "=" * 80
)

lines.append(
    "SAFETY"
)

lines.append(
    "=" * 80
)

lines.append(
    "No Django database records were created or changed."
)

lines.append(
    "No Service records were created or changed."
)

lines.append(
    "No ImportRow records were created."
)

lines.append(
    "No migration was created or applied."
)

lines.append(
    "The Excel workbook was opened read-only in practice "
    "and was never saved."
)

lines.append(
    "No workbook cell values are printed in this report."
)


output = (
    SOURCE_DIR
    / "audit"
    / "step9c_real_workbook_SAFE_TO_SHARE.txt"
)

output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 9C DRY RUN COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
