#!/usr/bin/env bash
set -euo pipefail

cd "/mnt/d/BharatNXT Wave/BharatNXTwave Toolkit"
source .venv/bin/activate

echo ""
echo "============================================================"
echo "STEP 10M — CONTRACT EXECUTION CONSISTENCY PATCH"
echo "============================================================"

python - <<'PY'
import copy
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import os
import sys

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

root = str(Path.cwd())

if root not in sys.path:
    sys.path.insert(0, root)

import django
django.setup()

from toolkit.models import (
    ImportBatch,
    ImportRow,
    Service,
    ServiceDomain,
    Category,
    ImportChange,
    ServiceClassification,
    ServiceSource,
    ServiceCommercial,
    ServiceContentSection,
    ReferenceItem,
    ComparisonMatrix,
    ComparisonEntry,
    CommunicationTemplate,
)


# ============================================================
# CONSTANTS
# ============================================================

AUDIT_DIR = Path(
    "confidential_source/audit"
)

V2_PATH = (
    AUDIT_DIR
    / "step10_mapping_contract_v2.json"
)

V2_MANIFEST_PATH = (
    AUDIT_DIR
    / "step10l_final_import_plan_manifest.json"
)

EXPECTED_V2_SHA256 = (
    "1040d6c278fd47f2ac1ab67f6eba2d012"
    "bf6355b090faff1d0c7a4c2534a1168"
)

EXPECTED_V2_MANIFEST_SHA256 = (
    "fbd08cdf36695a20899262bf36b87c747"
    "b1f291caa64605f162bcd80ea5d4ab1"
)

SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

V3_PATH = (
    AUDIT_DIR
    / "step10_mapping_contract_v3.json"
)

V3_HASH_PATH = (
    AUDIT_DIR
    / "step10_mapping_contract_v3.json.sha256"
)

MANIFEST_V2_PATH = (
    AUDIT_DIR
    / "step10m_final_import_plan_manifest_v2.json"
)

MANIFEST_V2_HASH_PATH = (
    AUDIT_DIR
    / "step10m_final_import_plan_manifest_v2.json.sha256"
)

SAFE_REPORT = (
    AUDIT_DIR
    / "step10m_contract_consistency_SAFE_TO_SHARE.txt"
)


# ============================================================
# HELPERS
# ============================================================

def sha256_bytes(data):
    return hashlib.sha256(
        data
    ).hexdigest()


def canonical_json(data):
    return (
        json.dumps(
            data,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
        )
        + "\n"
    ).encode(
        "utf-8"
    )


def raw(row):
    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):
    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):
    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):
    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return str(value).strip()


# ============================================================
# VERIFY FROZEN V2
# ============================================================

if not V2_PATH.exists():
    raise SystemExit(
        "STOPPED SAFELY: frozen Contract v2 missing."
    )

if not V2_MANIFEST_PATH.exists():
    raise SystemExit(
        "STOPPED SAFELY: frozen v2 manifest missing."
    )


v2_bytes = V2_PATH.read_bytes()

v2_manifest_bytes = (
    V2_MANIFEST_PATH.read_bytes()
)


if (
    sha256_bytes(v2_bytes)
    != EXPECTED_V2_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: Contract v2 SHA-256 changed."
    )


if (
    sha256_bytes(v2_manifest_bytes)
    != EXPECTED_V2_MANIFEST_SHA256
):
    raise SystemExit(
        "STOPPED SAFELY: v2 import manifest "
        "SHA-256 changed."
    )


v2 = json.loads(
    v2_bytes.decode(
        "utf-8"
    )
)

old_manifest = json.loads(
    v2_manifest_bytes.decode(
        "utf-8"
    )
)


# ============================================================
# VERIFY DB STATE
# ============================================================

batch = ImportBatch.objects.get(
    pk=5
)


if batch.file_sha256 != SOURCE_SHA256:
    raise SystemExit(
        "STOPPED SAFELY: staged source hash changed."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
)


if len(rows) != 478:
    raise SystemExit(
        "STOPPED SAFELY: expected 478 ImportRows."
    )


expected_counts = {
    "Service": (
        Service.objects.count(),
        1,
    ),
    "ServiceDomain": (
        ServiceDomain.objects.count(),
        8,
    ),
    "Category": (
        Category.objects.count(),
        32,
    ),
    "ImportChange": (
        ImportChange.objects.count(),
        0,
    ),
    "ServiceClassification": (
        ServiceClassification.objects.count(),
        0,
    ),
    "ServiceSource": (
        ServiceSource.objects.count(),
        0,
    ),
    "ServiceCommercial": (
        ServiceCommercial.objects.count(),
        0,
    ),
    "ServiceContentSection": (
        ServiceContentSection.objects.count(),
        0,
    ),
    "ReferenceItem": (
        ReferenceItem.objects.count(),
        0,
    ),
    "ComparisonMatrix": (
        ComparisonMatrix.objects.count(),
        0,
    ),
    "ComparisonEntry": (
        ComparisonEntry.objects.count(),
        0,
    ),
    "CommunicationTemplate": (
        CommunicationTemplate.objects.count(),
        0,
    ),
}


for name, (
    actual,
    wanted,
) in expected_counts.items():

    if actual != wanted:
        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} count changed "
            f"({actual} != {wanted})."
        )


# ============================================================
# VERIFY STRUCTURED COMMERCIAL COVERAGE
# ============================================================

structured_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
        and row.source_key
    )
]


groups = defaultdict(
    list
)


for row in structured_rows:
    groups[
        row.source_key
    ].append(
        row
    )


if len(groups) != 100:
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 structured identities."
    )


structured_with_minimum_charge = 0

minimum_charge_conflicts = 0

structured_government_charge_candidates = 0


for identity, group in groups.items():

    minimum_values = {
        payload_value(
            fields(row).get(
                "minimum_charge",
                {},
            )
        )
        for row in group
    }

    minimum_values.discard(
        ""
    )


    if minimum_values:

        structured_with_minimum_charge += 1


    if len(minimum_values) > 1:

        minimum_charge_conflicts += 1


    government_values = {
        payload_value(
            fields(row).get(
                "government_charge",
                {},
            )
        )
        for row in group
    }

    government_values.discard(
        ""
    )


    if government_values:

        structured_government_charge_candidates += 1


if (
    structured_with_minimum_charge
    != 99
):
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "99 structured Services with "
        "minimum-charge source data."
    )


if minimum_charge_conflicts != 0:
    raise SystemExit(
        "STOPPED SAFELY: structured "
        "minimum-charge conflicts detected."
    )


if (
    structured_government_charge_candidates
    != 3
):
    raise SystemExit(
        "STOPPED SAFELY: expected "
        "3 structured government/additional "
        "charge candidates."
    )


# ============================================================
# CREATE CONTRACT V3
# ============================================================

v3 = copy.deepcopy(
    v2
)


v3[
    "contract"
][
    "version"
] = 3


v3[
    "contract"
][
    "supersedes_version"
] = 2


v3[
    "contract"
][
    "previous_contract_sha256"
] = EXPECTED_V2_SHA256


v3[
    "contract"
][
    "execution_consistency_patch"
] = (
    "Adds explicit structured ServiceCommercial "
    "record policy required by the already-frozen "
    "structured minimum_charge field mapping."
)


v3[
    "structured_commercial"
] = {

    "canonical_services_with_minimum_charge": 99,

    "minimum_charge_conflict_groups": 0,

    "record_policy": (
        "Create at most one structured "
        "ServiceCommercial record per canonical "
        "Service when minimum_charge_raw exists."
    ),

    "minimum_charge_source": (
        "structured minimum_charge canonical field"
    ),

    "minimum_charge_raw": True,

    "numeric_auto_parse": False,

    "default_visibility": (
        "ADMIN_ONLY"
    ),

    "source_import_row_policy": (
        "Use first source row containing the "
        "canonical minimum-charge value."
    ),

    "duplicate_source_lineage": (
        "Other duplicate ImportRows remain linked "
        "to the canonical Service separately."
    ),

    "government_charge_candidates": 3,

    "government_fee_auto_mapping": False,

    "government_charge_policy": (
        "Preserve candidate source payload in "
        "ImportRow until exact header semantics "
        "justify government_fee_raw mapping."
    ),

    "never_copy_to_legacy_service_fee_fields": True,
}


v3_bytes = canonical_json(
    v3
)

v3_hash = sha256_bytes(
    v3_bytes
)


if V3_PATH.exists():

    existing = (
        V3_PATH.read_bytes()
    )

    if existing != v3_bytes:

        raise SystemExit(
            "STOPPED SAFELY: Contract v3 "
            "already exists with different content."
        )

else:

    V3_PATH.write_bytes(
        v3_bytes
    )


V3_HASH_PATH.write_text(
    f"{v3_hash}  "
    f"{V3_PATH.name}\n",
    encoding="utf-8",
)


# ============================================================
# CORRECTED IMPORT MANIFEST V2
# ============================================================

manifest = copy.deepcopy(
    old_manifest
)


manifest[
    "manifest"
][
    "version"
] = 2


manifest[
    "manifest"
][
    "mapping_contract_version"
] = 3


manifest[
    "manifest"
][
    "mapping_contract_sha256"
] = v3_hash


manifest[
    "manifest"
][
    "supersedes_manifest_sha256"
] = EXPECTED_V2_MANIFEST_SHA256


manifest[
    "planned_database_changes"
][
    "ServiceCommercial"
] = {

    "structured_canonical_records": 99,

    "amount_deductions_source_row_records": 62,

    "expected_total_records": 161,

    "default_visibility": "ADMIN_ONLY",

    "numeric_auto_parse": False,

    "structured_government_charge_candidates": 3,

    "structured_government_fee_auto_mapped": 0,

    "legacy_service_fee_fields_written": False,
}


manifest_bytes = canonical_json(
    manifest
)

manifest_hash = sha256_bytes(
    manifest_bytes
)


if MANIFEST_V2_PATH.exists():

    existing = (
        MANIFEST_V2_PATH.read_bytes()
    )

    if existing != manifest_bytes:

        raise SystemExit(
            "STOPPED SAFELY: corrected "
            "manifest already exists with "
            "different content."
        )

else:

    MANIFEST_V2_PATH.write_bytes(
        manifest_bytes
    )


MANIFEST_V2_HASH_PATH.write_text(
    f"{manifest_hash}  "
    f"{MANIFEST_V2_PATH.name}\n",
    encoding="utf-8",
)


# ============================================================
# SAFE REPORT
# ============================================================

lines = [
    "=" * 80,
    (
        "BHARATNXT WAVE — "
        "STEP 10M CONTRACT EXECUTION CONSISTENCY"
    ),
    "=" * 80,
    "",
    "Frozen Contract v2 verified: YES",
    (
        f"Contract v2 SHA-256: "
        f"{EXPECTED_V2_SHA256}"
    ),
    "",
    (
        f"Structured canonical Services: "
        f"{len(groups)}"
    ),
    (
        "Structured Services with "
        f"minimum-charge data: "
        f"{structured_with_minimum_charge}"
    ),
    (
        "Structured minimum-charge "
        f"conflicts: {minimum_charge_conflicts}"
    ),
    (
        "Structured government/additional "
        f"charge candidates retained for review: "
        f"{structured_government_charge_candidates}"
    ),
    "",
    "1. CORRECTED COMMERCIAL RECORD PLAN",
    "  Structured ServiceCommercial records: 99",
    "  AMOUNT DEDUCTIONS ServiceCommercial records: 62",
    "  Expected total ServiceCommercial records: 161",
    "  Numeric auto-parsing: NO",
    "  Default visibility: ADMIN_ONLY",
    "  Legacy Service fee fields written: NO",
    "",
    "2. CONTRACT",
    "  Previous Contract v2 preserved: YES",
    "  Contract v3 created: YES",
    (
        f"  Contract v3 SHA-256: "
        f"{v3_hash}"
    ),
    "",
    "3. IMPORT MANIFEST",
    "  Previous manifest preserved: YES",
    "  Corrected manifest version: 2",
    (
        f"  Corrected manifest SHA-256: "
        f"{manifest_hash}"
    ),
    "",
    "4. DATABASE SAFETY",
    "  Service records created: 0",
    "  Category records created: 0",
    "  ServiceCommercial records created: 0",
    "  ImportRow records modified: 0",
    "  Live database writes performed: NO",
    "",
    "5. NEXT PHASE",
    (
        "  BUILD FULL TRANSFORMATION ENGINE "
        "AGAINST CONTRACT V3"
    ),
]


SAFE_REPORT.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10M CONTRACT PATCH COMPLETE"
)

print(
    f"Contract v3 SHA-256: "
    f"{v3_hash}"
)

print(
    f"Corrected manifest SHA-256: "
    f"{manifest_hash}"
)

print(
    f"SAFE REPORT: {SAFE_REPORT}"
)
PY


chmod 444 \
    confidential_source/audit/step10_mapping_contract_v3.json \
    confidential_source/audit/step10_mapping_contract_v3.json.sha256 \
    confidential_source/audit/step10m_final_import_plan_manifest_v2.json \
    confidential_source/audit/step10m_final_import_plan_manifest_v2.json.sha256 \
    confidential_source/audit/step10m_contract_consistency_SAFE_TO_SHARE.txt \
    2>/dev/null || true


echo ""
echo "===== CONTRACT V3 HASH ====="

cat \
    confidential_source/audit/step10_mapping_contract_v3.json.sha256


echo ""
echo "===== CORRECTED MANIFEST HASH ====="

cat \
    confidential_source/audit/step10m_final_import_plan_manifest_v2.json.sha256


echo ""
echo "===== SAFE REPORT ====="

cat \
    confidential_source/audit/step10m_contract_consistency_SAFE_TO_SHARE.txt


echo ""
echo "===== FINAL CHECKS ====="

python manage.py check

python manage.py makemigrations \
    --check \
    --dry-run


echo ""
echo "============================================================"
echo "STEP 10M SUCCESS"
echo "============================================================"
