import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

PROJECT_ROOT = Path.cwd()

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(PROJECT_ROOT),
    )


import django
django.setup()


from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


# ============================================================
# CONSTANTS
# ============================================================

BATCH_ID = 5

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

CONTRACT_V1 = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)


KNOWLEDGE_SHEETS = (
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
)


# ============================================================
# HASH
# ============================================================

def sha256_file(path):

    digest = hashlib.sha256()

    with Path(path).open("rb") as file:

        for chunk in iter(
            lambda: file.read(
                1024 * 1024
            ),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


if (
    sha256_file(CONTRACT_V1)
    != EXPECTED_CONTRACT_SHA256
):

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 changed."
    )


# ============================================================
# BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if (
    batch.file_sha256
    != EXPECTED_SOURCE_SHA256
):

    raise SystemExit(
        "STOPPED SAFELY: ImportBatch source "
        "SHA-256 mismatch."
    )


metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if (
    metadata.get("operation")
    != "workbook_staging"
):

    raise SystemExit(
        "STOPPED SAFELY: Batch #5 is not "
        "the approved staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


if len(rows) != 478:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "478 staged rows."
    )


# ============================================================
# HELPERS
# ============================================================

def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def cells(row):

    value = raw(row).get(
        "cells",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):

    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def normalize_identity(value):

    text = payload_value(
        {
            "value": value
        }
    ).casefold()

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def column_value(
    row,
    column,
):

    return payload_value(
        cells(row).get(
            column,
            {},
        )
    )


def useful_identity(value):

    identity = normalize_identity(
        value
    )

    # Do not consider tiny labels/entity noise.
    if len(identity) < 3:
        return ""

    return identity


def classify_payload_shape(
    payload
):

    if not isinstance(
        payload,
        dict,
    ):
        return "BLANK"

    value = payload_value(
        payload
    )

    if (
        payload.get(
            "hyperlink_target"
        )
        or payload.get(
            "hyperlink_location"
        )
    ):
        return "HYPERLINK"

    if not value:
        return "BLANK"

    if (
        payload.get(
            "cell_type"
        )
        == "d"
    ):
        return "DATE"

    if re.fullmatch(
        r"[-+]?\d+(?:\.\d+)?",
        value.replace(
            ",",
            "",
        ),
    ):
        return "NUMERIC_LIKE"

    if re.search(
        r"https?://|www\.",
        value,
        flags=re.I,
    ):
        return "URL_LIKE_TEXT"

    return "TEXT"


# ============================================================
# CANONICAL STRUCTURED SERVICE IDENTITIES
# ============================================================

scheme_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
    )
]


canonical_rows = [
    row
    for row in scheme_rows
    if row.source_key
]


canonical_identities = {
    row.source_key
    for row in canonical_rows
}


if len(
    canonical_identities
) != 100:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 canonical scheme identities."
    )


# ============================================================
# BENEFITS ENTITY-LIKE KEYS
# ============================================================

benefits_rows = [
    row
    for row in rows
    if (
        row.sheet_name
        == "BENEFITS"
        and meta(row).get(
            "row_role"
        ) == "DATA"
    )
]


benefits_labels = []

for row in benefits_rows:

    identity = useful_identity(
        column_value(
            row,
            "A",
        )
    )

    if identity:
        benefits_labels.append(
            identity
        )


benefits_counter = Counter(
    benefits_labels
)

benefits_unique = set(
    benefits_labels
)

benefits_matching_canonical = (
    benefits_unique
    & canonical_identities
)

benefits_outside_canonical = (
    benefits_unique
    - canonical_identities
)


# ============================================================
# AMOUNT DEDUCTIONS SERVICE-LIKE LABELS
# ============================================================

amount_rows = [
    row
    for row in rows
    if (
        row.sheet_name
        == "AMOUNT DEDUCTIONS"
        and meta(row).get(
            "row_role"
        ) == "DATA"
    )
]


amount_labels = []

amount_blank_a = 0


for row in amount_rows:

    identity = useful_identity(
        column_value(
            row,
            "A",
        )
    )

    if identity:

        amount_labels.append(
            identity
        )

    else:

        amount_blank_a += 1


amount_counter = Counter(
    amount_labels
)

amount_unique = set(
    amount_labels
)

amount_matching_canonical = (
    amount_unique
    & canonical_identities
)

amount_outside_canonical = (
    amount_unique
    - canonical_identities
)


# ============================================================
# BENEFITS ↔ COMMERCIAL OVERLAP
# ============================================================

benefits_amount_overlap = (
    benefits_unique
    & amount_unique
)

outside_canonical_overlap = (
    benefits_outside_canonical
    & amount_outside_canonical
)


# ============================================================
# ROLLING GRANTS COLUMN ANALYSIS
# ============================================================

rolling_rows = [
    row
    for row in rows
    if row.sheet_name
    == "Rolling_Grants"
]


rolling_columns = (
    "A",
    "B",
    "C",
    "E",
)


rolling_profile = {}


for column in rolling_columns:

    identities = []

    shapes = Counter()


    for row in rolling_rows:

        payload = cells(row).get(
            column,
            {},
        )

        shapes[
            classify_payload_shape(
                payload
            )
        ] += 1


        identity = useful_identity(
            payload_value(
                payload
            )
        )

        if identity:
            identities.append(
                identity
            )


    unique = set(
        identities
    )


    rolling_profile[
        column
    ] = {
        "nonblank": len(
            identities
        ),
        "unique": len(
            unique
        ),
        "canonical_matches": len(
            unique
            & canonical_identities
        ),
        "benefits_matches": len(
            unique
            & benefits_unique
        ),
        "commercial_matches": len(
            unique
            & amount_unique
        ),
        "shapes": shapes,
    }


# ============================================================
# KNOWLEDGE SHEET CROSS-MATCH
#
# Exact normalized full-cell matching only.
# No fuzzy guessing.
# ============================================================

knowledge_profile = {}


for sheet_name in (
    KNOWLEDGE_SHEETS
):

    sheet_rows = [
        row
        for row in rows
        if row.sheet_name
        == sheet_name
    ]


    identities = []


    for row in sheet_rows:

        for payload in (
            cells(row).values()
        ):

            identity = useful_identity(
                payload_value(
                    payload
                )
            )

            if identity:
                identities.append(
                    identity
                )


    unique = set(
        identities
    )


    knowledge_profile[
        sheet_name
    ] = {
        "staged_rows": len(
            sheet_rows
        ),
        "unique_full_cell_texts": len(
            unique
        ),
        "canonical_exact_matches": len(
            unique
            & canonical_identities
        ),
        "benefits_exact_matches": len(
            unique
            & benefits_unique
        ),
        "commercial_exact_matches": len(
            unique
            & amount_unique
        ),
    }


# ============================================================
# CROSS-SHEET ENTITY-LIKE INVENTORY
#
# IMPORTANT:
# These are labels, NOT automatically Services.
# ============================================================

label_universe = (
    canonical_identities
    | benefits_unique
    | amount_unique
)


additional_label_candidates = (
    label_universe
    - canonical_identities
)


additional_supported_by_both = (
    benefits_unique
    & amount_unique
    - canonical_identities
)


benefits_only_additional = (
    benefits_outside_canonical
    - amount_unique
)


commercial_only_additional = (
    amount_outside_canonical
    - benefits_unique
)


# ============================================================
# DUPLICATE PROFILE
# ============================================================

benefits_duplicate_labels = sum(
    1
    for count in (
        benefits_counter.values()
    )
    if count > 1
)


amount_duplicate_labels = sum(
    1
    for count in (
        amount_counter.values()
    )
    if count > 1
)


# ============================================================
# ACTUAL DESTINATION MODEL SCHEMA
# ============================================================

MODEL_CLASSES = {
    "ServiceCommercial":
        ServiceCommercial,

    "ReferenceItem":
        ReferenceItem,

    "ServiceContentSection":
        ServiceContentSection,

    "ComparisonMatrix":
        ComparisonMatrix,

    "ComparisonEntry":
        ComparisonEntry,

    "CommunicationTemplate":
        CommunicationTemplate,
}


model_schema = {}


for model_name, model in (
    MODEL_CLASSES.items()
):

    entries = []


    for field in (
        model._meta.get_fields()
    ):

        # Skip reverse relations.
        if not getattr(
            field,
            "concrete",
            False,
        ):
            continue


        choices = getattr(
            field,
            "choices",
            None,
        )


        choice_values = []

        if choices:

            for choice in choices:

                try:
                    value = choice[0]
                except (
                    TypeError,
                    IndexError,
                ):
                    continue

                choice_values.append(
                    str(value)
                )


        entries.append(
            {
                "name": field.name,
                "type": (
                    field.__class__.__name__
                ),
                "null": getattr(
                    field,
                    "null",
                    False,
                ),
                "blank": getattr(
                    field,
                    "blank",
                    False,
                ),
                "unique": getattr(
                    field,
                    "unique",
                    False,
                ),
                "choices": (
                    choice_values
                ),
            }
        )


    model_schema[
        model_name
    ] = entries


# ============================================================
# LIVE SAFETY
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if (
    destination_counts["Service"]
    != 1
):

    raise SystemExit(
        "STOPPED SAFELY: Service count changed."
    )


for name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if (
        destination_counts[
            name
        ]
        != 0
    ):

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} unexpectedly contains data."
        )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10f_cross_sheet_entity_inventory_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10F CROSS-SHEET ENTITY INVENTORY"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    "Approved staged source verified: YES"
)

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    "Workbook opened: NO"
)

lines.append(
    "Database writes performed: NO"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. STRUCTURED CANONICAL INVENTORY"
)
# ------------------------------------------------------------

lines.append(
    f"  Named structured rows: "
    f"{len(canonical_rows)}"
)

lines.append(
    f"  Canonical structured identities: "
    f"{len(canonical_identities)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. BENEFITS ENTITY-LIKE KEY INVENTORY"
)
# ------------------------------------------------------------

lines.append(
    f"  Data rows: "
    f"{len(benefits_rows)}"
)

lines.append(
    f"  Nonblank normalized keys: "
    f"{len(benefits_labels)}"
)

lines.append(
    f"  Unique normalized keys: "
    f"{len(benefits_unique)}"
)

lines.append(
    f"  Duplicate normalized keys: "
    f"{benefits_duplicate_labels}"
)

lines.append(
    f"  Exact matches to canonical "
    f"structured identities: "
    f"{len(benefits_matching_canonical)}"
)

lines.append(
    f"  Keys outside canonical "
    f"structured identities: "
    f"{len(benefits_outside_canonical)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. AMOUNT DEDUCTIONS SERVICE-LIKE INVENTORY"
)
# ------------------------------------------------------------

lines.append(
    f"  Data rows: "
    f"{len(amount_rows)}"
)

lines.append(
    f"  Rows with blank Column A identity: "
    f"{amount_blank_a}"
)

lines.append(
    f"  Nonblank normalized Column A labels: "
    f"{len(amount_labels)}"
)

lines.append(
    f"  Unique normalized Column A labels: "
    f"{len(amount_unique)}"
)

lines.append(
    f"  Duplicate normalized labels: "
    f"{amount_duplicate_labels}"
)

lines.append(
    f"  Exact matches to canonical "
    f"structured identities: "
    f"{len(amount_matching_canonical)}"
)

lines.append(
    f"  Labels outside canonical "
    f"structured identities: "
    f"{len(amount_outside_canonical)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. BENEFITS ↔ AMOUNT DEDUCTIONS OVERLAP"
)
# ------------------------------------------------------------

lines.append(
    f"  Total normalized labels appearing "
    f"in both sheets: "
    f"{len(benefits_amount_overlap)}"
)

lines.append(
    f"  Shared labels outside the "
    f"100 structured identities: "
    f"{len(outside_canonical_overlap)}"
)

lines.append(
    f"  Benefits-only additional labels: "
    f"{len(benefits_only_additional)}"
)

lines.append(
    f"  Commercial-only additional labels: "
    f"{len(commercial_only_additional)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. ENTITY-LIKE LABEL UNIVERSE"
)
# ------------------------------------------------------------

lines.append(
    f"  Canonical structured identities: "
    f"{len(canonical_identities)}"
)

lines.append(
    f"  Union of structured + Benefits + "
    f"commercial labels: "
    f"{len(label_universe)}"
)

lines.append(
    f"  Additional normalized labels "
    f"outside structured 100: "
    f"{len(additional_label_candidates)}"
)

lines.append(
    f"  Additional labels supported by "
    f"both Benefits and commercial sheets: "
    f"{len(additional_supported_by_both)}"
)

lines.append(
    "  IMPORTANT: additional labels are "
    "candidates only, not yet Services."
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. ROLLING GRANTS COLUMN MATCH PROFILE"
)
# ------------------------------------------------------------

for column in rolling_columns:

    profile = rolling_profile[
        column
    ]


    shape_text = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            profile[
                "shapes"
            ].items()
        )
    )


    lines.append(
        f"  Column {column}: "
        f"nonblank={profile['nonblank']} | "
        f"unique={profile['unique']} | "
        f"canonical_matches="
        f"{profile['canonical_matches']} | "
        f"benefits_matches="
        f"{profile['benefits_matches']} | "
        f"commercial_matches="
        f"{profile['commercial_matches']} | "
        f"shapes[{shape_text}]"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. KNOWLEDGE SHEET ENTITY MATCH PROFILE"
)
# ------------------------------------------------------------

for sheet_name in (
    KNOWLEDGE_SHEETS
):

    profile = knowledge_profile[
        sheet_name
    ]


    lines.append(
        f"  {sheet_name}: "
        f"rows="
        f"{profile['staged_rows']} | "
        f"unique_full_cell_texts="
        f"{profile['unique_full_cell_texts']} | "
        f"canonical_exact_matches="
        f"{profile['canonical_exact_matches']} | "
        f"benefits_exact_matches="
        f"{profile['benefits_exact_matches']} | "
        f"commercial_exact_matches="
        f"{profile['commercial_exact_matches']}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. ACTUAL DESTINATION MODEL SCHEMA"
)
# ------------------------------------------------------------

for model_name in (
    MODEL_CLASSES
):

    lines.append(
        f"  {model_name}"
    )


    for field in (
        model_schema[
            model_name
        ]
    ):

        choices = (
            ",".join(
                field[
                    "choices"
                ]
            )
            if field[
                "choices"
            ]
            else "NONE"
        )


        lines.append(
            f"    {field['name']}: "
            f"{field['type']} | "
            f"null={field['null']} | "
            f"blank={field['blank']} | "
            f"unique={field['unique']} | "
            f"choices={choices}"
        )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "9. LIVE DESTINATION SAFETY"
)
# ------------------------------------------------------------

for key, value in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "10. WRITE / CONFIDENTIALITY SAFETY"
)
# ------------------------------------------------------------

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Destination records created: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Entity names printed: NO"
)

lines.append(
    "  Commercial values printed: NO"
)

lines.append(
    "  Benefit values printed: NO"
)

lines.append(
    "  URLs printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10F AUDIT COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
