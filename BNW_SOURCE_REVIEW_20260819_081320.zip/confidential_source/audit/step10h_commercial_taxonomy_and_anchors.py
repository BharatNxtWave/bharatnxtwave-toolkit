import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


# ============================================================
# CONSTANTS
# ============================================================

BATCH_ID = 5

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

CONTRACT_V1 = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)

EXPECTED_ROWS = 478
EXPECTED_STRUCTURED = 100
EXPECTED_COMMERCIAL = 61
EXPECTED_FINAL_PROSPECTIVE = 162


KNOWLEDGE_REVIEW_SHEETS = (
    "SEED FUND",
    "LLP",
)


# ============================================================
# HASH / BATCH SAFETY
# ============================================================

def sha256_file(path):

    digest = hashlib.sha256()

    with Path(path).open("rb") as handle:

        for chunk in iter(
            lambda: handle.read(
                1024 * 1024
            ),
            b"",
        ):
            digest.update(
                chunk
            )

    return digest.hexdigest()


if not CONTRACT_V1.exists():

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 missing."
    )


if (
    sha256_file(CONTRACT_V1)
    != EXPECTED_CONTRACT_SHA256
):

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 changed."
    )


batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if (
    batch.file_sha256
    != EXPECTED_SOURCE_SHA256
):

    raise SystemExit(
        "STOPPED SAFELY: source SHA-256 mismatch."
    )


batch_metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if (
    batch_metadata.get("operation")
    != "workbook_staging"
):

    raise SystemExit(
        "STOPPED SAFELY: Batch #5 is not "
        "the approved staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


if len(rows) != EXPECTED_ROWS:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "478 staged rows."
    )


# ============================================================
# HELPERS
# ============================================================

def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def cells(row):

    value = raw(row).get(
        "cells",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):

    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def column_value(
    row,
    column,
):

    return payload_value(
        cells(row).get(
            column,
            {},
        )
    )


def normalize_identity(value):

    if value is None:
        return ""

    text = str(
        value
    ).casefold()

    text = text.replace(
        "&",
        " and ",
    )

    text = re.sub(
        r"[_/]+",
        " ",
        text,
    )

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def anonymous_id(
    prefix,
    identity,
):

    digest = hashlib.sha256(
        identity.encode(
            "utf-8"
        )
    ).hexdigest()[:8].upper()

    return (
        f"{prefix}-{digest}"
    )


def token_set(value):

    return set(
        normalize_identity(
            value
        ).split()
    )


def exact_phrase_count(
    identity,
    texts,
):

    identity_tokens = token_set(
        identity
    )

    if not identity_tokens:

        return 0


    count = 0


    for text in texts:

        normalized = normalize_identity(
            text
        )

        text_tokens = set(
            normalized.split()
        )

        if (
            identity_tokens
            and identity_tokens.issubset(
                text_tokens
            )
        ):

            count += 1


    return count


# ============================================================
# MODEL SERVICE KIND CHOICES
# ============================================================

service_kind_choices = {
    str(value)
    for value, label
    in Service._meta.get_field(
        "service_kind"
    ).choices
}


# ============================================================
# COMMERCIAL TAXONOMY SIGNALS
#
# Conservative.
# No sheet-based invention for commercial catalogue.
# ============================================================

COMMERCIAL_KIND_RULES = {

    "REGISTRATION": (
        "registration",
        "incorporation",
        "register",
    ),

    "CERTIFICATION": (
        "certification",
        "certificate",
        "iso",
        "cert",
    ),

    "COMPLIANCE": (
        "compliance",
        "filing",
        "return",
        "compliances",
    ),

    "LEGAL": (
        "legal",
        "agreement",
        "trademark",
        "patent",
        "copyright",
    ),

    "CONSULTING": (
        "consulting",
        "consultancy",
        "advisory",
    ),

    "DIGITAL": (
        "digital",
        "website",
        "seo",
        "social media",
    ),

    "GRANT": (
        "grant",
    ),

    "LOAN": (
        "loan",
    ),

    "EQUITY": (
        "equity",
    ),

    "SUBSIDY": (
        "subsidy",
    ),

    "GOVT_SCHEME": (
        "scheme",
        "government",
        "govt",
    ),
}


def commercial_kind_signals(
    identity
):

    padded = (
        " "
        + normalize_identity(
            identity
        )
        + " "
    )


    matches = set()


    for kind, terms in (
        COMMERCIAL_KIND_RULES.items()
    ):

        if kind not in (
            service_kind_choices
        ):

            continue


        for term in terms:

            normalized_term = (
                normalize_identity(
                    term
                )
            )

            pattern = (
                r"(?:^|\s)"
                + re.escape(
                    normalized_term
                )
                + r"(?:\s|$)"
            )


            if re.search(
                pattern,
                padded.strip(),
            ):

                matches.add(
                    kind
                )

                break


    return matches


# ============================================================
# STRUCTURED SERVICE IDENTITIES
# ============================================================

structured_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
        and row.source_key
    )
]


structured_identities = set()


for row in structured_rows:

    identity = normalize_identity(
        payload_value(
            fields(row).get(
                "scheme_name",
                {},
            )
        )
    )

    if identity:

        structured_identities.add(
            identity
        )


if (
    len(structured_identities)
    != EXPECTED_STRUCTURED
):

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 structured identities."
    )


# ============================================================
# COMMERCIAL CATALOGUE
# ============================================================

amount_rows = [
    row
    for row in rows
    if (
        row.sheet_name
        == "AMOUNT DEDUCTIONS"
        and meta(row).get(
            "row_role"
        )
        == "DATA"
    )
]


commercial_rows_by_identity = defaultdict(
    list
)


for row in amount_rows:

    identity = normalize_identity(
        column_value(
            row,
            "A",
        )
    )


    if identity:

        commercial_rows_by_identity[
            identity
        ].append(
            row
        )


commercial_identities = set(
    commercial_rows_by_identity
)


if (
    len(commercial_identities)
    != EXPECTED_COMMERCIAL
):

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "61 commercial identities."
    )


# ============================================================
# COMMERCIAL KIND RESOLUTION
# ============================================================

commercial_kind_status = Counter()

commercial_kind_counts = Counter()

commercial_ambiguous_shapes = Counter()

commercial_unresolved_token_counts = Counter()

commercial_resolution = {}


for identity in sorted(
    commercial_identities
):

    signals = (
        commercial_kind_signals(
            identity
        )
    )


    if len(signals) == 1:

        kind = next(
            iter(signals)
        )

        status = (
            "RESOLVED_SINGLE_SIGNAL"
        )


        commercial_kind_counts[
            kind
        ] += 1


    elif len(signals) > 1:

        kind = None

        status = (
            "MULTIPLE_KIND_SIGNALS"
        )


        commercial_ambiguous_shapes[
            len(signals)
        ] += 1


    else:

        kind = None

        status = (
            "NO_KIND_SIGNAL"
        )


        commercial_unresolved_token_counts[
            len(
                token_set(
                    identity
                )
            )
        ] += 1


    commercial_kind_status[
        status
    ] += 1


    commercial_resolution[
        identity
    ] = {
        "status": status,
        "kind": kind,
        "signals": signals,
    }


# ============================================================
# COMMERCIAL TAXONOMY LABEL SIGNALS
#
# Classification can be richer than primary kind.
# ============================================================

COMMERCIAL_CLASSIFICATION_RULES = {

    "Registration": (
        "registration",
        "incorporation",
    ),

    "Certification": (
        "certificate",
        "certification",
        "iso",
    ),

    "Compliance": (
        "compliance",
        "filing",
        "return",
    ),

    "Legal": (
        "legal",
        "trademark",
        "patent",
        "copyright",
        "agreement",
    ),

    "Digital": (
        "digital",
        "website",
        "seo",
    ),

    "Grant": (
        "grant",
    ),

    "Loan": (
        "loan",
    ),

    "Equity": (
        "equity",
    ),

    "Subsidy": (
        "subsidy",
    ),
}


commercial_classification_counts = Counter()

commercial_classification_shape = Counter()


for identity in (
    commercial_identities
):

    normalized = normalize_identity(
        identity
    )


    classifications = set()


    for classification, terms in (
        COMMERCIAL_CLASSIFICATION_RULES.items()
    ):

        for term in terms:

            normalized_term = normalize_identity(
                term
            )


            if re.search(
                r"(?:^|\s)"
                + re.escape(
                    normalized_term
                )
                + r"(?:\s|$)",
                normalized,
            ):

                classifications.add(
                    classification
                )

                break


    commercial_classification_shape[
        len(classifications)
    ] += 1


    for classification in (
        classifications
    ):

        commercial_classification_counts[
            classification
        ] += 1


# ============================================================
# ROLLING GRANTS FINAL STRUCTURAL VALIDATION
# ============================================================

rolling_rows = [
    row
    for row in rows
    if row.sheet_name
    == "Rolling_Grants"
]


rolling_new_rows = []


for row in rolling_rows:

    identity = normalize_identity(
        column_value(
            row,
            "A",
        )
    )


    if (
        identity
        and identity
        not in structured_identities
        and identity
        not in commercial_identities
    ):

        rolling_new_rows.append(
            row
        )


if len(rolling_new_rows) != 2:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "2 new Rolling Grant candidates."
    )


rolling_new_completeness = Counter()


for row in (
    rolling_new_rows
):

    present = {
        column
        for column in (
            "A",
            "B",
            "C",
            "E",
        )
        if column_value(
            row,
            column,
        )
    }


    if present == {
        "A",
        "B",
        "C",
        "E",
    }:

        rolling_new_completeness[
            "COMPLETE_A_B_C_E"
        ] += 1

    else:

        rolling_new_completeness[
            "INCOMPLETE"
        ] += 1


# ============================================================
# KNOWLEDGE TIE-BREAK
#
# Stronger than Step 10G:
# - compare all content rows
# - count phrase containment
# - count exact normalized equality
# - earliest source-row evidence
#
# Names are never printed.
# ============================================================

knowledge_tie_break = {}


for sheet_name in (
    KNOWLEDGE_REVIEW_SHEETS
):

    sheet_rows = [
        row
        for row in rows
        if row.sheet_name
        == sheet_name
    ]


    content_entries = []


    for row in sheet_rows:

        for payload in cells(
            row
        ).values():

            text = payload_value(
                payload
            )


            if text:

                content_entries.append(
                    (
                        row.source_row_number,
                        text,
                    )
                )


    texts = [
        text
        for row_number, text
        in content_entries
    ]


    evidence = []


    for identity in (
        commercial_identities
    ):

        candidate_tokens = (
            token_set(
                identity
            )
        )


        if not candidate_tokens:

            continue


        exact_count = 0

        containment_count = 0

        earliest = None


        for row_number, text in (
            content_entries
        ):

            normalized_text = (
                normalize_identity(
                    text
                )
            )


            text_tokens = set(
                normalized_text.split()
            )


            if (
                normalized_text
                == identity
            ):

                exact_count += 1


            if (
                candidate_tokens
                and candidate_tokens.issubset(
                    text_tokens
                )
            ):

                containment_count += 1


                if (
                    earliest is None
                    or row_number
                    < earliest
                ):

                    earliest = (
                        row_number
                    )


        # Sheet-name token bonus.
        sheet_tokens = token_set(
            sheet_name
        )

        label_sheet_overlap = len(
            candidate_tokens
            & sheet_tokens
        )


        evidence.append(
            {
                "identity": identity,
                "exact": exact_count,
                "containment": (
                    containment_count
                ),
                "sheet_overlap": (
                    label_sheet_overlap
                ),
                "earliest": (
                    earliest
                    if earliest
                    is not None
                    else 999999
                ),
            }
        )


    evidence.sort(
        key=lambda item: (
            item["exact"],
            item["containment"],
            item["sheet_overlap"],
            -item["earliest"],
        ),
        reverse=True,
    )


    top = evidence[0]

    second = evidence[1]


    top_tuple = (
        top["exact"],
        top["containment"],
        top["sheet_overlap"],
        -top["earliest"],
    )

    second_tuple = (
        second["exact"],
        second["containment"],
        second["sheet_overlap"],
        -second["earliest"],
    )


    if top_tuple > second_tuple:

        if (
            top["exact"] >= 1
            or top["containment"] >= 2
        ):

            status = (
                "RESOLVED_BY_CONTENT_EVIDENCE"
            )

        else:

            status = (
                "LEADER_BUT_REVIEW_REQUIRED"
            )


    else:

        status = (
            "STILL_TIED"
        )


    knowledge_tie_break[
        sheet_name
    ] = {
        "status": status,
        "top_id": anonymous_id(
            "KC",
            top["identity"],
        ),
        "runner_id": anonymous_id(
            "KC",
            second["identity"],
        ),
        "top_exact": (
            top["exact"]
        ),
        "runner_exact": (
            second["exact"]
        ),
        "top_containment": (
            top["containment"]
        ),
        "runner_containment": (
            second["containment"]
        ),
        "top_sheet_overlap": (
            top["sheet_overlap"]
        ),
        "runner_sheet_overlap": (
            second["sheet_overlap"]
        ),
        "top_earliest": (
            top["earliest"]
            if top["earliest"]
            != 999999
            else None
        ),
        "runner_earliest": (
            second["earliest"]
            if second["earliest"]
            != 999999
            else None
        ),
    }


knowledge_resolution_counts = Counter(
    result[
        "status"
    ]
    for result in (
        knowledge_tie_break.values()
    )
)


# ============================================================
# FINAL UNIVERSE SAFETY
# ============================================================

rolling_new_identities = {
    normalize_identity(
        column_value(
            row,
            "A",
        )
    )
    for row in (
        rolling_new_rows
    )
}


final_prospective = (
    structured_identities
    | commercial_identities
    | rolling_new_identities
)


if (
    len(final_prospective)
    != EXPECTED_FINAL_PROSPECTIVE
):

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "162 prospective Service identities."
    )


# ============================================================
# DESTINATION SAFETY
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if (
    destination_counts[
        "Service"
    ]
    != 1
):

    raise SystemExit(
        "STOPPED SAFELY: Service count changed."
    )


for name in (
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):

    if (
        destination_counts[
            name
        ]
        != 0
    ):

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} unexpectedly contains data."
        )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10h_commercial_taxonomy_and_anchors_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10H COMMERCIAL TAXONOMY / FINAL ANCHORS"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    "Approved staged source verified: YES"
)

lines.append(
    f"Import Batch ID: "
    f"{batch.pk}"
)

lines.append(
    f"Prospective Service universe verified: "
    f"{len(final_prospective)}"
)

lines.append(
    "Database writes performed: NO"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. COMMERCIAL PRIMARY-KIND SIGNAL RESOLUTION"
)
# ------------------------------------------------------------

lines.append(
    f"  Commercial identities inspected: "
    f"{len(commercial_identities)}"
)


for status, count in sorted(
    commercial_kind_status.items()
):

    lines.append(
        f"  {status}: {count}"
    )


lines.append("")

lines.append(
    "  RESOLVED PRIMARY KINDS"
)


if commercial_kind_counts:

    for kind, count in sorted(
        commercial_kind_counts.items()
    ):

        lines.append(
            f"    {kind}: {count}"
        )

else:

    lines.append(
        "    NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. COMMERCIAL AMBIGUITY SHAPE"
)
# ------------------------------------------------------------

if commercial_ambiguous_shapes:

    for signal_count, count in sorted(
        commercial_ambiguous_shapes.items()
    ):

        lines.append(
            f"  Identities with "
            f"{signal_count} simultaneous kind signals: "
            f"{count}"
        )

else:

    lines.append(
        "  Multiple-signal identities: 0"
    )


lines.append("")

lines.append(
    "  NO-SIGNAL TOKEN LENGTH"
)


if commercial_unresolved_token_counts:

    for token_count, count in sorted(
        commercial_unresolved_token_counts.items()
    ):

        lines.append(
            f"    {token_count} token(s): "
            f"{count}"
        )

else:

    lines.append(
        "    NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. COMMERCIAL TAXONOMY CLASSIFICATIONS"
)
# ------------------------------------------------------------

if commercial_classification_counts:

    for classification, count in sorted(
        commercial_classification_counts.items()
    ):

        lines.append(
            f"  {classification}: "
            f"{count}"
        )

else:

    lines.append(
        "  NONE"
    )


lines.append("")

lines.append(
    "  CLASSIFICATION COUNT PER SERVICE"
)


for classification_count, count in sorted(
    commercial_classification_shape.items()
):

    lines.append(
        f"    {classification_count} "
        f"classification signal(s): "
        f"{count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. NEW ROLLING GRANTS VALIDATION"
)
# ------------------------------------------------------------

lines.append(
    f"  New Rolling Grant candidates: "
    f"{len(rolling_new_rows)}"
)


for status, count in sorted(
    rolling_new_completeness.items()
):

    lines.append(
        f"  {status}: {count}"
    )


lines.append(
    "  Proposed primary kind: GRANT"
)

lines.append(
    "  Proposed classification: Grant"
)

lines.append(
    "  Column B inferred as Benefits: YES"
)

lines.append(
    "  Column C inferred as Focus Sectors: YES"
)

lines.append(
    "  Column E inferred as Eligibility: YES"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. KNOWLEDGE ANCHOR TIE-BREAK"
)
# ------------------------------------------------------------

for sheet_name in (
    KNOWLEDGE_REVIEW_SHEETS
):

    result = (
        knowledge_tie_break[
            sheet_name
        ]
    )


    lines.append(
        f"  {sheet_name}"
    )

    lines.append(
        f"    status: "
        f"{result['status']}"
    )

    lines.append(
        f"    top_candidate: "
        f"{result['top_id']}"
    )

    lines.append(
        f"    runner_up: "
        f"{result['runner_id']}"
    )

    lines.append(
        f"    exact_matches: "
        f"{result['top_exact']} "
        f"vs {result['runner_exact']}"
    )

    lines.append(
        f"    containment_matches: "
        f"{result['top_containment']} "
        f"vs {result['runner_containment']}"
    )

    lines.append(
        f"    sheet_token_overlap: "
        f"{result['top_sheet_overlap']} "
        f"vs {result['runner_sheet_overlap']}"
    )

    lines.append(
        f"    earliest_content_row: "
        f"{result['top_earliest'] or 'NONE'} "
        f"vs "
        f"{result['runner_earliest'] or 'NONE'}"
    )


lines.append("")

lines.append(
    "  TIE-BREAK STATUS TOTALS"
)


for status, count in sorted(
    knowledge_resolution_counts.items()
):

    lines.append(
        f"    {status}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. FINAL ENTITY UNIVERSE"
)
# ------------------------------------------------------------

lines.append(
    f"  Structured identities: "
    f"{len(structured_identities)}"
)

lines.append(
    f"  Commercial identities: "
    f"{len(commercial_identities)}"
)

lines.append(
    f"  Structured/commercial overlap: "
    f"{len(structured_identities & commercial_identities)}"
)

lines.append(
    f"  New Rolling Grant identities: "
    f"{len(rolling_new_identities)}"
)

lines.append(
    f"  Final prospective unique Services: "
    f"{len(final_prospective)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. LIVE DESTINATION SAFETY"
)
# ------------------------------------------------------------

for model_name, count in (
    destination_counts.items()
):

    lines.append(
        f"  {model_name}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. WRITE / CONFIDENTIALITY SAFETY"
)
# ------------------------------------------------------------

lines.append(
    "  Mapping Contract v1 modified: NO"
)

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  Destination records created: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Commercial service names printed: NO"
)

lines.append(
    "  Commercial amounts printed: NO"
)

lines.append(
    "  Knowledge content printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10H AUDIT COMPLETE"
)

print(
    f"Prospective unique Services: "
    f"{len(final_prospective)}"
)

print(
    f"SAFE REPORT: {output}"
)
