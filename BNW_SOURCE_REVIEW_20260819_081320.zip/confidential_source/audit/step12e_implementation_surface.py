import inspect
import os
import sys
from pathlib import Path

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import django
django.setup()

import toolkit.importing.transformation as transformation
import toolkit.importing.supporting_transformation as supporting

from django.apps import apps


print("=" * 84)
print("BHARATNXT WAVE — STEP 12E EXACT IMPLEMENTATION SURFACE")
print("=" * 84)
print()
print("MODE: READ ONLY")
print("DATABASE WRITES: NO")
print("WORKBOOK BUSINESS VALUES PRINTED: NO")


# ============================================================
# HELPERS
# ============================================================

def matching_functions(module, needles):

    matches = []

    for name, obj in inspect.getmembers(
        module,
        inspect.isfunction,
    ):

        if obj.__module__ != module.__name__:
            continue

        try:
            source = inspect.getsource(
                obj
            )
        except Exception:
            continue

        lowered = source.lower()

        if any(
            needle.lower() in lowered
            for needle in needles
        ):
            matches.append(
                (
                    name,
                    obj,
                    source,
                )
            )

    return matches


def print_function_matches(
    title,
    module,
    needles,
):

    print()
    print("=" * 84)
    print(title)
    print("=" * 84)

    matches = matching_functions(
        module,
        needles,
    )

    print(
        "Matching functions:",
        len(matches),
    )

    for name, obj, source in matches:

        print()
        print("-" * 84)

        print(
            "FUNCTION:",
            name,
        )

        print(
            "FILE:",
            inspect.getsourcefile(
                obj
            ),
        )

        print(
            "START LINE:",
            inspect.getsourcelines(
                obj
            )[1],
        )

        print("-" * 84)

        print(
            source.rstrip()
        )


def print_model_source(
    model_name,
):

    model = apps.get_model(
        "toolkit",
        model_name,
    )

    print()
    print("-" * 84)
    print(
        f"MODEL: {model_name}"
    )

    print(
        "START LINE:",
        inspect.getsourcelines(
            model
        )[1],
    )

    print("-" * 84)

    print(
        inspect.getsource(
            model
        ).rstrip()
    )


# ============================================================
# 1. ROLLING GRANTS TRANSFORMATION
# ============================================================

print_function_matches(
    "1. ROLLING_GRANTS TRANSFORMATION CODE",
    transformation,
    (
        "Rolling_Grants",
        "ROLLING_GRANTS",
        "rolling",
    ),
)


# ============================================================
# 2. KNOWLEDGE TRANSFORMATION
# ============================================================

print_function_matches(
    "2. KNOWLEDGE TRANSFORMATION CODE",
    supporting,
    (
        "knowledge",
        "ServiceContentSection",
        "knowledge_heading_rows",
    ),
)


# ============================================================
# 3. CRITICAL MODEL DEFINITIONS
# ============================================================

print()
print("=" * 84)
print("3. CURRENT MODEL DEFINITIONS")
print("=" * 84)

for model_name in (
    "ImportBatch",
    "ImportRow",
    "ImportChange",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):

    print_model_source(
        model_name
    )


# ============================================================
# 4. IMPORT / TRANSACTION / ROLLBACK CODE
# ============================================================

print()
print("=" * 84)
print("4. IMPORT / TRANSACTION / ROLLBACK IMPLEMENTATION")
print("=" * 84)


needles = (
    "transaction.atomic",
    "ImportChange.objects",
    "rollback",
    "ROLLED_BACK",
)


for path in sorted(
    (ROOT / "toolkit").rglob(
        "*.py"
    )
):

    try:
        text = path.read_text(
            encoding="utf-8",
            errors="ignore",
        )
    except Exception:
        continue

    lines = text.splitlines()

    hits = []

    for line_number, line in enumerate(
        lines,
        start=1,
    ):

        if any(
            needle.lower()
            in line.lower()
            for needle in needles
        ):
            hits.append(
                line_number
            )

    if not hits:
        continue

    print()
    print("-" * 84)

    print(
        "FILE:",
        path.relative_to(
            ROOT
        ),
    )

    print(
        "MATCHING LINES:",
        ", ".join(
            str(number)
            for number in hits
        ),
    )

    print("-" * 84)

    # Print limited context around every hit.
    printed = set()

    for hit in hits:

        start = max(
            1,
            hit - 12,
        )

        end = min(
            len(lines),
            hit + 18,
        )

        for number in range(
            start,
            end + 1,
        ):

            if number in printed:
                continue

            printed.add(
                number
            )

            print(
                f"{number:5}: "
                f"{lines[number - 1]}"
            )


# ============================================================
# 5. CURRENT MIGRATION LIST
# ============================================================

print()
print("=" * 84)
print("5. TOOLKIT MIGRATIONS")
print("=" * 84)

migration_dir = (
    ROOT
    / "toolkit"
    / "migrations"
)

for path in sorted(
    migration_dir.glob(
        "*.py"
    )
):

    if path.name == "__init__.py":
        continue

    print(
        path.name
    )


# ============================================================
# 6. SAFETY COUNTS
# ============================================================

print()
print("=" * 84)
print("6. DATABASE SAFETY")
print("=" * 84)

for model_name in (
    "Service",
    "Category",
    "ImportRow",
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceSource",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):

    model = apps.get_model(
        "toolkit",
        model_name,
    )

    print(
        f"{model_name}: "
        f"{model.objects.count()}"
    )


print()
print("=" * 84)
print("STEP 12E COMPLETE")
print("DATABASE WRITES: NO")
print("=" * 84)
