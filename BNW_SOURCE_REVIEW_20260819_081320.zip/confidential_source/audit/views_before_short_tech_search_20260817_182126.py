from toolkit.visibility import visible_service_statuses
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import (
    get_object_or_404,
    redirect,
    render,
)
from django.utils.http import (
    url_has_allowed_host_and_scheme,
)
from django.views.decorators.http import require_POST

from accounts.activity import log_activity

from .models import (
    Category,
    SavedService,
    SearchEvent,
    Service,
    ServiceDomain,
)

from .pitching import (
    VISIBLE_STATUSES,
    apply_pitch_state,
    apply_pitch_states,
    available_sectors,
    closing_soon_queryset,
    pitchable_queryset,
    sector_match_ids,
)


SOURCE_PRIORITY = {
    "APPLICATION": 0,
    "OFFICIAL_PORTAL": 1,
    "REFERENCE": 2,
    "FLYER": 3,
    "OTHER": 4,
}

SOURCE_LABELS = {
    "APPLICATION": "Apply / Open Portal",
    "OFFICIAL_PORTAL": "Official Scheme Page",
    "REFERENCE": "Reference",
    "FLYER": "Guidelines / Flyer",
    "OTHER": "External Link",
}


def visible_services():
    """
    Services that are currently pitchable according to the pitch-window engine.
    Kept for pitch-window-specific workflows.
    """
    return pitchable_queryset(
        Service.objects.select_related(
            "domain",
            "category",
            "verified_by",
        )
    )


def all_bde_services():
    """
    Complete BDE catalog.

    Published/approved statuses are visible even when a pitch-window warning
    exists. The UI shows the pitch state instead of silently hiding the record.
    """
    return (
        Service.objects
        .select_related(
            "domain",
            "category",
            "verified_by",
        )
        .prefetch_related(
            "sources",
            "classifications",
            "eligibility_rules",
            "document_requirements",
            "process_steps",
        )
        .filter(
            status__in=VISIBLE_STATUSES
        )
    )



def business_knowledge_match_ids(query):
    """
    Return Service IDs matched through BDE-visible
    supporting business knowledge.

    Raw imports, hashes, audit data and technical metadata
    are deliberately excluded.
    """

    from django.apps import apps

    from django.db import (
        models as django_models,
    )

    from django.db.models import (
        Q as KnowledgeQ,
    )


    query = str(
        query or ""
    ).strip()


    if not query:

        return set()


    # Explicit allow-list.
    # Technical models such as ImportBatch, ImportRow,
    # ImportChange and audit/security models are absent.
    business_models = (
        "ServiceContentSection",
        "ServiceCommercial",
        "ServiceSource",
        "KnowledgeSection",
        "EligibilityRule",
        "DocumentRequirement",
        "ProcessStep",
        "ReferenceItem",
        "CommunicationTemplate",
    )


    blocked_fields = {
        "visibility",
        "status",
        "section_type",
        "content_type",
        "kind",
        "source_kind",
        "source_type",
        "source_reference",
        "source_sheet",
        "source_row_number",
        "row_hash",
        "raw_data",
        "metadata",
        "before_snapshot",
        "after_snapshot",
        "object_model",
        "object_pk",
        "engine_version",
        "ip_address",
        "user_agent",
    }


    blocked_fragments = (
        "internal",
        "technical",
        "audit",
        "hash",
        "import_",
        "created_by",
        "updated_by",
    )


    service_ids = set()


    for model_name in business_models:

        try:

            Model = apps.get_model(
                "toolkit",
                model_name,
            )

        except LookupError:

            continue


        # ----------------------------------------------------
        # REQUIRE DIRECT SERVICE RELATION
        # ----------------------------------------------------

        service_field = None


        for field in Model._meta.fields:

            remote = getattr(
                field,
                "remote_field",
                None,
            )

            remote_model = getattr(
                remote,
                "model",
                None,
            )


            if remote_model is None:

                continue


            if (
                getattr(
                    remote_model._meta,
                    "label_lower",
                    "",
                )
                == "toolkit.service"
            ):

                service_field = field
                break


        # Do not invent relationships between unrelated
        # business records and Services.
        if service_field is None:

            continue


        # ----------------------------------------------------
        # SAFE BUSINESS TEXT FIELDS
        # ----------------------------------------------------

        searchable_fields = []


        for field in Model._meta.fields:

            if not isinstance(
                field,
                (
                    django_models.CharField,
                    django_models.TextField,
                ),
            ):

                continue


            name = field.name
            lowered = name.lower()


            if name in blocked_fields:

                continue


            if any(
                fragment in lowered
                for fragment
                in blocked_fragments
            ):

                continue


            searchable_fields.append(
                name
            )


        if not searchable_fields:

            continue


        condition = KnowledgeQ()


        for field_name in searchable_fields:

            condition |= KnowledgeQ(
                **{
                    f"{field_name}__icontains":
                        query
                }
            )


        queryset = Model.objects.filter(
            condition
        )


        model_fields = {
            field.name
            for field in Model._meta.fields
        }


        # ----------------------------------------------------
        # BDE VISIBILITY
        # ----------------------------------------------------

        if "visibility" in model_fields:

            visibility_field = (
                Model._meta.get_field(
                    "visibility"
                )
            )


            valid_choices = {
                str(value)
                for value, label
                in (
                    visibility_field.choices
                    or []
                )
            }


            permitted = []


            if "BDE" in valid_choices:

                permitted.append(
                    "BDE"
                )


            if "BDE_ALLOWED" in valid_choices:

                permitted.append(
                    "BDE_ALLOWED"
                )


            # If a visibility-controlled model does not expose
            # a known BDE permission, do not search it.
            if not permitted:

                continue


            queryset = queryset.filter(
                visibility__in=permitted
            )


        if "is_active" in model_fields:

            queryset = queryset.filter(
                is_active=True
            )


        if "is_published" in model_fields:

            queryset = queryset.filter(
                is_published=True
            )


        ids = queryset.values_list(
            service_field.attname,
            flat=True,
        )


        service_ids.update(
            service_id
            for service_id
            in ids
            if service_id
        )


    return service_ids


def search_text_filter(query):
    return (
        Q(title__icontains=query)
        | Q(service_id__icontains=query)
        | Q(bde_summary__icontains=query)
        | Q(overview__icontains=query)
        | Q(benefits__icontains=query)
        | Q(eligibility_summary__icontains=query)
        | Q(applicable_for_raw__icontains=query)
        | Q(funding_organisation__icontains=query)
        | Q(application_deadline_raw__icontains=query)
        | Q(domain__name__icontains=query)
        | Q(category__name__icontains=query)
        | Q(classifications__name__icontains=query)
        | Q(service_kind__icontains=query)
        | Q(funding_type__icontains=query)
        | Q(subsidy_details__icontains=query)
        | Q(sales_pitch__icontains=query)
    )


def _natural_variant_match_ids(
    base_services,
    variants,
):
    """
    Search one natural-language concept against the same
    trusted V1 data surfaces.
    """

    condition = Q()


    for variant in variants:

        condition |= search_text_filter(
            variant
        )


    service_ids = set(
        base_services
        .filter(
            condition
        )
        .distinct()
        .values_list(
            "pk",
            flat=True,
        )
    )


    for variant in variants:

        service_ids.update(
            sector_match_ids(
                base_services,
                variant,
            )
        )


        service_ids.update(
            business_knowledge_match_ids(
                variant
            )
        )


    return service_ids


def natural_language_match_ids(
    base_services,
    query,
):
    """
    Deterministic English/Hinglish search.

    Two concepts:
        both required.

    Three concepts:
        all preferred; otherwise at least two.

    Four or more:
        all preferred; otherwise all but one.
    """

    from .search_intelligence import (
        query_groups,
    )


    groups = query_groups(
        query
    )


    if not groups:

        return set()


    matched_groups = [
        _natural_variant_match_ids(
            base_services,
            variants,
        )
        for variants in groups
    ]


    if len(
        matched_groups
    ) == 1:

        return matched_groups[
            0
        ]


    if all(
        matched_groups
    ):

        intersection = set.intersection(
            *matched_groups
        )


        if intersection:

            return intersection


    scores = {}


    for matched_ids in matched_groups:

        for service_id in matched_ids:

            scores[
                service_id
            ] = (
                scores.get(
                    service_id,
                    0,
                )
                + 1
            )


    group_count = len(
        matched_groups
    )


    if group_count <= 2:

        threshold = group_count

    elif group_count == 3:

        threshold = 2

    else:

        threshold = max(
            2,
            group_count - 1,
        )


    return {
        service_id
        for service_id, score
        in scores.items()
        if score >= threshold
    }


def _search_money_amounts(value):
    """
    Extract monetary values and normalize them to lakh units.

    5 lakh  -> 5
    25 lakh -> 25
    1 crore -> 100

    This prevents substring mistakes such as
    5 lakh matching 25 lakh.
    """

    import re

    from decimal import Decimal


    text = str(
        value or ""
    ).casefold()


    pattern = re.compile(
        r"(?<![0-9])"
        r"([0-9]+(?:\.[0-9]+)?)"
        r"\s*"
        r"(lakh|lakhs|lac|lacs|crore|crores|cr)"
        r"\b"
    )


    amounts = set()


    for number, unit in pattern.findall(
        text
    ):

        amount = Decimal(
            number
        )


        if unit in {
            "crore",
            "crores",
            "cr",
        }:

            amount *= Decimal(
                "100"
            )


        amounts.add(
            amount
        )


    return amounts


def natural_language_rank_map(
    base_services,
    query,
):
    """
    Rank existing V2A.1 candidates.

    This DOES NOT change search recall.
    It only determines which relevant Services appear first.

    Scores are internal only.
    """

    from .search_intelligence import (
        normalize_query,
        query_groups,
    )


    groups = query_groups(
        query
    )


    if not groups:

        return {}


    matched_groups = [
        _natural_variant_match_ids(
            base_services,
            variants,
        )
        for variants in groups
    ]


    candidate_ids = set()


    for matched_ids in matched_groups:

        candidate_ids.update(
            matched_ids
        )


    if not candidate_ids:

        return {}


    services = list(
        base_services
        .filter(
            pk__in=candidate_ids
        )
        .select_related(
            "domain",
            "category",
        )
        .distinct()
    )


    query_amounts = (
        _search_money_amounts(
            query
        )
    )


    scores = {}


    for service in services:

        values = (
            service.title,
            service.service_id,
            service.bde_summary,
            service.overview,
            service.benefits,
            service.eligibility_summary,
            service.applicable_for_raw,
            service.funding_organisation,
            service.funding_type,
            service.subsidy_details,
            service.sales_pitch,
            service.restrictions,
            service.important_notes,
        )


        raw_text = " ".join(
            str(value)
            for value in values
            if value
        )


        core_text = normalize_query(
            raw_text
        )


        service_amounts = (
            _search_money_amounts(
                raw_text
            )
        )


        score = 0
        true_matches = 0


        for variants, matched_ids in zip(
            groups,
            matched_groups,
        ):

            group_amounts = set()


            for variant in variants:

                group_amounts.update(
                    _search_money_amounts(
                        variant
                    )
                )


            # =================================================
            # NUMERIC CONCEPT
            # =================================================

            if group_amounts:

                if (
                    query_amounts
                    & service_amounts
                ):

                    true_matches += 1

                    # Exact amount evidence.
                    score += 2500


                elif (
                    query_amounts
                    and service_amounts
                    and any(
                        available
                        >= requested
                        for available
                        in service_amounts
                        for requested
                        in query_amounts
                    )
                ):

                    # Can potentially provide at least
                    # requested amount, but isn't exact.
                    score += 120


                continue


            # =================================================
            # NORMAL BUSINESS CONCEPT
            # =================================================

            if service.pk not in matched_ids:

                continue


            true_matches += 1
            score += 450


            title = normalize_query(
                service.title
            )


            category = normalize_query(
                service.category.name
                if service.category
                else ""
            )


            domain = normalize_query(
                service.domain.name
                if service.domain
                else ""
            )


            normalized_variants = [
                normalize_query(
                    variant
                )
                for variant in variants
                if variant
            ]


            if any(
                variant
                and variant in title
                for variant
                in normalized_variants
            ):

                score += 350


            if any(
                variant
                and variant in core_text
                for variant
                in normalized_variants
            ):

                score += 220


            if any(
                variant
                and (
                    variant in category
                    or variant in domain
                )
                for variant
                in normalized_variants
            ):

                score += 100


        # =====================================================
        # FULL-INTENT BONUS
        # =====================================================

        if true_matches == len(
            groups
        ):

            score += 1500


        elif (
            len(groups) >= 3
            and true_matches
            == len(groups) - 1
        ):

            score += 200


        scores[
            service.pk
        ] = score


    return scores


def search_relevance_sort_key(
    service,
    relevance_scores,
    query,
    domain_tiebreak=False,
):
    """
    Shared relevance order for:

    - Business Toolkit
    - live search suggestions
    - Service Library
    """

    from .search_intelligence import (
        normalize_query,
    )


    score = int(
        relevance_scores.get(
            service.pk,
            0,
        )
    )


    query_text = normalize_query(
        query
    )


    title = normalize_query(
        service.title
    )


    # Known Service name searches stay strongest.
    if (
        query_text
        and title == query_text
    ):

        score += 5000


    elif (
        query_text
        and title.startswith(
            query_text
        )
    ):

        score += 1800


    elif (
        query_text
        and query_text in title
    ):

        score += 900


    domain_order = 0


    if domain_tiebreak:

        domain_order = getattr(
            service.domain,
            "display_order",
            9999,
        )


    return (
        -score,
        domain_order,
        title,
    )




def _source_sort_key(source):
    return (
        SOURCE_PRIORITY.get(
            source.source_kind,
            99,
        ),
        0 if source.is_official else 1,
        source.pk or 0,
    )


def _deadline_label(service):
    if service.application_deadline:
        return service.application_deadline.strftime(
            "%d %b %Y"
        )

    raw = (
        service.application_deadline_raw
        or ""
    ).strip()

    if raw:
        return raw

    if service.deadline_status not in {
        "",
        "UNKNOWN",
    }:
        return service.get_deadline_status_display()

    return "Not recorded"


def _attach_bde_ui(service):
    apply_pitch_state(service)

    sources = [
        source
        for source
        in service.sources.all()
        if source.source_url
    ]

    sources.sort(
        key=_source_sort_key
    )

    service.bde_sources = sources
    service.primary_source = (
        sources[0]
        if sources
        else None
    )

    service.bde_deadline_label = (
        _deadline_label(service)
    )

    return service


def _attach_bde_ui_many(services):
    for service in services:
        _attach_bde_ui(service)

    return services


def _remember_recent(request, service):
    recent = list(
        request.session.get(
            "bde_recent_service_ids",
            [],
        )
    )

    service_id = int(service.pk)

    recent = [
        item
        for item
        in recent
        if int(item) != service_id
    ]

    recent.insert(
        0,
        service_id,
    )

    request.session[
        "bde_recent_service_ids"
    ] = recent[:12]


def _serialize_service(
    request,
    service,
):
    _attach_bde_ui(service)
    _remember_recent(
        request,
        service,
    )

    summary = (
        service.bde_summary
        or service.overview
        or service.benefits
        or ""
    ).strip()

    sources = [
        {
            "name": (
                source.source_name
                or SOURCE_LABELS.get(
                    source.source_kind,
                    "External Link",
                )
            ),
            "label": SOURCE_LABELS.get(
                source.source_kind,
                "External Link",
            ),
            "kind": source.source_kind,
            "url": source.source_url,
            "official": source.is_official,
        }
        for source
        in service.bde_sources
    ]

    return {
        "id": service.pk,
        "service_id": service.service_id,
        "title": service.title,
        "domain": service.domain.name,
        "category": service.category.name,
        "kind": (
            service.get_service_kind_display()
        ),
        "summary": summary,
        "benefits": service.benefits or "",
        "eligibility": (
            service.eligibility_summary
            or ""
        ),
        "applicable_for": (
            service.applicable_for_raw
            or ""
        ),
        "funding_organisation": (
            service.funding_organisation
            or ""
        ),
        "deadline": (
            service.bde_deadline_label
        ),
        "pitch_state": (
            service.pitch_state_label
        ),
        "pitch_state_code": (
            service.pitch_state_code
        ),
        "primary_url": (
            service.primary_source.source_url
            if service.primary_source
            else ""
        ),
        "detail_url": (
            f"/toolkit/service/{service.slug}/"
        ),
        "sources": sources,
        "requirements": [
            {
                "name": item.name,
                "description": (
                    item.description
                    or ""
                ),
                "mandatory": (
                    item.is_mandatory
                ),
            }
            for item
            in service.document_requirements.all()
        ],
        "process": [
            {
                "number": item.step_number,
                "title": item.title,
                "description": (
                    item.description
                    or ""
                ),
            }
            for item
            in service.process_steps.all()
        ],
        "saved": SavedService.objects.filter(
            user=request.user,
            service=service,
        ).exists(),
    }


@login_required
def toolkit_home(request):
    # BDE search is now a complete published catalog search.
    # Pitch windows are displayed as state, not used to hide valid records.
    base_services = all_bde_services()

    query = request.GET.get(
        "q",
        ""
    ).strip()

    sector = request.GET.get(
        "sector",
        ""
    ).strip()

    domain_slug = request.GET.get(
        "domain",
        ""
    ).strip()

    category_id = request.GET.get(
        "category",
        ""
    ).strip()

    service_kind = request.GET.get(
        "kind",
        ""
    ).strip()

    deadline_filter = request.GET.get(
        "deadline",
        ""
    ).strip()


    services = base_services


    if query:
        sector_ids = sector_match_ids(
            base_services,
            query
        )

        services = services.filter(
            search_text_filter(query)
            | Q(pk__in=sector_ids)
            | Q(
                pk__in=business_knowledge_match_ids(
                    query
                )
            )
            | Q(
                pk__in=natural_language_match_ids(
                    base_services,
                    query
                )
            )
        ).distinct()


    if sector:
        sector_ids = sector_match_ids(
            base_services,
            sector
        )

        services = services.filter(
            pk__in=sector_ids
        )


    if domain_slug:
        services = services.filter(
            domain__slug=domain_slug
        )


    if category_id.isdigit():
        category_pk = int(
            category_id
        )

        services = services.filter(
            Q(category_id=category_pk)
            | Q(
                classifications__id=(
                    category_pk
                )
            )
        ).distinct()


    valid_kinds = {
        value
        for value, label
        in Service.SERVICE_KIND_CHOICES
    }

    if service_kind in valid_kinds:
        services = services.filter(
            service_kind=service_kind
        )


    if deadline_filter == "closing":
        services = closing_soon_queryset(
            services,
            days=30
        )

    elif deadline_filter == "urgent":
        services = closing_soon_queryset(
            services,
            days=7
        )

    elif deadline_filter == "no_deadline":
        services = services.filter(
            application_deadline__isnull=True,
        )


    result_count = services.count()


    filters = {
        "sector": sector,
        "domain": domain_slug,
        "category": category_id,
        "service_kind": service_kind,
        "deadline": deadline_filter,
    }

    filters_used = any(
        filters.values()
    )


    if query or filters_used:
        SearchEvent.objects.create(
            user=request.user,
            event_type=(
                "SEARCH"
                if query
                else "FILTER"
            ),
            query=query,
            filters=filters,
            result_count=result_count,
        )


    if query:
        log_activity(
            request,
            "SEARCH",
            f'Toolkit search: "{query}"',
            metadata={
                "query": query,
                "result_count": result_count,
            },
        )


    if filters_used:
        log_activity(
            request,
            "FILTER",
            "Toolkit filters applied.",
            metadata={
                **filters,
                "result_count": result_count,
            },
        )


    domains = (
        ServiceDomain.objects
        .filter(is_active=True)
        .order_by(
            "display_order",
            "name"
        )
    )


    categories = (
        Category.objects
        .filter(is_active=True)
        .select_related("domain")
        .order_by(
            "domain__display_order",
            "display_order",
            "name"
        )
    )


    sector_options = available_sectors(
        base_services
    )


    if query:

        relevance_scores = (
            natural_language_rank_map(
                base_services,
                query,
            )
        )

        service_list = list(
            services.select_related(
                "domain",
                "category",
            )
        )

        service_list.sort(
            key=lambda service:
                search_relevance_sort_key(
                    service,
                    relevance_scores,
                    query,
                    domain_tiebreak=True,
                )
        )

        service_list = (
            service_list[:250]
        )

    else:

        service_list = list(
            services.order_by(
                "domain__display_order",
                "title"
            )[:250]
        )

    _attach_bde_ui_many(
        service_list
    )


    saved_service_ids = set(
        SavedService.objects
        .filter(user=request.user)
        .values_list(
            "service_id",
            flat=True
        )
    )


    context = {
        "services": service_list,
        "result_count": result_count,
        "domains": domains,
        "categories": categories,
        "sector_options": sector_options,
        "service_kinds": (
            Service.SERVICE_KIND_CHOICES
        ),
        "query": query,
        "selected_sector": sector,
        "selected_domain": domain_slug,
        "selected_category": category_id,
        "selected_kind": service_kind,
        "selected_deadline": deadline_filter,
        "saved_service_ids": (
            saved_service_ids
        ),
    }


    return render(
        request,
        "toolkit/toolkit_home.html",
        context
    )


@login_required
def search_suggestions(request):
    query = request.GET.get(
        "q",
        ""
    ).strip()

    if len(query) < 2:
        return JsonResponse(
            {"results": []}
        )


    base_services = all_bde_services()

    sector_ids = sector_match_ids(
        base_services,
        query
    )


    candidates = list(
        base_services
        .filter(
            search_text_filter(query)
            | Q(pk__in=sector_ids)
            | Q(
                pk__in=business_knowledge_match_ids(
                    query
                )
            )
            | Q(
                pk__in=natural_language_match_ids(
                    base_services,
                    query
                )
            )
        )
        .distinct()
        .order_by("title")[:200]
    )

    relevance_scores = (
        natural_language_rank_map(
            base_services,
            query,
        )
    )

    services = sorted(
        candidates,
        key=lambda service:
            search_relevance_sort_key(
                service,
                relevance_scores,
                query,
            ),
    )[:8]


    results = []

    for service in services:
        _attach_bde_ui(
            service
        )

        results.append(
            {
                "pk": service.pk,
                "title": service.title,
                "service_id": (
                    service.service_id
                ),
                "domain": (
                    service.domain.name
                ),
                "category": (
                    service.category.name
                ),
                "kind": (
                    service.get_service_kind_display()
                ),
                "deadline": (
                    service.bde_deadline_label
                ),
                "url": (
                    f"/toolkit/service/"
                    f"{service.slug}/"
                ),
            }
        )


    return JsonResponse(
        {"results": results}
    )


@login_required
def service_library(request):
    base_services = all_bde_services()

    query = request.GET.get(
        "q",
        ""
    ).strip()

    category_id = request.GET.get(
        "category",
        ""
    ).strip()

    service_kind = request.GET.get(
        "kind",
        ""
    ).strip()

    selected_service_id = (
        request.GET.get(
            "service",
            ""
        ).strip()
    )


    # Build category counts from the complete BDE catalog.
    catalog_services = list(
        base_services.order_by(
            "title"
        )
    )

    category_counts = {}

    for service in catalog_services:
        category_ids = {
            service.category_id
        }

        category_ids.update(
            category.pk
            for category
            in service.classifications.all()
        )

        for item_id in category_ids:
            category_counts[
                item_id
            ] = (
                category_counts.get(
                    item_id,
                    0
                )
                + 1
            )


    category_items = list(
        Category.objects
        .filter(is_active=True)
        .select_related("domain")
        .order_by(
            "domain__display_order",
            "domain__name",
            "display_order",
            "name",
        )
    )

    for item in category_items:
        item.bde_count = (
            category_counts.get(
                item.pk,
                0
            )
        )


    services = base_services

    if query:
        sector_ids = sector_match_ids(
            base_services,
            query
        )

        services = services.filter(
            search_text_filter(query)
            | Q(pk__in=sector_ids)
            | Q(
                pk__in=business_knowledge_match_ids(
                    query
                )
            )
            | Q(
                pk__in=natural_language_match_ids(
                    base_services,
                    query
                )
            )
        ).distinct()


    if category_id.isdigit():
        category_pk = int(
            category_id
        )

        services = services.filter(
            Q(category_id=category_pk)
            | Q(
                classifications__id=(
                    category_pk
                )
            )
        ).distinct()


    valid_kinds = {
        value
        for value, label
        in Service.SERVICE_KIND_CHOICES
    }

    if service_kind in valid_kinds:
        services = services.filter(
            service_kind=service_kind
        )


    if query:

        relevance_scores = (
            natural_language_rank_map(
                base_services,
                query,
            )
        )

        service_list = list(
            services.select_related(
                "domain",
                "category",
            )
        )

        service_list.sort(
            key=lambda service:
                search_relevance_sort_key(
                    service,
                    relevance_scores,
                    query,
                )
        )

        service_list = (
            service_list[:300]
        )

    else:

        service_list = list(
            services.order_by(
                "title"
            )[:300]
        )

    _attach_bde_ui_many(
        service_list
    )


    selected_service = None

    if selected_service_id.isdigit():
        selected_pk = int(
            selected_service_id
        )

        selected_service = next(
            (
                item
                for item
                in service_list
                if item.pk == selected_pk
            ),
            None,
        )

        if selected_service is None:
            selected_service = (
                all_bde_services()
                .filter(
                    pk=selected_pk
                )
                .first()
            )

            if selected_service:
                _attach_bde_ui(
                    selected_service
                )


    if (
        selected_service is None
        and service_list
    ):
        selected_service = (
            service_list[0]
        )


    saved_service_ids = set(
        SavedService.objects
        .filter(user=request.user)
        .values_list(
            "service_id",
            flat=True
        )
    )


    return render(
        request,
        "toolkit/service_library.html",
        {
            "services": service_list,
            "result_count": len(
                service_list
            ),
            "total_service_count": len(
                catalog_services
            ),
            "categories": category_items,
            "selected_category": (
                category_id
            ),
            "selected_kind": (
                service_kind
            ),
            "service_kinds": (
                Service.SERVICE_KIND_CHOICES
            ),
            "query": query,
            "selected_service": (
                selected_service
            ),
            "saved_service_ids": (
                saved_service_ids
            ),
        }
    )


@login_required
def service_quick_view(
    request,
    service_id,
):
    service = get_object_or_404(
        all_bde_services(),
        pk=service_id,
    )

    return JsonResponse(
        _serialize_service(
            request,
            service,
        )
    )


@login_required
def service_detail(request, slug):
    service = get_object_or_404(
        all_bde_services(),
        slug=slug
    )

    _attach_bde_ui(
        service
    )

    _remember_recent(
        request,
        service,
    )


    log_activity(
        request,
        "SERVICE_VIEW",
        f"Viewed service: {service.title}.",
        target_type="service",
        target_id=service.pk,
        metadata={
            "service_id": service.service_id,
            "domain": service.domain.name,
            "category": service.category.name,
            "pitch_state": (
                service.pitch_state_code
            ),
        },
    )


    is_saved = SavedService.objects.filter(
        user=request.user,
        service=service,
    ).exists()


    eligibility_rules = list(
        service.eligibility_rules
        .all()
        .order_by(
            "display_order",
            "id",
        )
    )


    document_requirements = list(
        service.document_requirements
        .all()
        .order_by(
            "display_order",
            "name",
        )
    )


    process_steps = list(
        service.process_steps
        .all()
        .order_by(
            "step_number",
            "id",
        )
    )


    content_sections = list(
        service.content_sections
        .filter(
            visibility="BDE"
        )
        .order_by(
            "display_order",
            "id",
        )
    )


    commercial_terms = list(
        service.commercial_terms
        .filter(
            visibility="BDE_ALLOWED",
            is_active=True,
        )
        .order_by(
            "id"
        )
    )


    knowledge_sections = list(
        service.knowledge_sections
        .filter(
            visibility="BDE"
        )
        .select_related(
            "document"
        )
        .order_by(
            "document__title",
            "display_order",
            "id",
        )
    )


    comparison_entries = list(
        service.comparison_entries
        .select_related(
            "matrix"
        )
        .order_by(
            "matrix__name",
            "row_number",
            "id",
        )
    )


    return render(
        request,
        "toolkit/service_detail.html",
        {
            "service":
                service,

            "is_saved":
                is_saved,

            "sources":
                service.bde_sources,

            "primary_source":
                service.primary_source,

            "classification_categories":
                list(
                    service.classifications.all()
                ),

            "eligibility_rules":
                eligibility_rules,

            "document_requirements":
                document_requirements,

            "process_steps":
                process_steps,

            "content_sections":
                content_sections,

            "commercial_terms":
                commercial_terms,

            "knowledge_sections":
                knowledge_sections,

            "comparison_entries":
                comparison_entries,
        }
    )


@login_required
def saved_services(request):
    saved_items = list(
        SavedService.objects
        .filter(user=request.user)
        .select_related(
            "service",
            "service__domain",
            "service__category",
        )
        .prefetch_related(
            "service__sources",
        )
        .order_by("-created_at")
    )

    for item in saved_items:
        _attach_bde_ui(
            item.service
        )


    return render(
        request,
        "toolkit/saved_services.html",
        {
            "saved_items": saved_items,
        }
    )


@login_required
def recent_services(request):
    recent_ids = [
        int(item)
        for item
        in request.session.get(
            "bde_recent_service_ids",
            [],
        )
        if str(item).isdigit()
    ]

    services_by_id = {
        service.pk: service
        for service
        in all_bde_services().filter(
            pk__in=recent_ids
        )
    }

    services = [
        services_by_id[
            service_id
        ]
        for service_id
        in recent_ids
        if service_id
        in services_by_id
    ]

    _attach_bde_ui_many(
        services
    )

    return render(
        request,
        "toolkit/recent_services.html",
        {
            "services": services,
        }
    )


@login_required
@require_POST
def toggle_saved_service(
    request,
    service_id
):
    service = get_object_or_404(
        Service,
        pk=service_id,
        status__in=visible_service_statuses(request.user),
    )


    saved_item = SavedService.objects.filter(
        user=request.user,
        service=service,
    ).first()


    if saved_item:
        saved_item.delete()

        saved = False

        if (
            request.headers.get(
                "X-Requested-With"
            )
            != "XMLHttpRequest"
        ):
            messages.success(
                request,
                f'Removed "{service.title}" from Saved Services.'
            )

        log_activity(
            request,
            "SERVICE_UNSAVE",
            (
                "Removed saved service: "
                f"{service.title}."
            ),
            target_type="service",
            target_id=service.pk,
            metadata={
                "service_id": (
                    service.service_id
                ),
            },
        )

    else:
        SavedService.objects.create(
            user=request.user,
            service=service,
        )

        saved = True

        if (
            request.headers.get(
                "X-Requested-With"
            )
            != "XMLHttpRequest"
        ):
            messages.success(
                request,
                f'Saved "{service.title}" to Saved Services.'
            )

        log_activity(
            request,
            "SERVICE_SAVE",
            (
                "Saved service: "
                f"{service.title}."
            ),
            target_type="service",
            target_id=service.pk,
            metadata={
                "service_id": (
                    service.service_id
                ),
            },
        )


    if (
        request.headers.get(
            "X-Requested-With"
        )
        == "XMLHttpRequest"
    ):
        return JsonResponse(
            {
                "saved": saved,
                "service_id": service.pk,
            }
        )


    next_url = request.POST.get(
        "next",
        ""
    )

    if (
        next_url
        and url_has_allowed_host_and_scheme(
            url=next_url,
            allowed_hosts={
                request.get_host()
            },
            require_https=request.is_secure(),
        )
    ):
        return redirect(
            next_url
        )


    return redirect(
        "toolkit:service_detail",
        slug=service.slug
    )
