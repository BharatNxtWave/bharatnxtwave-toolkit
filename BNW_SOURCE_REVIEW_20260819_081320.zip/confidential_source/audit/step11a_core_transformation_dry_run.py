import os
import sys

from collections import Counter
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.importing.transformation import (
    build_core_transformation_plan,
)

from toolkit.models import (
    Category,
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ServiceDomain,
    ServiceSource,
)


# ============================================================
# PRE-RUN DB SNAPSHOT
# ============================================================

def snapshot():
    return {
        "Service":
            Service.objects.count(),
        "ServiceDomain":
            ServiceDomain.objects.count(),
        "Category":
            Category.objects.count(),
        "ImportRow":
            ImportRow.objects.count(),
        "ImportChange":
            ImportChange.objects.count(),
        "ServiceClassification":
            ServiceClassification.objects.count(),
        "ServiceSource":
            ServiceSource.objects.count(),
        "ServiceCommercial":
            ServiceCommercial.objects.count(),
        "ServiceContentSection":
            ServiceContentSection.objects.count(),
        "ReferenceItem":
            ReferenceItem.objects.count(),
        "ComparisonMatrix":
            ComparisonMatrix.objects.count(),
        "ComparisonEntry":
            ComparisonEntry.objects.count(),
        "CommunicationTemplate":
            CommunicationTemplate.objects.count(),
    }


expected = {
    "Service": 1,
    "ServiceDomain": 8,
    "Category": 32,
    "ImportRow": 478,
    "ImportChange": 0,
    "ServiceClassification": 0,
    "ServiceSource": 0,
    "ServiceCommercial": 0,
    "ServiceContentSection": 0,
    "ReferenceItem": 0,
    "ComparisonMatrix": 0,
    "ComparisonEntry": 0,
    "CommunicationTemplate": 0,
}


before = snapshot()


if before != expected:
    raise SystemExit(
        "STOPPED SAFELY: database state differs "
        "from approved pre-import state."
    )


# ============================================================
# BUILD FULL CORE PLAN IN MEMORY
# ============================================================

plan = (
    build_core_transformation_plan()
)


# ============================================================
# PLAN STATISTICS
# ============================================================

services = plan[
    "services"
]

classifications = plan[
    "classifications"
]

commercial = plan[
    "commercial"
]


source_family_counts = Counter(
    service[
        "source_family"
    ]
    for service in (
        services.values()
    )
)


primary_domain_counts = Counter(
    service[
        "domain_slug"
    ]
    for service in (
        services.values()
    )
)


primary_category_counts = Counter(
    service[
        "category_slug"
    ]
    for service in (
        services.values()
    )
)


classification_category_counts = Counter(
    item[
        "category_slug"
    ]
    for item in classifications
)


commercial_family_counts = Counter(
    item[
        "source_family"
    ]
    for item in commercial
)


commercial_visibility_counts = Counter(
    item[
        "visibility"
    ]
    for item in commercial
)


numeric_commercial_values = sum(
    1
    for item in commercial
    for field in (
        "minimum_charge",
        "government_fee",
        "vendor_cost",
        "bdm_deduction",
    )
    if item[field] is not None
)


# ============================================================
# VERIFY DATABASE UNCHANGED AFTER PLANNING
# ============================================================

after = snapshot()


if after != before:
    raise SystemExit(
        "STOPPED SAFELY: dry-run unexpectedly "
        "changed database counts."
    )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step11a_core_transformation_SAFE_TO_SHARE.txt"
)


lines = [
    "=" * 80,
    (
        "BHARATNXT WAVE — "
        "STEP 11A CORE TRANSFORMATION DRY RUN"
    ),
    "=" * 80,
    "",
    (
        f"Mapping Contract version: "
        f"{plan['contract_version']}"
    ),
    (
        f"Import Batch ID: "
        f"{plan['batch_id']}"
    ),
    (
        f"Staged rows inspected: "
        f"{plan['staged_row_count']}"
    ),
    "Database writes performed: NO",
    "",
    "1. CORE SERVICE PLAN",
    (
        f"  Planned Services: "
        f"{len(services)}"
    ),
    (
        f"  Planned new Categories: "
        f"{len(plan['categories'])}"
    ),
    (
        f"  Planned ServiceClassifications: "
        f"{len(classifications)}"
    ),
    (
        f"  Planned ServiceCommercial records: "
        f"{len(commercial)}"
    ),
    "",
    "2. SERVICE SOURCE-FAMILY COUNTS",
]

for key, value in sorted(
    source_family_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "3. SERVICE KIND COUNTS",
        "  STRUCTURED:",
    ]
)


for key, value in sorted(
    plan[
        "structured_kind_counts"
    ].items()
):
    lines.append(
        f"    {key}: {value}"
    )


lines.append(
    "  COMMERCIAL ADDITIONAL:"
)


for key, value in sorted(
    plan[
        "commercial_kind_counts"
    ].items()
):
    lines.append(
        f"    {key}: {value}"
    )


lines.append(
    "  ROLLING_GRANTS: GRANT=2"
)


lines.extend(
    [
        "",
        "4. COMMERCIAL PRIMARY-MAPPING METHOD",
    ]
)


for key, value in sorted(
    plan[
        "commercial_method_counts"
    ].items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "5. PRIMARY DOMAIN COUNTS",
    ]
)


for key, value in sorted(
    primary_domain_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "6. PRIMARY CATEGORY COUNTS",
    ]
)


for key, value in sorted(
    primary_category_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "7. SECONDARY CLASSIFICATION COUNTS",
    ]
)


if classification_category_counts:
    for key, value in sorted(
        classification_category_counts.items()
    ):
        lines.append(
            f"  {key}: {value}"
        )
else:
    lines.append(
        "  NONE"
    )


lines.extend(
    [
        "",
        "8. COMMERCIAL RECORD PLAN",
    ]
)


for key, value in sorted(
    commercial_family_counts.items()
):
    lines.append(
        f"  {key}: {value}"
    )


lines.append(
    (
        "  Total commercial records: "
        f"{len(commercial)}"
    )
)


for key, value in sorted(
    commercial_visibility_counts.items()
):
    lines.append(
        f"  Visibility {key}: {value}"
    )


lines.append(
    (
        "  Numeric commercial fields "
        f"auto-populated: {numeric_commercial_values}"
    )
)


lines.extend(
    [
        "",
        "9. MODEL / IDENTITY VALIDATION",
        (
            f"  Service validation count: "
            f"{plan['validation']['services']}"
        ),
        (
            f"  Category validation count: "
            f"{plan['validation']['categories_to_create']}"
        ),
        (
            f"  Classification validation count: "
            f"{plan['validation']['classifications']}"
        ),
        (
            f"  Commercial validation count: "
            f"{plan['validation']['commercial_records']}"
        ),
        "  Duplicate planned service_id: 0",
        "  Duplicate planned slug: 0",
        "  Live title collisions: 0",
        "  Missing primary domain/category: 0",
        "  Invalid service_kind values: 0",
        "",
        "10. DATABASE SAFETY",
    ]
)


for key, value in after.items():
    lines.append(
        f"  {key}: {value}"
    )


lines.extend(
    [
        "",
        "11. CONFIDENTIALITY",
        "  Service names printed: NO",
        "  Commercial amounts printed: NO",
        "  BDM deductions printed: NO",
        "  Source cell values printed: NO",
        "  URLs printed: NO",
        "  Detailed transformation plan persisted: NO",
        "",
        "12. RESULT",
        "  CORE TRANSFORMATION ENGINE: PASS",
        "  LIVE DATABASE IMPORT: NOT STARTED",
        (
            "  Next: add sources, references, comparison, "
            "knowledge and communication parsers."
        ),
    ]
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 11A CORE TRANSFORMATION DRY RUN COMPLETE"
)

print(
    f"Planned Services: "
    f"{len(services)}"
)

print(
    f"Planned Categories: "
    f"{len(plan['categories'])}"
)

print(
    f"Planned Classifications: "
    f"{len(classifications)}"
)

print(
    f"Planned ServiceCommercial: "
    f"{len(commercial)}"
)

print(
    f"SAFE REPORT: {output}"
)
