import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


# ============================================================
# CONSTANTS
# ============================================================

BATCH_ID = 5

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

CONTRACT_V1 = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)

EXPECTED_IMPORT_ROWS = 478
EXPECTED_STRUCTURED_IDENTITIES = 100
EXPECTED_COMMERCIAL_UNIQUE_LABELS = 61

KNOWLEDGE_SHEETS = (
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
)

ROLLING_COMPARE_FIELDS = (
    "benefits",
    "focus_sectors",
    "eligibility",
    "deadline",
    "funding_organisation",
    "scheme_type",
    "applicable_for",
    "portal_link",
    "minimum_charge",
    "government_charge",
    "additional_info",
    "flyer",
)


# ============================================================
# HASH / INTEGRITY
# ============================================================

def sha256_file(path):
    digest = hashlib.sha256()

    with Path(path).open("rb") as handle:
        for chunk in iter(
            lambda: handle.read(1024 * 1024),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


if not CONTRACT_V1.exists():
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 missing."
    )


actual_contract_hash = sha256_file(
    CONTRACT_V1
)


if actual_contract_hash != EXPECTED_CONTRACT_SHA256:
    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 SHA-256 changed."
    )


batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if batch.file_sha256 != EXPECTED_SOURCE_SHA256:
    raise SystemExit(
        "STOPPED SAFELY: staged source SHA-256 mismatch."
    )


batch_metadata = (
    batch.metadata
    if isinstance(batch.metadata, dict)
    else {}
)


if (
    batch_metadata.get("operation")
    != "workbook_staging"
):
    raise SystemExit(
        "STOPPED SAFELY: Batch #5 is not the approved staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


if len(rows) != EXPECTED_IMPORT_ROWS:
    raise SystemExit(
        "STOPPED SAFELY: expected 478 staged rows."
    )


# ============================================================
# HELPERS
# ============================================================

def raw(row):
    return (
        row.raw_data
        if isinstance(row.raw_data, dict)
        else {}
    )


def meta(row):
    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def cells(row):
    value = raw(row).get(
        "cells",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def fields(row):
    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(value, dict)
        else {}
    )


def payload_value(payload):
    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def column_value(
    row,
    column,
):
    return payload_value(
        cells(row).get(
            column,
            {},
        )
    )


def normalize_identity(value):
    if value is None:
        return ""

    text = str(value).casefold()

    text = text.replace(
        "&",
        " and ",
    )

    text = re.sub(
        r"[_/]+",
        " ",
        text,
    )

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def normalize_content(value):
    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip().casefold()


def payload_populated(payload):
    if not isinstance(
        payload,
        dict,
    ):
        return False

    if payload_value(payload):
        return True

    if payload.get(
        "hyperlink_target"
    ):
        return True

    if payload.get(
        "hyperlink_location"
    ):
        return True

    return False


def commercial_shape(payload):
    if not isinstance(
        payload,
        dict,
    ):
        return "BLANK"

    value = payload_value(
        payload
    )

    if not value:
        return "BLANK"

    compact = (
        value
        .replace(",", "")
        .replace("₹", "")
        .strip()
    )

    if re.fullmatch(
        r"[-+]?\d+(?:\.\d+)?",
        compact,
    ):
        return "NUMERIC_LIKE"

    if re.search(
        r"\b(?:rs\.?|inr)\b|₹",
        value,
        flags=re.I,
    ):
        return "CURRENCY_TEXT"

    return "TEXT"


def service_match_score(
    candidate,
    text,
):
    """
    Conservative similarity used only for
    knowledge-anchor investigation.

    No fuzzy result is written to the database.
    """

    candidate = normalize_identity(
        candidate
    )

    text = normalize_identity(
        text
    )

    if not candidate or not text:
        return 0.0

    if candidate == text:
        return 1.0

    candidate_tokens = set(
        candidate.split()
    )

    text_tokens = set(
        text.split()
    )

    if not candidate_tokens:
        return 0.0

    shared = (
        candidate_tokens
        & text_tokens
    )

    coverage = (
        len(shared)
        / len(candidate_tokens)
    )

    union = (
        candidate_tokens
        | text_tokens
    )

    jaccard = (
        len(shared)
        / len(union)
        if union
        else 0.0
    )

    sequence = SequenceMatcher(
        None,
        candidate,
        text,
    ).ratio()

    # Strong phrase containment, but only for
    # multi-token candidate identities.
    if (
        len(candidate_tokens) >= 2
        and candidate_tokens.issubset(
            text_tokens
        )
    ):
        return max(
            0.96,
            sequence,
        )

    token_score = (
        0.65 * coverage
        + 0.35 * jaccard
    )

    return min(
        1.0,
        max(
            token_score,
            sequence * 0.80,
        ),
    )


# ============================================================
# 1. STRUCTURED CANONICAL SERVICES
# ============================================================

structured_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
        and row.source_key
    )
]


structured_by_identity = defaultdict(
    list
)


for row in structured_rows:
    scheme_name = payload_value(
        fields(row).get(
            "scheme_name",
            {},
        )
    )

    identity = normalize_identity(
        scheme_name
    )

    if identity:
        structured_by_identity[
            identity
        ].append(row)


structured_identities = set(
    structured_by_identity
)


if (
    len(structured_identities)
    != EXPECTED_STRUCTURED_IDENTITIES
):
    raise SystemExit(
        "STOPPED SAFELY: expected 100 structured identities."
    )


# ============================================================
# 2. BENEFITS — REFERENCE DATA ONLY
# ============================================================

benefit_rows = [
    row
    for row in rows
    if (
        row.sheet_name == "BENEFITS"
        and meta(row).get(
            "row_role"
        ) == "DATA"
    )
]


benefit_keys = {
    normalize_identity(
        column_value(
            row,
            "A",
        )
    )
    for row in benefit_rows
}


benefit_keys.discard(
    ""
)


# ============================================================
# 3. AMOUNT DEDUCTIONS — COMMERCIAL SERVICE CATALOGUE
# ============================================================

amount_rows = [
    row
    for row in rows
    if (
        row.sheet_name
        == "AMOUNT DEDUCTIONS"
        and meta(row).get(
            "row_role"
        ) == "DATA"
    )
]


commercial_rows_by_identity = defaultdict(
    list
)

commercial_column_shapes = {
    column: Counter()
    for column in (
        "B",
        "C",
        "D",
        "E",
    )
}

commercial_presence_counts = Counter()

rows_with_any_commercial_evidence = 0
rows_without_commercial_evidence = 0


for row in amount_rows:
    identity = normalize_identity(
        column_value(
            row,
            "A",
        )
    )

    if not identity:
        continue

    commercial_rows_by_identity[
        identity
    ].append(row)

    present = 0

    for column in (
        "B",
        "C",
        "D",
        "E",
    ):
        payload = cells(row).get(
            column,
            {},
        )

        commercial_column_shapes[
            column
        ][
            commercial_shape(
                payload
            )
        ] += 1

        if payload_populated(
            payload
        ):
            present += 1

    commercial_presence_counts[
        present
    ] += 1

    if present:
        rows_with_any_commercial_evidence += 1
    else:
        rows_without_commercial_evidence += 1


commercial_identities = set(
    commercial_rows_by_identity
)


if (
    len(commercial_identities)
    != EXPECTED_COMMERCIAL_UNIQUE_LABELS
):
    raise SystemExit(
        "STOPPED SAFELY: expected 61 unique commercial labels."
    )


commercial_with_evidence = {
    identity
    for identity, identity_rows
    in commercial_rows_by_identity.items()
    if any(
        any(
            payload_populated(
                cells(row).get(
                    column,
                    {},
                )
            )
            for column in (
                "B",
                "C",
                "D",
                "E",
            )
        )
        for row in identity_rows
    )
}


commercial_overlap_structured = (
    commercial_identities
    & structured_identities
)


commercial_additional = (
    commercial_identities
    - structured_identities
)


confirmed_base_service_universe = (
    structured_identities
    | commercial_identities
)


# ============================================================
# 4. ROLLING GRANTS
# ============================================================

rolling_rows = [
    row
    for row in rows
    if row.sheet_name
    == "Rolling_Grants"
]


rolling_identities = []


for row in rolling_rows:
    identity = normalize_identity(
        column_value(
            row,
            "A",
        )
    )

    if identity:
        rolling_identities.append(
            identity
        )


rolling_unique = set(
    rolling_identities
)


rolling_matching_structured = (
    rolling_unique
    & structured_identities
)

rolling_matching_commercial = (
    rolling_unique
    & commercial_identities
)

rolling_new_candidates = (
    rolling_unique
    - structured_identities
    - commercial_identities
)


# ============================================================
# 5. INFER ROLLING_GRANTS B/C/E COLUMN SEMANTICS
#
# Use the five rows whose Column A already matches a
# known structured identity.
# ============================================================

rolling_semantic_matches = {
    column: Counter()
    for column in (
        "B",
        "C",
        "E",
    )
}

rolling_matched_rows_used = 0


for rolling_row in rolling_rows:
    identity = normalize_identity(
        column_value(
            rolling_row,
            "A",
        )
    )

    if identity not in structured_by_identity:
        continue

    rolling_matched_rows_used += 1

    source_group = (
        structured_by_identity[
            identity
        ]
    )

    for rolling_column in (
        "B",
        "C",
        "E",
    ):
        rolling_value = normalize_content(
            column_value(
                rolling_row,
                rolling_column,
            )
        )

        if not rolling_value:
            continue

        for field_name in (
            ROLLING_COMPARE_FIELDS
        ):
            matched = False

            for source_row in source_group:
                source_value = normalize_content(
                    payload_value(
                        fields(source_row).get(
                            field_name,
                            {},
                        )
                    )
                )

                if (
                    source_value
                    and source_value
                    == rolling_value
                ):
                    matched = True
                    break

            if matched:
                rolling_semantic_matches[
                    rolling_column
                ][
                    field_name
                ] += 1


rolling_column_inference = {}


for column in (
    "B",
    "C",
    "E",
):
    counter = (
        rolling_semantic_matches[
            column
        ]
    )

    if not counter:
        rolling_column_inference[
            column
        ] = {
            "status": "UNRESOLVED",
            "field": None,
            "matches": 0,
            "runner_up": 0,
        }

        continue

    ranked = counter.most_common()

    best_field, best_count = (
        ranked[0]
    )

    runner_up = (
        ranked[1][1]
        if len(ranked) > 1
        else 0
    )

    if (
        best_count >= 3
        and best_count > runner_up
    ):
        status = (
            "STRONG_INFERENCE"
        )

    elif best_count >= 2:
        status = (
            "PARTIAL_INFERENCE"
        )

    else:
        status = (
            "WEAK_INFERENCE"
        )

    rolling_column_inference[
        column
    ] = {
        "status": status,
        "field": best_field,
        "matches": best_count,
        "runner_up": runner_up,
    }


# ============================================================
# 6. PROSPECTIVE SERVICE UNIVERSE WITH ROLLING GRANTS
#
# The two unmatched Rolling Grant Column-A identities are
# treated as prospective scheme candidates because:
# - the sheet is classified as ROLLING_GRANTS,
# - all seven rows have the same four-column shape,
# - five of seven already resolve to canonical schemes.
#
# Still simulation only.
# ============================================================

prospective_service_universe = (
    confirmed_base_service_universe
    | rolling_unique
)


# ============================================================
# 7. KNOWLEDGE-SHEET ANCHOR RESOLUTION
#
# No source text or Service names are printed.
# ============================================================

knowledge_anchor_results = {}


for sheet_name in KNOWLEDGE_SHEETS:
    sheet_rows = [
        row
        for row in rows
        if row.sheet_name
        == sheet_name
    ]

    source_texts = [
        sheet_name
    ]

    for row in sheet_rows:
        for payload in cells(
            row
        ).values():
            text = payload_value(
                payload
            )

            if text:
                source_texts.append(
                    text
                )

    candidate_scores = []

    for candidate in (
        prospective_service_universe
    ):
        best_score = 0.0

        for source_text in (
            source_texts
        ):
            score = service_match_score(
                candidate,
                source_text,
            )

            if score > best_score:
                best_score = score

        candidate_scores.append(
            (
                best_score,
                candidate,
            )
        )

    candidate_scores.sort(
        reverse=True,
        key=lambda item: item[0],
    )

    top_score = (
        candidate_scores[0][0]
        if candidate_scores
        else 0.0
    )

    second_score = (
        candidate_scores[1][0]
        if len(candidate_scores) > 1
        else 0.0
    )

    gap = (
        top_score
        - second_score
    )

    top_identity = (
        candidate_scores[0][1]
        if candidate_scores
        else None
    )

    if (
        top_score >= 0.95
        and gap >= 0.05
    ):
        status = (
            "HIGH_CONFIDENCE_MATCH"
        )

    elif (
        top_score >= 0.85
        and gap >= 0.10
    ):
        status = (
            "LIKELY_MATCH"
        )

    else:
        status = (
            "REVIEW_REQUIRED"
        )

    if top_identity in structured_identities:
        source_family = (
            "STRUCTURED"
        )

    elif top_identity in commercial_identities:
        source_family = (
            "COMMERCIAL"
        )

    elif top_identity in rolling_new_candidates:
        source_family = (
            "ROLLING_NEW"
        )

    else:
        source_family = (
            "NONE"
        )

    knowledge_anchor_results[
        sheet_name
    ] = {
        "status": status,
        "top_score": round(
            top_score,
            3,
        ),
        "second_score": round(
            second_score,
            3,
        ),
        "gap": round(
            gap,
            3,
        ),
        "candidate_source_family": (
            source_family
        ),
        "staged_rows": len(
            sheet_rows
        ),
    }


knowledge_status_counts = Counter(
    result[
        "status"
    ]
    for result in (
        knowledge_anchor_results.values()
    )
)


# ============================================================
# 8. ONBOARDING MAIL SEGMENTATION
# ============================================================

onboarding_rows = [
    row
    for row in rows
    if row.sheet_name
    == "ONBOARDING_MAIL"
]


onboarding_source_rows = sorted(
    row.source_row_number
    for row in onboarding_rows
)


mail_blocks = []


if onboarding_source_rows:
    start = (
        onboarding_source_rows[0]
    )

    previous = start

    for current in (
        onboarding_source_rows[1:]
    ):
        if current == previous + 1:
            previous = current
            continue

        mail_blocks.append(
            (
                start,
                previous,
            )
        )

        start = current
        previous = current

    mail_blocks.append(
        (
            start,
            previous,
        )
    )


mail_block_lengths = Counter(
    end - start + 1
    for start, end
    in mail_blocks
)


mail_line_patterns = Counter()


for row in onboarding_rows:
    text = column_value(
        row,
        "A",
    )

    lowered = text.casefold()

    if re.match(
        r"^\s*subject\s*[:\-]",
        lowered,
    ):
        mail_line_patterns[
            "SUBJECT_PREFIX"
        ] += 1

    elif re.match(
        r"^\s*(dear|hello|hi)\b",
        lowered,
    ):
        mail_line_patterns[
            "GREETING_LIKE"
        ] += 1

    elif re.search(
        r"\b(regards|sincerely|thanks|thank you)\b",
        lowered,
    ):
        mail_line_patterns[
            "CLOSING_LIKE"
        ] += 1

    else:
        mail_line_patterns[
            "BODY_OR_OTHER"
        ] += 1


# ============================================================
# 9. SOURCE SUPPORT DISTRIBUTION
# ============================================================

support = defaultdict(
    set
)


for identity in structured_identities:
    support[
        identity
    ].add(
        "STRUCTURED"
    )


for identity in commercial_identities:
    support[
        identity
    ].add(
        "COMMERCIAL"
    )


for identity in rolling_unique:
    support[
        identity
    ].add(
        "ROLLING_GRANTS"
    )


support_distribution = Counter(
    len(
        support[
            identity
        ]
    )
    for identity in (
        prospective_service_universe
    )
)


# ============================================================
# 10. LIVE DESTINATION SAFETY
# ============================================================

destination_counts = {
    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if (
    destination_counts[
        "Service"
    ]
    != 1
):
    raise SystemExit(
        "STOPPED SAFELY: live Service count changed."
    )


for model_name in (
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):
    if (
        destination_counts[
            model_name
        ]
        != 0
    ):
        raise SystemExit(
            "STOPPED SAFELY: "
            f"{model_name} unexpectedly contains data."
        )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10g_final_service_universe_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10G FINAL SERVICE UNIVERSE RESOLUTION"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    f"Contract SHA-256: "
    f"{actual_contract_hash}"
)

lines.append(
    "Approved staged source verified: YES"
)

lines.append(
    f"Import Batch ID: "
    f"{batch.pk}"
)

lines.append(
    "Workbook opened: NO"
)

lines.append(
    "Database writes performed: NO"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. STRUCTURED SERVICE INVENTORY"
)
# ------------------------------------------------------------

lines.append(
    f"  Named structured source rows: "
    f"{len(structured_rows)}"
)

lines.append(
    f"  Canonical structured Service identities: "
    f"{len(structured_identities)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. COMMERCIAL SERVICE CATALOGUE"
)
# ------------------------------------------------------------

lines.append(
    f"  AMOUNT DEDUCTIONS data rows: "
    f"{len(amount_rows)}"
)

lines.append(
    f"  Unique normalized service labels: "
    f"{len(commercial_identities)}"
)

lines.append(
    f"  Unique labels with commercial evidence: "
    f"{len(commercial_with_evidence)}"
)

lines.append(
    f"  Labels overlapping structured Services: "
    f"{len(commercial_overlap_structured)}"
)

lines.append(
    f"  Additional commercial Service identities: "
    f"{len(commercial_additional)}"
)

lines.append(
    f"  Rows with at least one B-E field: "
    f"{rows_with_any_commercial_evidence}"
)

lines.append(
    f"  Rows without B-E evidence: "
    f"{rows_without_commercial_evidence}"
)


for field_count, row_count in sorted(
    commercial_presence_counts.items()
):
    lines.append(
        f"  Rows with {field_count} populated "
        f"commercial field(s) B-E: "
        f"{row_count}"
    )


lines.append("")

lines.append(
    "  COMMERCIAL FIELD SHAPES"
)


for column in (
    "B",
    "C",
    "D",
    "E",
):
    description = ", ".join(
        f"{shape}={count}"
        for shape, count
        in sorted(
            commercial_column_shapes[
                column
            ].items()
        )
    )

    lines.append(
        f"    Column {column}: "
        f"{description}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. CONFIRMED BASE SERVICE UNIVERSE"
)
# ------------------------------------------------------------

lines.append(
    f"  Structured Services: "
    f"{len(structured_identities)}"
)

lines.append(
    f"  Unique commercial catalogue Services: "
    f"{len(commercial_identities)}"
)

lines.append(
    f"  Structured/commercial overlap: "
    f"{len(commercial_overlap_structured)}"
)

lines.append(
    f"  Confirmed union before Rolling Grants: "
    f"{len(confirmed_base_service_universe)}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. ROLLING GRANTS RESOLUTION"
)
# ------------------------------------------------------------

lines.append(
    f"  Rolling Grant rows: "
    f"{len(rolling_rows)}"
)

lines.append(
    f"  Unique Column-A identities: "
    f"{len(rolling_unique)}"
)

lines.append(
    f"  Match structured Services: "
    f"{len(rolling_matching_structured)}"
)

lines.append(
    f"  Match commercial Services: "
    f"{len(rolling_matching_commercial)}"
)

lines.append(
    f"  New Rolling Grant Service candidates: "
    f"{len(rolling_new_candidates)}"
)

lines.append(
    f"  Known matched rows used for "
    f"column inference: "
    f"{rolling_matched_rows_used}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. ROLLING GRANTS COLUMN INFERENCE"
)
# ------------------------------------------------------------

for column in (
    "B",
    "C",
    "E",
):
    result = (
        rolling_column_inference[
            column
        ]
    )

    lines.append(
        f"  Column {column}: "
        f"status={result['status']} | "
        f"best_field="
        f"{result['field'] or 'NONE'} | "
        f"exact_matches="
        f"{result['matches']} | "
        f"runner_up="
        f"{result['runner_up']}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. PROSPECTIVE COMPLETE SERVICE UNIVERSE"
)
# ------------------------------------------------------------

lines.append(
    f"  Confirmed base union: "
    f"{len(confirmed_base_service_universe)}"
)

lines.append(
    f"  New Rolling Grant candidates: "
    f"{len(rolling_new_candidates)}"
)

lines.append(
    f"  Prospective Service identities: "
    f"{len(prospective_service_universe)}"
)

lines.append(
    "  BENEFITS keys promoted to Services: 0"
)

lines.append(
    "  Knowledge-sheet rows promoted "
    "to Services automatically: 0"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. KNOWLEDGE SHEET ANCHOR RESOLUTION"
)
# ------------------------------------------------------------

for sheet_name in KNOWLEDGE_SHEETS:
    result = (
        knowledge_anchor_results[
            sheet_name
        ]
    )

    lines.append(
        f"  {sheet_name}: "
        f"status={result['status']} | "
        f"top_score="
        f"{result['top_score']:.3f} | "
        f"runner_up="
        f"{result['second_score']:.3f} | "
        f"gap="
        f"{result['gap']:.3f} | "
        f"candidate_family="
        f"{result['candidate_source_family']} | "
        f"content_rows="
        f"{result['staged_rows']}"
    )


lines.append(
    "  Anchor status totals:"
)


for status, count in sorted(
    knowledge_status_counts.items()
):
    lines.append(
        f"    {status}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. BENEFITS REFERENCE ARCHITECTURE"
)
# ------------------------------------------------------------

lines.append(
    f"  Benefit data rows: "
    f"{len(benefit_rows)}"
)

lines.append(
    f"  Unique Benefit reference keys: "
    f"{len(benefit_keys)}"
)

lines.append(
    "  Destination: ReferenceItem"
)

lines.append(
    "  Automatic Service creation from "
    "Benefit keys: NO"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "9. ONBOARDING MAIL SEGMENTATION"
)
# ------------------------------------------------------------

lines.append(
    f"  Staged content lines: "
    f"{len(onboarding_rows)}"
)

lines.append(
    f"  Contiguous source blocks: "
    f"{len(mail_blocks)}"
)


for block_length, count in sorted(
    mail_block_lengths.items()
):
    lines.append(
        f"  Blocks with "
        f"{block_length} line(s): "
        f"{count}"
    )


lines.append(
    "  Structural line patterns:"
)


for pattern, count in sorted(
    mail_line_patterns.items()
):
    lines.append(
        f"    {pattern}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "10. SOURCE SUPPORT DISTRIBUTION"
)
# ------------------------------------------------------------

for source_family_count, service_count in sorted(
    support_distribution.items()
):
    lines.append(
        f"  Service identities represented "
        f"in {source_family_count} source "
        f"family/families: "
        f"{service_count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "11. LIVE DESTINATION SAFETY"
)
# ------------------------------------------------------------

for model_name, count in (
    destination_counts.items()
):
    lines.append(
        f"  {model_name}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "12. WRITE / CONFIDENTIALITY SAFETY"
)
# ------------------------------------------------------------

lines.append(
    "  Mapping Contract v1 modified: NO"
)

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  ServiceCommercial records created: 0"
)

lines.append(
    "  ServiceContentSection records created: 0"
)

lines.append(
    "  ReferenceItem records created: 0"
)

lines.append(
    "  Comparison records created: 0"
)

lines.append(
    "  CommunicationTemplate records created: 0"
)

lines.append(
    "  Workbook opened: NO"
)

lines.append(
    "  Service names printed: NO"
)

lines.append(
    "  Commercial amounts printed: NO"
)

lines.append(
    "  Benefit values printed: NO"
)

lines.append(
    "  Knowledge content printed: NO"
)

lines.append(
    "  URLs printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10G AUDIT COMPLETE"
)

print(
    f"Confirmed base Service identities: "
    f"{len(confirmed_base_service_universe)}"
)

print(
    f"Prospective Service identities "
    f"including Rolling Grants: "
    f"{len(prospective_service_universe)}"
)

print(
    f"SAFE REPORT: {output}"
)
