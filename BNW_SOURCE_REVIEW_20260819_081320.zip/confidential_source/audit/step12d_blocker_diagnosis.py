import hashlib
import os
import re
import sys

from collections import Counter
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import django
django.setup()


from django.apps import apps
from django.db import connection

from toolkit.importing.transformation import (
    build_core_transformation_plan,
    load_verified_context,
)

from toolkit.importing.supporting_transformation import (
    build_supporting_transformation_plan,
)


# ============================================================
# HELPERS
# ============================================================

def model(name):
    return apps.get_model(
        "toolkit",
        name,
    )


def anon_service(identity):
    return (
        "SVC-"
        + hashlib.sha256(
            str(identity).encode("utf-8")
        ).hexdigest()[:10].upper()
    )


def recursive_row_reference_count(
    obj,
    row_id,
):
    count = 0

    if isinstance(obj, dict):

        for key, value in obj.items():

            if key in {
                "source_import_row_id",
                "import_row_id",
                "source_row_id",
            }:
                if value == row_id:
                    count += 1

            elif key in {
                "source_row_ids",
                "import_row_ids",
                "source_import_row_ids",
            }:
                if isinstance(
                    value,
                    (list, tuple, set),
                ):
                    count += sum(
                        1
                        for item in value
                        if item == row_id
                    )

            count += recursive_row_reference_count(
                value,
                row_id,
            )

    elif isinstance(
        obj,
        (list, tuple, set),
    ):

        for item in obj:
            count += recursive_row_reference_count(
                item,
                row_id,
            )

    return count


def field_summary(
    model_obj,
    field_name,
):

    field = model_obj._meta.get_field(
        field_name
    )

    remote = getattr(
        field,
        "remote_field",
        None,
    )

    related_model = None
    on_delete_name = None

    if remote is not None:

        related = getattr(
            remote,
            "model",
            None,
        )

        if related is not None:
            related_model = getattr(
                related,
                "__name__",
                str(related),
            )

        on_delete = getattr(
            remote,
            "on_delete",
            None,
        )

        if on_delete is not None:
            on_delete_name = getattr(
                on_delete,
                "__name__",
                str(on_delete),
            )

    return {
        "type":
            field.__class__.__name__,

        "null":
            getattr(field, "null", False),

        "blank":
            getattr(field, "blank", False),

        "unique":
            getattr(field, "unique", False),

        "related_model":
            related_model,

        "on_delete":
            on_delete_name,

        "choices":
            list(
                getattr(
                    field,
                    "choices",
                    [],
                )
                or []
            ),
    }


# ============================================================
# BASELINE
# ============================================================

print("=" * 84)
print("BHARATNXT WAVE — STEP 12D BLOCKER DIAGNOSIS")
print("=" * 84)
print()
print("MODE: READ ONLY")
print("DATABASE WRITES: NO")
print("BUSINESS VALUES PRINTED: NO")


contract, batch, staged_rows = (
    load_verified_context()
)

staged_rows = list(
    staged_rows
)

core = (
    build_core_transformation_plan()
)

supporting = (
    build_supporting_transformation_plan(
        core
    )
)


print()
print("=" * 84)
print("1. VERIFIED CONTEXT")
print("=" * 84)

print(
    "Contract version:",
    contract.get(
        "contract",
        {},
    ).get(
        "version",
        "UNKNOWN",
    ),
)

print(
    "Batch:",
    batch.id,
)

print(
    "Batch status:",
    batch.status,
)

print(
    "Staged rows:",
    len(staged_rows),
)


# ============================================================
# VALIDATION ACCOUNTING
# ============================================================

print()
print("=" * 84)
print("2. VALIDATION ACCOUNTING DIAGNOSIS")
print("=" * 84)


plan_validation = core.get(
    "validation",
    {},
)


print(
    "Core validation metric count:",
    len(plan_validation),
)

print(
    "Core validation metrics:"
)


plan_total = 0

for key in sorted(
    plan_validation.keys()
):

    value = plan_validation[
        key
    ]

    print(
        f"  {key}: {value}"
    )

    if isinstance(
        value,
        int,
    ):
        plan_total += value


print(
    "Naive sum of core validation metrics:",
    plan_total,
)


db_validation = Counter(
    str(
        row.validation_status
    ).upper()
    for row in staged_rows
)


print()
print(
    "Actual ImportRow.validation_status counts:"
)

for key, value in sorted(
    db_validation.items()
):
    print(
        f"  {key}: {value}"
    )


print(
    "Actual validation-status row total:",
    sum(
        db_validation.values()
    ),
)


candidate_actions = Counter(
    str(
        row.candidate_action
    ).upper()
    for row in staged_rows
)


print()
print(
    "Actual ImportRow.candidate_action counts:"
)

for key, value in sorted(
    candidate_actions.items()
):
    print(
        f"  {key}: {value}"
    )


print(
    "Actual candidate-action row total:",
    sum(
        candidate_actions.values()
    ),
)


if (
    sum(
        db_validation.values()
    )
    == 478
):

    print(
        "VALIDATION STATUS PARTITION: PASS"
    )

else:

    print(
        "VALIDATION STATUS PARTITION: FAIL"
    )


if plan_total != 478:

    print(
        "CORE VALIDATION METRICS ARE NOT SAFE "
        "TO TREAT AS A SIMPLE 478-ROW PARTITION."
    )


# ============================================================
# ROLLING GRANTS DIAGNOSIS
# ============================================================

print()
print("=" * 84)
print("3. ROLLING_GRANTS LINEAGE DIAGNOSIS")
print("=" * 84)


rolling_rows = sorted(
    [
        row
        for row in staged_rows
        if row.sheet_name
        == "Rolling_Grants"
    ],
    key=lambda row: (
        row.source_row_number,
        row.id,
    ),
)


print(
    "Rolling_Grants staged rows:",
    len(rolling_rows),
)


services = core.get(
    "services",
    {},
)

classifications = core.get(
    "classifications",
    [],
)

commercial = core.get(
    "commercial",
    [],
)


referenced_count = 0
unreferenced_count = 0


for ordinal, row in enumerate(
    rolling_rows,
    start=1,
):

    service_refs = []

    for identity, service_plan in (
        services.items()
    ):

        ids = service_plan.get(
            "source_row_ids",
            [],
        )

        if row.id in ids:

            service_refs.append(
                anon_service(
                    identity
                )
            )


    classification_refs = sum(
        1
        for item in classifications
        if item.get(
            "source_import_row_id"
        )
        == row.id
    )


    commercial_refs = sum(
        1
        for item in commercial
        if item.get(
            "source_import_row_id"
        )
        == row.id
    )


    supporting_refs = (
        recursive_row_reference_count(
            supporting,
            row.id,
        )
    )


    total_refs = (
        len(service_refs)
        + classification_refs
        + commercial_refs
        + supporting_refs
    )


    if total_refs:
        referenced_count += 1
    else:
        unreferenced_count += 1


    anonymous_targets = (
        ",".join(
            sorted(
                set(
                    service_refs
                )
            )
        )
        if service_refs
        else "NONE"
    )


    print(
        (
            f"Row {ordinal}: "
            f"source_row={row.source_row_number} | "
            f"validation={row.validation_status} | "
            f"action={row.candidate_action} | "
            f"service_refs={len(service_refs)} | "
            f"classification_refs={classification_refs} | "
            f"commercial_refs={commercial_refs} | "
            f"supporting_refs={supporting_refs} | "
            f"targets={anonymous_targets}"
        )
    )


print()
print(
    "Rolling rows with transformation references:",
    referenced_count,
)

print(
    "Rolling rows without transformation references:",
    unreferenced_count,
)


# ============================================================
# KNOWLEDGE MODEL DIAGNOSIS
# ============================================================

print()
print("=" * 84)
print("4. KNOWLEDGE MODEL DIAGNOSIS")
print("=" * 84)


ServiceContentSection = model(
    "ServiceContentSection"
)


for field_name in (
    "service",
    "section_type",
    "title",
    "content",
    "display_order",
    "visibility",
    "source_import_row",
):

    info = field_summary(
        ServiceContentSection,
        field_name,
    )

    print(
        (
            f"{field_name}: "
            f"type={info['type']} | "
            f"null={info['null']} | "
            f"blank={info['blank']} | "
            f"related={info['related_model']} | "
            f"on_delete={info['on_delete']}"
        )
    )


section_type_info = (
    field_summary(
        ServiceContentSection,
        "section_type",
    )
)

visibility_info = (
    field_summary(
        ServiceContentSection,
        "visibility",
    )
)


print()
print(
    "ServiceContentSection section_type choices:"
)

for value, label in (
    section_type_info[
        "choices"
    ]
):
    print(
        f"  {value}"
    )


print()
print(
    "ServiceContentSection visibility choices:"
)

for value, label in (
    visibility_info[
        "choices"
    ]
):
    print(
        f"  {value}"
    )


for proposed_model in (
    "KnowledgeDocument",
    "KnowledgeSection",
):

    try:

        model(
            proposed_model
        )

        exists = True

    except LookupError:

        exists = False

    print(
        f"{proposed_model} exists:",
        exists,
    )


# ============================================================
# IMPORT CHANGE SCHEMA
# ============================================================

print()
print("=" * 84)
print("5. IMPORT CHANGE / ROLLBACK SCHEMA")
print("=" * 84)


ImportChange = model(
    "ImportChange"
)


for field in ImportChange._meta.get_fields():

    if not getattr(
        field,
        "concrete",
        False,
    ):
        continue

    info = field_summary(
        ImportChange,
        field.name,
    )

    print(
        (
            f"{field.name}: "
            f"{info['type']} | "
            f"null={info['null']} | "
            f"blank={info['blank']} | "
            f"related={info['related_model']} | "
            f"on_delete={info['on_delete']}"
        )
    )


action_info = (
    field_summary(
        ImportChange,
        "action",
    )
)


print()
print(
    "ImportChange action choices:"
)

for value, label in (
    action_info[
        "choices"
    ]
):
    print(
        f"  {value}"
    )


# ============================================================
# IMPORT / ATOMIC / LEDGER CODE EVIDENCE
# ============================================================

print()
print("=" * 84)
print("6. IMPORT ENGINE CODE EVIDENCE")
print("=" * 84)


patterns = {
    "transaction.atomic":
        re.compile(
            r"transaction\s*\.\s*atomic"
        ),

    "ImportChange.objects.create":
        re.compile(
            r"ImportChange\s*\.\s*objects\s*\.\s*create"
        ),

    "ImportChange.objects.bulk_create":
        re.compile(
            r"ImportChange\s*\.\s*objects\s*\.\s*bulk_create"
        ),

    "rollback function":
        re.compile(
            r"def\s+[A-Za-z0-9_]*rollback[A-Za-z0-9_]*\s*\(",
            re.IGNORECASE,
        ),

    "rolled_back status":
        re.compile(
            r"ROLLED_BACK"
        ),
}


hits = {
    key: []
    for key in patterns
}


for path in sorted(
    (ROOT / "toolkit").rglob(
        "*.py"
    )
):

    try:

        lines = path.read_text(
            encoding="utf-8",
            errors="ignore",
        ).splitlines()

    except Exception:

        continue


    for line_number, line in enumerate(
        lines,
        start=1,
    ):

        for label, regex in (
            patterns.items()
        ):

            if regex.search(
                line
            ):

                relative = path.relative_to(
                    ROOT
                )

                hits[
                    label
                ].append(
                    f"{relative}:{line_number}"
                )


for label, locations in (
    hits.items()
):

    print()
    print(
        f"{label}: {len(locations)} hit(s)"
    )

    for location in locations[:30]:

        print(
            f"  {location}"
        )


# ============================================================
# DATABASE SAFETY
# ============================================================

print()
print("=" * 84)
print("7. DATABASE SAFETY")
print("=" * 84)


with connection.cursor() as cursor:

    cursor.execute(
        "PRAGMA integrity_check;"
    )

    integrity = cursor.fetchone()

    cursor.execute(
        "PRAGMA foreign_key_check;"
    )

    fk_rows = cursor.fetchall()


print(
    "integrity_check:",
    integrity[0]
    if integrity
    else "NO RESULT",
)

print(
    "foreign_key_check violations:",
    len(fk_rows),
)


for model_name in (
    "Service",
    "Category",
    "ImportRow",
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceSource",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
):

    print(
        f"{model_name}: "
        f"{model(model_name).objects.count()}"
    )


print()
print("=" * 84)
print("STEP 12D DIAGNOSIS COMPLETE")
print("DATABASE WRITES: NO")
print("LIVE IMPORT: NOT STARTED")
print("=" * 84)
