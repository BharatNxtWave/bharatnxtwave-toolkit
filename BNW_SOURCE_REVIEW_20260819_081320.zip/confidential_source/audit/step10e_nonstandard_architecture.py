import hashlib
import os
import statistics
import sys

from collections import Counter
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

PROJECT_ROOT = Path.cwd()

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(PROJECT_ROOT),
    )


import django
django.setup()


from openpyxl import load_workbook


from toolkit.models import (
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
)


# ============================================================
# CONSTANTS
# ============================================================

BATCH_ID = 5

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

CONTRACT_V1 = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)


EXPECTED_NONSTANDARD_ROWS = 365


EXPECTED_FAMILY_COUNTS = {
    "REFERENCE_TABLE": 108,
    "COMPARISON_MATRIX": 23,
    "KNOWLEDGE": 207,
    "COMMUNICATION": 20,
    "ROLLING_GRANTS": 7,
}


EXPECTED_SHEET_COUNTS = {
    "BENEFITS": 45,
    "START_UP INDIA": 43,
    "LOAN": 23,
    "TAX_CERT": 22,
    "SEED FUND": 41,
    "PVT": 62,
    "LLP": 39,
    "AMOUNT DEDUCTIONS": 63,
    "ONBOARDING_MAIL": 20,
    "Rolling_Grants": 7,
}


DESTINATION_PLAN = {
    "BENEFITS": (
        "REFERENCE_ITEM"
    ),

    "AMOUNT DEDUCTIONS": (
        "COMMERCIAL_AND_REFERENCE_SPLIT"
    ),

    "LOAN": (
        "COMPARISON_MATRIX"
    ),

    "START_UP INDIA": (
        "SERVICE_CONTENT"
    ),

    "TAX_CERT": (
        "SERVICE_CONTENT"
    ),

    "SEED FUND": (
        "SERVICE_CONTENT"
    ),

    "PVT": (
        "SERVICE_CONTENT"
    ),

    "LLP": (
        "SERVICE_CONTENT"
    ),

    "ONBOARDING_MAIL": (
        "COMMUNICATION_TEMPLATE"
    ),

    "Rolling_Grants": (
        "STRUCTURED_SERVICE_REVIEW"
    ),
}


# ============================================================
# HASH HELPERS
# ============================================================

def sha256_file(path):

    digest = hashlib.sha256()

    with Path(path).open("rb") as file:

        for chunk in iter(
            lambda: file.read(
                1024 * 1024
            ),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


# ============================================================
# CONTRACT INTEGRITY
# ============================================================

if not CONTRACT_V1.exists():

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "does not exist."
    )


contract_hash = sha256_file(
    CONTRACT_V1
)


if contract_hash != EXPECTED_CONTRACT_SHA256:

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 changed."
    )


# ============================================================
# EXACT WORKBOOK
# ============================================================

source_dir = Path(
    "confidential_source"
)


approved_workbooks = []


for candidate in source_dir.glob(
    "*.xlsx"
):

    if candidate.name.startswith(
        "~$"
    ):
        continue

    try:

        if (
            sha256_file(candidate)
            == EXPECTED_SOURCE_SHA256
        ):

            approved_workbooks.append(
                candidate
            )

    except OSError:
        continue


if len(approved_workbooks) != 1:

    raise SystemExit(
        "STOPPED SAFELY: expected exactly "
        "one approved workbook; found "
        f"{len(approved_workbooks)}."
    )


workbook_path = approved_workbooks[0]


# ============================================================
# BATCH
# ============================================================

batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if batch.file_sha256 != EXPECTED_SOURCE_SHA256:

    raise SystemExit(
        "STOPPED SAFELY: ImportBatch source "
        "SHA-256 mismatch."
    )


metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if (
    metadata.get("operation")
    != "workbook_staging"
):

    raise SystemExit(
        "STOPPED SAFELY: ImportBatch #5 "
        "is not the staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


# ============================================================
# STAGED HELPERS
# ============================================================

def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def cells(row):

    value = raw(row).get(
        "cells",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


# ============================================================
# NON-STANDARD ROWS
# ============================================================

nonstandard_rows = [
    row
    for row in rows
    if (
        meta(row).get("family")
        != "SCHEME_TABLE"
    )
]


if len(nonstandard_rows) != EXPECTED_NONSTANDARD_ROWS:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        f"{EXPECTED_NONSTANDARD_ROWS} "
        "non-standard rows; found "
        f"{len(nonstandard_rows)}."
    )


family_counts = Counter(
    meta(row).get(
        "family",
        "UNKNOWN",
    )
    for row in nonstandard_rows
)


if dict(family_counts) != EXPECTED_FAMILY_COUNTS:

    raise SystemExit(
        "STOPPED SAFELY: non-standard "
        "family counts changed."
    )


sheet_counts = Counter(
    row.sheet_name
    for row in nonstandard_rows
)


for sheet_name, expected in (
    EXPECTED_SHEET_COUNTS.items()
):

    actual = sheet_counts[
        sheet_name
    ]

    if actual != expected:

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{sheet_name} expected "
            f"{expected} staged rows, "
            f"found {actual}."
        )


# ============================================================
# STAGED SHAPE PROFILE
# ============================================================

sheet_profiles = {}


for sheet_name in (
    EXPECTED_SHEET_COUNTS
):

    sheet_rows = [
        row
        for row in nonstandard_rows
        if row.sheet_name == sheet_name
    ]


    role_counts = Counter()

    populated_cell_counts = Counter()

    column_presence = Counter()

    formulas = 0

    hyperlink_cells = 0

    merged_resolutions = 0

    source_row_numbers = []


    for row in sheet_rows:

        source_row_numbers.append(
            row.source_row_number
        )


        role_counts[
            meta(row).get(
                "row_role",
                "UNKNOWN",
            )
        ] += 1


        row_cells = cells(
            row
        )


        populated_cell_counts[
            len(row_cells)
        ] += 1


        for column, payload in (
            row_cells.items()
        ):

            column_presence[
                column
            ] += 1


            if not isinstance(
                payload,
                dict,
            ):
                continue


            if payload.get(
                "cell_type"
            ) == "f":

                formulas += 1


            if (
                payload.get(
                    "hyperlink_target"
                )
                or payload.get(
                    "hyperlink_location"
                )
            ):

                hyperlink_cells += 1


            if payload.get(
                "merged_from"
            ):

                merged_resolutions += 1


    # --------------------------------------------------------
    # Contiguous source blocks
    # --------------------------------------------------------

    ordered = sorted(
        source_row_numbers
    )

    contiguous_blocks = []


    if ordered:

        block_start = ordered[0]

        previous = ordered[0]


        for current in ordered[1:]:

            if current == previous + 1:

                previous = current
                continue


            contiguous_blocks.append(
                (
                    block_start,
                    previous,
                )
            )

            block_start = current
            previous = current


        contiguous_blocks.append(
            (
                block_start,
                previous,
            )
        )


    sheet_profiles[
        sheet_name
    ] = {
        "role_counts": role_counts,
        "populated_cell_counts": (
            populated_cell_counts
        ),
        "column_presence": (
            column_presence
        ),
        "formulas": formulas,
        "hyperlink_cells": (
            hyperlink_cells
        ),
        "merged_resolutions": (
            merged_resolutions
        ),
        "contiguous_blocks": (
            contiguous_blocks
        ),
    }


# ============================================================
# WORKBOOK STYLE AUDIT
#
# NO CELL VALUES ARE PRINTED OR SAVED.
# ============================================================

workbook = load_workbook(
    workbook_path,
    read_only=False,
    data_only=False,
    keep_links=True,
)


style_profiles = {}


try:

    for sheet_name in (
        EXPECTED_SHEET_COUNTS
    ):

        worksheet = workbook[
            sheet_name
        ]


        staged_source_rows = {
            row.source_row_number
            for row in nonstandard_rows
            if row.sheet_name
            == sheet_name
        }


        font_sizes = []


        for row_number in (
            staged_source_rows
        ):

            for cell in worksheet[
                row_number
            ]:

                if cell.value is None:
                    continue


                if cell.font.size:

                    try:

                        font_sizes.append(
                            float(
                                cell.font.size
                            )
                        )

                    except (
                        TypeError,
                        ValueError,
                    ):
                        pass


        median_font_size = (
            statistics.median(
                font_sizes
            )
            if font_sizes
            else 11.0
        )


        heading_candidates = 0

        bold_rows = 0

        large_font_rows = 0

        filled_rows = 0

        merged_rows = set()

        single_cell_rows = 0

        multi_cell_rows = 0

        first_meaningful_row = None

        last_meaningful_row = None


        # Identify merged rows.
        for merged_range in (
            worksheet.merged_cells.ranges
        ):

            for row_number in range(
                merged_range.min_row,
                merged_range.max_row + 1,
            ):

                merged_rows.add(
                    row_number
                )


        for row_number in sorted(
            staged_source_rows
        ):

            nonempty = []

            row_bold = False

            row_large = False

            row_filled = False


            for cell in worksheet[
                row_number
            ]:

                if cell.value is None:
                    continue


                nonempty.append(
                    cell
                )


                if cell.font.bold:

                    row_bold = True


                if (
                    cell.font.size
                    and float(
                        cell.font.size
                    )
                    > median_font_size
                ):

                    row_large = True


                if (
                    cell.fill
                    and cell.fill.fill_type
                ):

                    row_filled = True


            if not nonempty:
                continue


            if first_meaningful_row is None:

                first_meaningful_row = (
                    row_number
                )


            last_meaningful_row = (
                row_number
            )


            if len(nonempty) == 1:

                single_cell_rows += 1

            else:

                multi_cell_rows += 1


            if row_bold:

                bold_rows += 1


            if row_large:

                large_font_rows += 1


            if row_filled:

                filled_rows += 1


            # Structural heading candidate only.
            #
            # We deliberately do NOT inspect or print
            # actual cell text.

            if (
                len(nonempty) == 1
                and (
                    row_bold
                    or row_large
                    or row_number
                    in merged_rows
                )
            ):

                heading_candidates += 1


        style_profiles[
            sheet_name
        ] = {
            "median_font_size": (
                median_font_size
            ),
            "heading_candidates": (
                heading_candidates
            ),
            "bold_rows": bold_rows,
            "large_font_rows": (
                large_font_rows
            ),
            "filled_rows": (
                filled_rows
            ),
            "merged_rows": len(
                staged_source_rows
                & merged_rows
            ),
            "single_cell_rows": (
                single_cell_rows
            ),
            "multi_cell_rows": (
                multi_cell_rows
            ),
            "first_meaningful_row": (
                first_meaningful_row
            ),
            "last_meaningful_row": (
                last_meaningful_row
            ),
        }


finally:

    workbook.close()


# ============================================================
# SPECIALIZED STRUCTURE AUDITS
# ============================================================

special = {}


# ------------------------------------------------------------
# BENEFITS
# ------------------------------------------------------------

benefit_rows = [
    row
    for row in nonstandard_rows
    if row.sheet_name == "BENEFITS"
]


benefit_two_cell_rows = sum(
    1
    for row in benefit_rows
    if len(cells(row)) == 2
)


special["BENEFITS"] = {
    "rows": len(
        benefit_rows
    ),
    "two_cell_rows": (
        benefit_two_cell_rows
    ),
    "reference_shape_ready": (
        benefit_two_cell_rows
        >= (
            len(benefit_rows) - 1
        )
    ),
}


# ------------------------------------------------------------
# AMOUNT DEDUCTIONS
# ------------------------------------------------------------

amount_rows = [
    row
    for row in nonstandard_rows
    if row.sheet_name
    == "AMOUNT DEDUCTIONS"
]


commercial_columns = {
    "A",
    "B",
    "C",
    "D",
    "E",
}

standards_columns = {
    "G",
    "H",
    "I",
    "J",
    "K",
}


commercial_rows = 0

standards_rows = 0

mixed_rows = 0


for row in amount_rows:

    present = set(
        cells(row).keys()
    )

    has_commercial = bool(
        present
        & commercial_columns
    )

    has_standards = bool(
        present
        & standards_columns
    )


    if has_commercial:

        commercial_rows += 1


    if has_standards:

        standards_rows += 1


    if (
        has_commercial
        and has_standards
    ):

        mixed_rows += 1


special[
    "AMOUNT DEDUCTIONS"
] = {
    "rows": len(
        amount_rows
    ),
    "commercial_side_rows": (
        commercial_rows
    ),
    "standards_side_rows": (
        standards_rows
    ),
    "mixed_rows": (
        mixed_rows
    ),
}


# ------------------------------------------------------------
# LOAN MATRIX
# ------------------------------------------------------------

loan_rows = [
    row
    for row in nonstandard_rows
    if row.sheet_name == "LOAN"
]


loan_roles = Counter(
    meta(row).get(
        "row_role",
        "UNKNOWN",
    )
    for row in loan_rows
)


special["LOAN"] = {
    "rows": len(
        loan_rows
    ),
    "title_rows": (
        loan_roles[
            "TITLE"
        ]
    ),
    "header_rows": (
        loan_roles[
            "HEADER"
        ]
    ),
    "data_rows": (
        loan_roles[
            "DATA"
        ]
    ),
}


# ------------------------------------------------------------
# KNOWLEDGE
# ------------------------------------------------------------

knowledge_sheets = [
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
]


knowledge_summary = {}


for sheet_name in (
    knowledge_sheets
):

    profile = style_profiles[
        sheet_name
    ]

    staged_count = sheet_counts[
        sheet_name
    ]


    knowledge_summary[
        sheet_name
    ] = {
        "rows": staged_count,
        "heading_candidates": (
            profile[
                "heading_candidates"
            ]
        ),
        "single_cell_rows": (
            profile[
                "single_cell_rows"
            ]
        ),
        "multi_cell_rows": (
            profile[
                "multi_cell_rows"
            ]
        ),
        "contiguous_blocks": len(
            sheet_profiles[
                sheet_name
            ][
                "contiguous_blocks"
            ]
        ),
    }


special[
    "KNOWLEDGE"
] = knowledge_summary


# ------------------------------------------------------------
# ONBOARDING MAIL
# ------------------------------------------------------------

onboarding = sheet_profiles[
    "ONBOARDING_MAIL"
]


special[
    "ONBOARDING_MAIL"
] = {
    "rows": (
        sheet_counts[
            "ONBOARDING_MAIL"
        ]
    ),
    "contiguous_blocks": len(
        onboarding[
            "contiguous_blocks"
        ]
    ),
    "single_cell_rows": (
        style_profiles[
            "ONBOARDING_MAIL"
        ][
            "single_cell_rows"
        ]
    ),
    "heading_candidates": (
        style_profiles[
            "ONBOARDING_MAIL"
        ][
            "heading_candidates"
        ]
    ),
}


# ------------------------------------------------------------
# ROLLING GRANTS
# ------------------------------------------------------------

rolling = sheet_profiles[
    "Rolling_Grants"
]


rolling_counts = (
    rolling[
        "populated_cell_counts"
    ]
)


special[
    "Rolling_Grants"
] = {
    "rows": (
        sheet_counts[
            "Rolling_Grants"
        ]
    ),
    "rows_with_4_cells": (
        rolling_counts[4]
    ),
    "rows_with_5_cells": (
        rolling_counts[5]
    ),
    "heading_candidates": (
        style_profiles[
            "Rolling_Grants"
        ][
            "heading_candidates"
        ]
    ),
    "multi_cell_rows": (
        style_profiles[
            "Rolling_Grants"
        ][
            "multi_cell_rows"
        ]
    ),
}


# ============================================================
# DESTINATION MODEL CAPACITY
# ============================================================

expected_model_fields = {

    "ReferenceItem": {
        "dataset_name",
        "key",
        "value",
        "metadata",
        "visibility",
    },

    "ServiceCommercial": {
        "service",
        "visibility",
    },

    "ServiceContentSection": {
        "service",
        "title",
        "content",
        "order",
        "visibility",
    },

    "ComparisonMatrix": {
        "name",
        "source_sheet",
        "metadata",
    },

    "ComparisonEntry": {
        "matrix",
        "row_number",
        "column_name",
        "value_raw",
    },

    "CommunicationTemplate": {
        "template_key",
        "title",
        "subject",
        "body",
        "visibility",
    },
}


model_classes = {
    "ReferenceItem":
        ReferenceItem,

    "ServiceCommercial":
        ServiceCommercial,

    "ServiceContentSection":
        ServiceContentSection,

    "ComparisonMatrix":
        ComparisonMatrix,

    "ComparisonEntry":
        ComparisonEntry,

    "CommunicationTemplate":
        CommunicationTemplate,
}


model_capacity = {}


for model_name, expected_fields in (
    expected_model_fields.items()
):

    model = model_classes[
        model_name
    ]


    actual_fields = {
        field.name
        for field in (
            model._meta.get_fields()
        )
    }


    missing = sorted(
        expected_fields
        - actual_fields
    )


    model_capacity[
        model_name
    ] = {
        "expected": len(
            expected_fields
        ),
        "present": (
            len(
                expected_fields
                & actual_fields
            )
        ),
        "missing": missing,
    }


# ============================================================
# DESTINATION SAFETY
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),
}


if destination_counts[
    "Service"
] != 1:

    raise SystemExit(
        "STOPPED SAFELY: "
        "Service count changed."
    )


for name in [
    "ImportChange",
    "ServiceClassification",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
]:

    if destination_counts[
        name
    ] != 0:

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{name} unexpectedly "
            "contains data."
        )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10e_nonstandard_architecture_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10E NON-STANDARD ARCHITECTURE AUDIT"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    "Approved workbook SHA-256 verified: YES"
)

lines.append(
    f"Import Batch ID: {batch.pk}"
)

lines.append(
    f"Non-standard staged rows inspected: "
    f"{len(nonstandard_rows)}"
)

lines.append(
    "Workbook opened for formatting metadata: YES"
)

lines.append(
    "Workbook saved or modified: NO"
)

lines.append(
    "Workbook cell values printed: NO"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. FAMILY COUNTS"
)
# ------------------------------------------------------------

for family, count in sorted(
    family_counts.items()
):

    lines.append(
        f"  {family}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. DESTINATION PLAN"
)
# ------------------------------------------------------------

for sheet_name, destination in (
    DESTINATION_PLAN.items()
):

    lines.append(
        f"  {sheet_name}: "
        f"{destination}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. SHEET STRUCTURE"
)
# ------------------------------------------------------------

for sheet_name in (
    EXPECTED_SHEET_COUNTS
):

    profile = sheet_profiles[
        sheet_name
    ]

    style = style_profiles[
        sheet_name
    ]


    roles = ", ".join(
        f"{key}={value}"
        for key, value
        in sorted(
            profile[
                "role_counts"
            ].items()
        )
    )


    cell_shapes = ", ".join(
        f"{cell_count}-cell={count}"
        for cell_count, count
        in sorted(
            profile[
                "populated_cell_counts"
            ].items()
        )
    )


    columns = ", ".join(
        f"{column}={count}"
        for column, count
        in sorted(
            profile[
                "column_presence"
            ].items()
        )
    )


    lines.append(
        f"  {sheet_name}"
    )

    lines.append(
        f"    staged_rows: "
        f"{sheet_counts[sheet_name]}"
    )

    lines.append(
        f"    row_roles: "
        f"{roles or 'NONE'}"
    )

    lines.append(
        f"    row_shapes: "
        f"{cell_shapes or 'NONE'}"
    )

    lines.append(
        f"    column_presence: "
        f"{columns or 'NONE'}"
    )

    lines.append(
        f"    contiguous_blocks: "
        f"{len(profile['contiguous_blocks'])}"
    )

    lines.append(
        f"    hyperlink_cells: "
        f"{profile['hyperlink_cells']}"
    )

    lines.append(
        f"    formula_cells: "
        f"{profile['formulas']}"
    )

    lines.append(
        f"    staged_merged_resolutions: "
        f"{profile['merged_resolutions']}"
    )

    lines.append(
        f"    style_heading_candidates: "
        f"{style['heading_candidates']}"
    )

    lines.append(
        f"    bold_rows: "
        f"{style['bold_rows']}"
    )

    lines.append(
        f"    large_font_rows: "
        f"{style['large_font_rows']}"
    )

    lines.append(
        f"    filled_rows: "
        f"{style['filled_rows']}"
    )

    lines.append(
        f"    merged_meaningful_rows: "
        f"{style['merged_rows']}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. BENEFITS REFERENCE SHAPE"
)
# ------------------------------------------------------------

benefits = special[
    "BENEFITS"
]

lines.append(
    f"  staged_rows: "
    f"{benefits['rows']}"
)

lines.append(
    f"  two_cell_rows: "
    f"{benefits['two_cell_rows']}"
)

lines.append(
    "  key/value reference structure "
    "compatible: "
    + (
        "YES"
        if benefits[
            "reference_shape_ready"
        ]
        else "REVIEW"
    )
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. AMOUNT DEDUCTIONS SPLIT"
)
# ------------------------------------------------------------

amount = special[
    "AMOUNT DEDUCTIONS"
]

lines.append(
    f"  staged_rows: "
    f"{amount['rows']}"
)

lines.append(
    f"  rows touching A-E "
    f"(commercial side): "
    f"{amount['commercial_side_rows']}"
)

lines.append(
    f"  rows touching G-K "
    f"(standards/reference side): "
    f"{amount['standards_side_rows']}"
)

lines.append(
    f"  rows touching both logical sides: "
    f"{amount['mixed_rows']}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. LOAN COMPARISON MATRIX"
)
# ------------------------------------------------------------

loan = special[
    "LOAN"
]

lines.append(
    f"  staged_rows: "
    f"{loan['rows']}"
)

lines.append(
    f"  title_rows: "
    f"{loan['title_rows']}"
)

lines.append(
    f"  header_rows: "
    f"{loan['header_rows']}"
)

lines.append(
    f"  data_rows: "
    f"{loan['data_rows']}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. KNOWLEDGE SHEET STRUCTURE"
)
# ------------------------------------------------------------

for sheet_name, data in (
    special[
        "KNOWLEDGE"
    ].items()
):

    lines.append(
        f"  {sheet_name}: "
        f"rows={data['rows']} | "
        f"heading_candidates="
        f"{data['heading_candidates']} | "
        f"single_cell="
        f"{data['single_cell_rows']} | "
        f"multi_cell="
        f"{data['multi_cell_rows']} | "
        f"blocks="
        f"{data['contiguous_blocks']}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. ONBOARDING MAIL STRUCTURE"
)
# ------------------------------------------------------------

mail = special[
    "ONBOARDING_MAIL"
]

lines.append(
    f"  staged_rows: "
    f"{mail['rows']}"
)

lines.append(
    f"  contiguous_blocks: "
    f"{mail['contiguous_blocks']}"
)

lines.append(
    f"  single_cell_rows: "
    f"{mail['single_cell_rows']}"
)

lines.append(
    f"  heading_candidates: "
    f"{mail['heading_candidates']}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "9. ROLLING GRANTS STRUCTURE"
)
# ------------------------------------------------------------

rolling_data = special[
    "Rolling_Grants"
]

lines.append(
    f"  staged_rows: "
    f"{rolling_data['rows']}"
)

lines.append(
    f"  4-cell rows: "
    f"{rolling_data['rows_with_4_cells']}"
)

lines.append(
    f"  5-cell rows: "
    f"{rolling_data['rows_with_5_cells']}"
)

lines.append(
    f"  multi_cell_rows: "
    f"{rolling_data['multi_cell_rows']}"
)

lines.append(
    f"  heading_candidates: "
    f"{rolling_data['heading_candidates']}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "10. DESTINATION MODEL CAPACITY"
)
# ------------------------------------------------------------

for model_name, data in (
    model_capacity.items()
):

    lines.append(
        f"  {model_name}: "
        f"expected_fields="
        f"{data['expected']} | "
        f"present="
        f"{data['present']} | "
        f"missing="
        + (
            ", ".join(
                data[
                    "missing"
                ]
            )
            or "NONE"
        )
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "11. LIVE DESTINATION SAFETY"
)
# ------------------------------------------------------------

for key, value in (
    destination_counts.items()
):

    lines.append(
        f"  {key}: {value}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "12. WRITE SAFETY"
)
# ------------------------------------------------------------

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  ReferenceItem records created: 0"
)

lines.append(
    "  ServiceCommercial records created: 0"
)

lines.append(
    "  ServiceContentSection records created: 0"
)

lines.append(
    "  ComparisonMatrix records created: 0"
)

lines.append(
    "  ComparisonEntry records created: 0"
)

lines.append(
    "  CommunicationTemplate records created: 0"
)

lines.append(
    "  Workbook modified: NO"
)

lines.append(
    "  Workbook saved: NO"
)

lines.append(
    "  Confidential source values printed: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10E AUDIT COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
