(function () {
    "use strict";

    const drawer = document.getElementById("bde-quick-drawer");
    const overlay = document.getElementById("bde-quick-overlay");
    const drawerContent = document.getElementById("bde-quick-drawer-content");
    const closeButton = document.getElementById("bde-quick-close");

    function escapeHtml(value) {
        return String(value || "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    function safeUrl(value) {
        try {
            const url = new URL(value, window.location.origin);

            if (
                url.protocol === "http:"
                || url.protocol === "https:"
            ) {
                return url.href;
            }
        }
        catch (error) {
            return "";
        }

        return "";
    }

    function paragraph(value) {
        const text = String(value || "").trim();

        if (!text) {
            return '<p class="bde-not-recorded">Not available in Toolkit.</p>';
        }

        return "<p>" + escapeHtml(text) + "</p>";
    }

    function sourceLinks(items) {
        if (!Array.isArray(items) || !items.length) {
            return '<p class="bde-not-recorded">No external scheme link is recorded.</p>';
        }

        return `
            <div class="bde-quick-links">
                ${items.map(function (item) {
                    const href = safeUrl(item.url);

                    if (!href) {
                        return "";
                    }

                    return `
                        <a href="${escapeHtml(href)}"
                           target="_blank"
                           rel="noopener noreferrer">
                            <span>${escapeHtml(item.label || item.name || "External Link")}</span>
                            <b>↗</b>
                        </a>
                    `;
                }).join("")}
            </div>
        `;
    }

    function serviceMarkup(data) {
        const primary = safeUrl(data.primary_url);
        const detail = safeUrl(data.detail_url);

        return `
            <div class="bde-preview-kicker">QUICK DETAILS</div>
            <div class="bde-preview-code">${escapeHtml(data.service_id)}</div>
            <h2 class="bde-quick-title">${escapeHtml(data.title)}</h2>

            <div class="bde-preview-tags">
                <span>${escapeHtml(data.kind)}</span>
                <span>${escapeHtml(data.category)}</span>
            </div>

            <div class="bde-preview-fact-grid">
                <div>
                    <span>Deadline</span>
                    <strong>${escapeHtml(data.deadline || "Not recorded")}</strong>
                </div>
                <div>
                    <span>Pitch status</span>
                    <strong>${escapeHtml(data.pitch_state || "—")}</strong>
                </div>
            </div>

            ${data.summary ? `
                <div class="bde-quick-block">
                    <span>WHAT IT DOES</span>
                    <div class="bde-quick-summary">${escapeHtml(data.summary)}</div>
                </div>
            ` : ""}

            <div class="bde-quick-block">
                <span>ELIGIBILITY</span>
                ${paragraph(data.eligibility || data.applicable_for)}
            </div>

            <div class="bde-quick-block">
                <span>BENEFITS</span>
                ${paragraph(data.benefits)}
            </div>

            ${data.funding_organisation ? `
                <div class="bde-quick-block">
                    <span>RUN BY</span>
                    <p>${escapeHtml(data.funding_organisation)}</p>
                </div>
            ` : ""}

            <div class="bde-quick-block">
                <span>SCHEME LINKS</span>
                ${sourceLinks(data.sources)}
            </div>

            <div class="bde-quick-footer">
                ${primary ? `
                    <a href="${escapeHtml(primary)}"
                       target="_blank"
                       rel="noopener noreferrer"
                       class="bde-external-button">
                        Open Scheme ↗
                    </a>
                ` : ""}

                ${detail ? `
                    <a href="${escapeHtml(detail)}"
                       class="primary-button">
                        Full Details
                    </a>
                ` : ""}
            </div>
        `;
    }

    async function loadService(serviceId) {
        const response = await fetch(
            "/toolkit/library/quick/"
            + encodeURIComponent(serviceId)
            + "/",
            {
                credentials: "same-origin",
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                }
            }
        );

        if (!response.ok) {
            throw new Error("Quick view request failed");
        }

        return response.json();
    }

    function openDrawer() {
        if (!drawer || !overlay) {
            return;
        }

        drawer.hidden = false;
        overlay.hidden = false;
        document.body.style.overflow = "hidden";
    }

    function closeDrawer() {
        if (!drawer || !overlay) {
            return;
        }

        drawer.hidden = true;
        overlay.hidden = true;
        document.body.style.overflow = "";
    }

    async function showInDrawer(serviceId) {
        if (!drawerContent) {
            return;
        }

        openDrawer();

        drawerContent.innerHTML =
            '<div class="bde-quick-loading">Loading service…</div>';

        try {
            const data = await loadService(serviceId);
            drawerContent.innerHTML = serviceMarkup(data);
        }
        catch (error) {
            drawerContent.innerHTML = `
                <div class="bde-empty-state compact">
                    <h3>Could not load this service</h3>
                    <p>Please open the full service page and try again.</p>
                </div>
            `;
        }
    }

    async function showInLibrary(serviceId, button) {
        const target = document.getElementById("bde-library-preview");

        if (!target) {
            return;
        }

        document
            .querySelectorAll(".bde-library-row.active")
            .forEach(function (item) {
                item.classList.remove("active");
            });

        if (button) {
            button.classList.add("active");
        }

        target.innerHTML =
            '<div class="bde-quick-loading">Loading service…</div>';

        try {
            const data = await loadService(serviceId);
            target.innerHTML = serviceMarkup(data);
        }
        catch (error) {
            target.innerHTML = `
                <div class="bde-empty-state compact">
                    <h3>Could not load service details</h3>
                    <p>Use the full details page instead.</p>
                </div>
            `;
        }
    }

    document.addEventListener("click", function (event) {
        const trigger = event.target.closest("[data-service-quick]");

        if (!trigger) {
            return;
        }

        event.preventDefault();

        const serviceId = trigger.dataset.serviceQuick;

        if (!serviceId) {
            return;
        }

        if (trigger.dataset.quickMode === "library") {
            showInLibrary(serviceId, trigger);
            return;
        }

        showInDrawer(serviceId);
    });

    if (closeButton) {
        closeButton.addEventListener("click", closeDrawer);
    }

    if (overlay) {
        overlay.addEventListener("click", closeDrawer);
    }

    document.addEventListener("keydown", function (event) {
        if (
            event.key === "Escape"
            && drawer
            && !drawer.hidden
        ) {
            closeDrawer();
        }

        if (
            (event.ctrlKey || event.metaKey)
            && event.key.toLowerCase() === "k"
        ) {
            event.preventDefault();

            const input =
                document.getElementById("toolkit-search-input")
                || document.getElementById("bde-global-search-input")
                || document.querySelector('.global-search input[type="search"]');

            if (input) {
                input.focus();
                input.select();
            }
        }
    });

    document.addEventListener("submit", async function (event) {
        const form = event.target.closest(".bde-ajax-save");

        if (!form) {
            return;
        }

        event.preventDefault();

        const button = form.querySelector("button[type='submit']");

        if (!button || button.disabled) {
            return;
        }

        const originalText = button.textContent;
        button.disabled = true;

        try {
            const response = await fetch(
                form.action,
                {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: new FormData(form)
                }
            );

            if (!response.ok) {
                throw new Error("Save request failed");
            }

            const data = await response.json();

            if (button.classList.contains("bde-save-icon")) {
                button.textContent = data.saved ? "★" : "☆";
            }
            else {
                button.textContent = data.saved ? "★ Saved" : "☆ Save";
            }

            button.classList.toggle("saved", Boolean(data.saved));
        }
        catch (error) {
            button.textContent = originalText;
        }
        finally {
            button.disabled = false;
        }
    });
})();
