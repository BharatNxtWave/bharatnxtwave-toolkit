import csv
import hashlib
import io
import zipfile
from pathlib import Path, PurePosixPath

from django.contrib.auth.decorators import user_passes_test
from django.db.models import Q, Sum
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from openpyxl import load_workbook

from accounts.activity import log_activity

from .import_forms import ToolkitImportUploadForm
from .models import ImportBatch
from .intelligence.ingestion import analyse_file
from .intelligence.staging import stage_analysis


MAX_PREVIEW_ROWS = 8
MAX_PREVIEW_COLUMNS = 30

MAX_XLSX_UNCOMPRESSED_BYTES = (
    250 * 1024 * 1024
)

MAX_XLSX_COMPRESSION_RATIO = 200


def can_import_toolkit(user):
    return (
        user.is_authenticated
        and (
            user.is_superuser
            or user.role in {
                "SUPER_ADMIN",
                "DATA_ADMIN",
            }
        )
    )


def normalize_value(value):
    if value is None:
        return ""

    return str(value).strip()


# =========================================================
# FILE FINGERPRINT
# =========================================================

def calculate_sha256(uploaded_file):
    digest = hashlib.sha256()

    uploaded_file.seek(0)

    for chunk in uploaded_file.chunks():
        digest.update(chunk)

    uploaded_file.seek(0)

    return digest.hexdigest()


# =========================================================
# CLIENT-REPORTED FILE MODIFICATION DATE
#
# This comes from browser File.lastModified.
# It is useful operational metadata but is not treated as
# a cryptographically trusted timestamp.
# =========================================================

def parse_source_modified_at(value):
    if not value:
        return None

    parsed = parse_datetime(value)

    if parsed is None:
        return None

    if timezone.is_naive(parsed):
        parsed = timezone.make_aware(parsed)

    return parsed


# =========================================================
# XLSX SECURITY VALIDATION
# =========================================================

def validate_xlsx_structure(uploaded_file):
    uploaded_file.seek(0)

    if not zipfile.is_zipfile(uploaded_file):
        uploaded_file.seek(0)

        raise ValueError(
            "The Excel file is not a valid XLSX archive."
        )

    uploaded_file.seek(0)

    with zipfile.ZipFile(uploaded_file) as archive:
        infos = archive.infolist()

        names = {
            info.filename
            for info in infos
        }

        required_files = {
            "[Content_Types].xml",
            "xl/workbook.xml",
        }

        if not required_files.issubset(names):
            raise ValueError(
                "The file does not contain a valid XLSX workbook."
            )

        # XLSX only. Macro-enabled content is not accepted.
        if any(
            name.lower().endswith(
                "vbaproject.bin"
            )
            for name in names
        ):
            raise ValueError(
                "Macro-enabled Excel files are not permitted."
            )

        total_compressed = 0
        total_uncompressed = 0

        for info in infos:
            path = PurePosixPath(
                info.filename
            )

            if (
                info.filename.startswith("/")
                or ".." in path.parts
            ):
                raise ValueError(
                    "Unsafe XLSX archive structure detected."
                )

            if info.flag_bits & 0x1:
                raise ValueError(
                    "Encrypted XLSX archives are not supported."
                )

            total_compressed += (
                info.compress_size
            )

            total_uncompressed += (
                info.file_size
            )

        if (
            total_uncompressed
            > MAX_XLSX_UNCOMPRESSED_BYTES
        ):
            raise ValueError(
                "The expanded Excel workbook is too large."
            )

        if (
            total_compressed > 0
            and (
                total_uncompressed
                / total_compressed
            )
            > MAX_XLSX_COMPRESSION_RATIO
        ):
            raise ValueError(
                "Unsafe Excel compression ratio detected."
            )

    uploaded_file.seek(0)


# =========================================================
# CSV SECURITY VALIDATION + PREVIEW
# =========================================================

def preview_csv(uploaded_file):
    uploaded_file.seek(0)

    raw = uploaded_file.read()

    uploaded_file.seek(0)

    if b"\x00" in raw:
        raise ValueError(
            "Binary content detected in CSV file."
        )

    text = None

    for encoding in (
        "utf-8-sig",
        "utf-8",
        "cp1252",
    ):
        try:
            text = raw.decode(encoding)
            break

        except UnicodeDecodeError:
            continue

    if text is None:
        raise ValueError(
            "CSV encoding could not be read."
        )

    csv.field_size_limit(
        1_000_000
    )

    stream = io.StringIO(text)

    reader = csv.reader(stream)

    first_row = next(
        reader,
        None
    )

    if first_row is None:
        return {
            "sheets": [
                {
                    "name": "CSV",
                    "headers": [],
                    "preview_rows": [],
                    "total_rows": 0,
                    "total_columns": 0,
                }
            ]
        }

    headers = [
        normalize_value(value)
        for value
        in first_row[
            :MAX_PREVIEW_COLUMNS
        ]
    ]

    preview_rows = []

    total_rows = 0
    total_columns = len(first_row)

    for row in reader:
        total_rows += 1

        total_columns = max(
            total_columns,
            len(row)
        )

        if (
            len(preview_rows)
            < MAX_PREVIEW_ROWS
        ):
            preview_rows.append(
                [
                    normalize_value(value)
                    for value
                    in row[
                        :MAX_PREVIEW_COLUMNS
                    ]
                ]
            )

    return {
        "sheets": [
            {
                "name": "CSV",
                "headers": headers,
                "preview_rows": preview_rows,
                "total_rows": total_rows,
                "total_columns": total_columns,
            }
        ]
    }


# =========================================================
# XLSX PREVIEW
# =========================================================

def preview_excel(uploaded_file):
    validate_xlsx_structure(
        uploaded_file
    )

    uploaded_file.seek(0)

    workbook = load_workbook(
        uploaded_file,
        read_only=True,
        data_only=True,
        keep_links=False,
    )

    sheets = []

    try:
        for worksheet in workbook.worksheets:
            rows = worksheet.iter_rows(
                values_only=True
            )

            first_row = next(
                rows,
                None
            )

            if first_row is None:
                sheets.append(
                    {
                        "name": worksheet.title,
                        "headers": [],
                        "preview_rows": [],
                        "total_rows": 0,
                        "total_columns": 0,
                    }
                )

                continue

            headers = [
                normalize_value(value)
                for value
                in first_row[
                    :MAX_PREVIEW_COLUMNS
                ]
            ]

            preview_rows = []

            total_data_rows = 0

            for row in rows:
                total_data_rows += 1

                if (
                    len(preview_rows)
                    < MAX_PREVIEW_ROWS
                ):
                    preview_rows.append(
                        [
                            normalize_value(value)
                            for value
                            in row[
                                :MAX_PREVIEW_COLUMNS
                            ]
                        ]
                    )

            sheets.append(
                {
                    "name": worksheet.title,
                    "headers": headers,
                    "preview_rows": preview_rows,
                    "total_rows": total_data_rows,
                    "total_columns": (
                        worksheet.max_column
                        or 0
                    ),
                }
            )

    finally:
        workbook.close()

        uploaded_file.seek(0)

    return {
        "sheets": sheets
    }




def _extraction_review_stats(batch):

    if batch is None:
        return None

    rows = batch.rows.all()

    candidates = rows.exclude(
        candidate_action="UNDECIDED"
    )

    return {
        "source_rows": rows.count(),

        "candidates": candidates.count(),

        "create": candidates.filter(
            candidate_action="CREATE"
        ).count(),

        "update": candidates.filter(
            candidate_action="UPDATE"
        ).count(),

        "merge_review": candidates.filter(
            candidate_action="MERGE_REVIEW"
        ).count(),

        "knowledge_rows": rows.filter(
            candidate_action="UNDECIDED"
        ).count(),
    }


# =========================================================
# IMPORT CENTER / SOURCE PREVIEW
# =========================================================

@user_passes_test(can_import_toolkit)
def import_center(request):
    preview = None
    import_error = None
    uploaded_name = None

    current_batch = None
    duplicate_batch = None
    analysis = None
    staging_result = None

    latest_review_batch = (
        ImportBatch.objects
        .filter(
            status__in=[
                "PREVIEWED",
                "VALIDATED",
            ],
            rows__isnull=False,
        )
        .distinct()
        .order_by("-created_at")
        .first()
    )

    latest_review_stats = (
        _extraction_review_stats(
            latest_review_batch
        )
    )

    if request.method == "POST":
        form = ToolkitImportUploadForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():
            uploaded_file = (
                form.cleaned_data["file"]
            )

            uploaded_name = (
                uploaded_file.name
            )

            extension = (
                Path(uploaded_file.name)
                .suffix
                .lower()
            )

            source_type = (
                "CSV"
                if extension == ".csv"
                else "XLSX"
            )

            try:
                file_sha256 = calculate_sha256(
                    uploaded_file
                )

                # Identical content, even if renamed.
                duplicate_batch = (
                    ImportBatch.objects
                    .filter(
                        file_sha256=file_sha256
                    )
                    .order_by(
                        "-created_at"
                    )
                    .first()
                )

                # Compare current version against the most
                # recent source with the same filename.
                previous_same_name = (
                    ImportBatch.objects
                    .filter(
                        source_type=source_type,
                        source_name=uploaded_name,
                    )
                    .order_by(
                        "-created_at"
                    )
                    .first()
                )

                if extension == ".csv":
                    preview = preview_csv(
                        uploaded_file
                    )

                elif extension == ".xlsx":
                    preview = preview_excel(
                        uploaded_file
                    )

                else:
                    raise ValueError(
                        "Unsupported file format."
                    )

                analysis = analyse_file(
                    uploaded_file,
                    uploaded_name,
                )

                sheets = preview.get(
                    "sheets",
                    []
                )

                total_rows = sum(
                    sheet.get(
                        "total_rows",
                        0
                    )
                    for sheet in sheets
                )

                source_modified_at = (
                    parse_source_modified_at(
                        request.POST.get(
                            "source_modified_at"
                        )
                    )
                )

                metadata = {
                    "operation": "preview",
                    "preview_only": True,

                    "sheet_names": [
                        sheet.get(
                            "name",
                            ""
                        )
                        for sheet in sheets
                    ],

                    "sheets": [
                        {
                            "name": sheet.get(
                                "name",
                                ""
                            ),
                            "rows": sheet.get(
                                "total_rows",
                                0
                            ),
                            "columns": sheet.get(
                                "total_columns",
                                0
                            ),
                        }
                        for sheet in sheets
                    ],

                    "duplicate_detected": (
                        duplicate_batch
                        is not None
                    ),

                    "duplicate_of_id": (
                        duplicate_batch.pk
                        if duplicate_batch
                        else None
                    ),

                    "previous_same_name_id": (
                        previous_same_name.pk
                        if previous_same_name
                        else None
                    ),

                    "source_changed_since_previous": (
                        bool(
                            previous_same_name
                            and (
                                previous_same_name.file_sha256
                                != file_sha256
                            )
                        )
                    ),
                }

                current_batch = (
                    ImportBatch.objects.create(
                        source_type=source_type,

                        source_name=(
                            uploaded_name
                        ),

                        source_modified_at=(
                            source_modified_at
                        ),

                        file_sha256=file_sha256,

                        sheet_count=len(
                            sheets
                        ),

                        row_count=total_rows,

                        status="PREVIEWED",

                        imported_by=(
                            request.user
                        ),

                        metadata=metadata,
                    )
                )

                staging_result = stage_analysis(
                    current_batch,
                    analysis,
                    uploaded_file,
                    uploaded_name,
                )

                meaningful_rows = (
                    staging_result.get(
                        "source_rows"
                    )
                    if staging_result
                    else None
                )

                if meaningful_rows is not None:

                    metadata = dict(
                        current_batch.metadata
                        or {}
                    )

                    if (
                        current_batch.row_count
                        != meaningful_rows
                    ):
                        metadata[
                            "preview_dimension_row_count"
                        ] = current_batch.row_count

                    metadata[
                        "meaningful_source_row_count"
                    ] = meaningful_rows

                    current_batch.row_count = (
                        meaningful_rows
                    )

                    current_batch.metadata = (
                        metadata
                    )

                    current_batch.save(
                        update_fields=[
                            "row_count",
                            "metadata",
                        ]
                    )

                latest_review_batch = (
                    current_batch
                )

                latest_review_stats = (
                    _extraction_review_stats(
                        current_batch
                    )
                )

                # Do NOT put confidential filenames,
                # row contents or cell contents into the
                # generic ActivityLog.
                log_activity(
                    request,
                    "IMPORT",
                    "Previewed toolkit source file.",
                    target_type=(
                        "import_batch"
                    ),
                    target_id=(
                        current_batch.pk
                    ),
                    metadata={
                        "operation": (
                            "preview"
                        ),
                        "batch_id": (
                            current_batch.pk
                        ),
                        "source_type": (
                            source_type
                        ),
                        "sheet_count": (
                            len(sheets)
                        ),
                        "row_count": (
                            total_rows
                        ),
                        "duplicate_detected": (
                            duplicate_batch
                            is not None
                        ),
                    },
                )

            except Exception as exc:
                import_error = str(
                    exc
                ) or (
                    "The source file could "
                    "not be read."
                )

    else:
        form = ToolkitImportUploadForm()

    return render(
        request,
        "toolkit/admin/import_center.html",
        {
            "form": form,
            "preview": preview,
            "import_error": import_error,
            "uploaded_name": uploaded_name,
            "current_batch": current_batch,
            "duplicate_batch": duplicate_batch,
            "analysis": analysis,
            "staging_result": staging_result,
            "latest_review_batch": latest_review_batch,
            "latest_review_stats": latest_review_stats,
        }
    )


# =========================================================
# SOURCE / IMPORT HISTORY
# =========================================================

@user_passes_test(can_import_toolkit)
def import_history(request):
    source_filter = request.GET.get(
        "source",
        ""
    ).strip()

    status_filter = request.GET.get(
        "status",
        ""
    ).strip()

    query = request.GET.get(
        "q",
        ""
    ).strip()

    batches = (
        ImportBatch.objects
        .select_related(
            "imported_by"
        )
        .all()
    )

    valid_sources = {
        value
        for value, label
        in ImportBatch.SOURCE_CHOICES
    }

    valid_statuses = {
        value
        for value, label
        in ImportBatch.STATUS_CHOICES
    }

    if source_filter in valid_sources:
        batches = batches.filter(
            source_type=source_filter
        )

    if status_filter in valid_statuses:
        batches = batches.filter(
            status=status_filter
        )

    if query:
        batches = batches.filter(
            Q(
                source_name__icontains=query
            )
            | Q(
                file_sha256__icontains=query
            )
        )

    all_batches = ImportBatch.objects.all()

    total_rows_seen = (
        all_batches.aggregate(
            total=Sum("row_count")
        )["total"]
        or 0
    )

    duplicate_count = sum(
        1
        for metadata
        in all_batches.values_list(
            "metadata",
            flat=True
        )
        if (
            isinstance(
                metadata,
                dict
            )
            and metadata.get(
                "duplicate_detected"
            )
        )
    )

    context = {
        "batches": batches[:250],

        "source_filter": source_filter,
        "status_filter": status_filter,
        "query": query,

        "source_choices": (
            ImportBatch.SOURCE_CHOICES
        ),

        "status_choices": (
            ImportBatch.STATUS_CHOICES
        ),

        "total_batches": (
            all_batches.count()
        ),

        "total_rows_seen": (
            total_rows_seen
        ),

        "duplicate_count": (
            duplicate_count
        ),
    }

    return render(
        request,
        "toolkit/admin/import_history.html",
        context
    )


# =========================================================
# SOURCE HISTORY DETAIL
# =========================================================

@user_passes_test(can_import_toolkit)
def import_history_detail(
    request,
    batch_id
):
    batch = get_object_or_404(
        ImportBatch.objects
        .select_related(
            "imported_by"
        ),
        pk=batch_id
    )

    duplicate_of = None
    previous_same_name = None

    if isinstance(
        batch.metadata,
        dict
    ):
        duplicate_id = (
            batch.metadata.get(
                "duplicate_of_id"
            )
        )

        previous_id = (
            batch.metadata.get(
                "previous_same_name_id"
            )
        )

        if duplicate_id:
            duplicate_of = (
                ImportBatch.objects
                .filter(
                    pk=duplicate_id
                )
                .first()
            )

        if previous_id:
            previous_same_name = (
                ImportBatch.objects
                .filter(
                    pk=previous_id
                )
                .first()
            )

    return render(
        request,
        "toolkit/admin/import_history_detail.html",
        {
            "batch": batch,
            "duplicate_of": duplicate_of,
            "previous_same_name": (
                previous_same_name
            ),
        }
    )


# ============================================================
# SOURCE HISTORY RECORD MANAGEMENT
# ============================================================

from django.contrib import messages as _source_messages
from django.contrib.auth.decorators import login_required as _source_login_required
from django.http import HttpResponseForbidden as _SourceHttpResponseForbidden
from django.shortcuts import get_object_or_404 as _source_get_object_or_404
from django.shortcuts import redirect as _source_redirect
from django.views.decorators.http import require_POST as _source_require_POST


def _can_delete_source_record(user):

    if not user.is_authenticated:
        return False

    if user.is_superuser:
        return True

    return getattr(
        user,
        "role",
        ""
    ) in {
        "SUPER_ADMIN",
        "DATA_ADMIN",
    }


@_source_login_required
@_source_require_POST
def import_source_delete(
    request,
    batch_id,
):

    if not _can_delete_source_record(
        request.user
    ):

        return _SourceHttpResponseForbidden(
            "You do not have permission to delete source records."
        )


    batch = _source_get_object_or_404(
        ImportBatch,
        pk=batch_id,
    )


    # --------------------------------------------------------
    # Do not allow deletion of a source that has actually
    # been imported into the live Toolkit.
    # --------------------------------------------------------

    if str(
        batch.status
    ).upper() == "IMPORTED":

        _source_messages.error(
            request,
            (
                "This source has already been imported into the "
                "Toolkit and cannot be deleted from Source History."
            ),
        )

        return _source_redirect(
            f"/admin-center/import/history/{batch.pk}/"
        )


    event_id = batch.pk


    batch.delete()


    _source_messages.success(
        request,
        (
            f"Source Event #{event_id} was deleted "
            "from Source History."
        ),
    )


    return _source_redirect(
        "/admin-center/import/history/"
    )



# =========================================================
# INTELLIGENT EXTRACTION REVIEW
# =========================================================

@user_passes_test(can_import_toolkit)
def import_extraction_review(
    request,
    batch_id,
):

    batch = get_object_or_404(
        ImportBatch.objects,
        pk=batch_id,
    )

    all_rows = (
        batch.rows
        .select_related(
            "matched_service"
        )
        .order_by(
            "sheet_name",
            "source_row_number",
        )
    )

    candidates = (
        all_rows
        .exclude(
            candidate_action="UNDECIDED"
        )
    )

    stats = {
        "source_rows":
            all_rows.count(),

        "candidates":
            candidates.count(),

        "create":
            candidates.filter(
                candidate_action="CREATE"
            ).count(),

        "update":
            candidates.filter(
                candidate_action="UPDATE"
            ).count(),

        "merge_review":
            candidates.filter(
                candidate_action="MERGE_REVIEW"
            ).count(),

        "invalid":
            candidates.filter(
                candidate_action="INVALID"
            ).count(),

        "knowledge_rows":
            all_rows.filter(
                candidate_action="UNDECIDED"
            ).count(),
    }

    return render(
        request,
        "toolkit/admin/extraction_review.html",
        {
            "batch": batch,
            "rows": candidates,
            "stats": stats,
        },
    )
