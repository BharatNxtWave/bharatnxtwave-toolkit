import os
import re
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import django
django.setup()

from django.apps import apps
from django.conf import settings
from django.db import connection

from toolkit.importing.transformation import (
    build_core_transformation_plan,
    load_verified_context,
)

from toolkit.importing.supporting_transformation import (
    build_supporting_transformation_plan,
)


# ============================================================
# REPORT HELPERS
# ============================================================

checks = []


def add_check(name, passed, detail=""):
    checks.append(
        {
            "name": name,
            "passed": bool(passed),
            "detail": str(detail),
        }
    )


def model(name):
    return apps.get_model(
        "toolkit",
        name,
    )


def collect_row_ids(obj, found=None):
    if found is None:
        found = set()

    single_keys = {
        "source_import_row_id",
        "import_row_id",
        "source_row_id",
    }

    multiple_keys = {
        "source_row_ids",
        "import_row_ids",
        "source_import_row_ids",
    }

    if isinstance(obj, dict):

        for key, value in obj.items():

            if key in single_keys:

                if isinstance(value, int):
                    found.add(value)

            elif key in multiple_keys:

                if isinstance(
                    value,
                    (list, tuple, set),
                ):
                    for item in value:
                        if isinstance(item, int):
                            found.add(item)

            collect_row_ids(
                value,
                found,
            )

    elif isinstance(
        obj,
        (list, tuple, set),
    ):

        for item in obj:
            collect_row_ids(
                item,
                found,
            )

    return found


def collect_values_for_key(
    obj,
    wanted_key,
    results=None,
):
    if results is None:
        results = []

    if isinstance(obj, dict):

        for key, value in obj.items():

            if key == wanted_key:
                results.append(value)

            collect_values_for_key(
                value,
                wanted_key,
                results,
            )

    elif isinstance(
        obj,
        (list, tuple, set),
    ):

        for item in obj:
            collect_values_for_key(
                item,
                wanted_key,
                results,
            )

    return results


def collect_url_values(
    obj,
    results=None,
):
    if results is None:
        results = []

    if isinstance(obj, dict):

        for key, value in obj.items():

            lowered = str(key).lower()

            if (
                lowered == "url"
                or lowered.endswith("_url")
            ):
                if isinstance(value, str):
                    results.append(value)

            collect_url_values(
                value,
                results,
            )

    elif isinstance(
        obj,
        (list, tuple, set),
    ):

        for item in obj:
            collect_url_values(
                item,
                results,
            )

    return results


# ============================================================
# VERIFIED SOURCE CONTEXT
# ============================================================

try:

    contract, batch, staged_rows = (
        load_verified_context()
    )

    add_check(
        "SOURCE WORKBOOK VERIFICATION",
        True,
        "Verified context loaded successfully",
    )

except Exception as exc:

    add_check(
        "SOURCE WORKBOOK VERIFICATION",
        False,
        exc.__class__.__name__,
    )

    raise


staged_rows = list(
    staged_rows
)

staged_ids = {
    row.id
    for row in staged_rows
}


add_check(
    "IMPORT BATCH STATUS",
    batch.status == "PREVIEWED",
    f"status={batch.status}",
)


add_check(
    "STAGED ROW COUNT",
    len(staged_rows) == 478,
    f"rows={len(staged_rows)}",
)


sheet_counts = Counter(
    row.sheet_name
    for row in staged_rows
)

add_check(
    "SOURCE SHEET COUNT",
    len(sheet_counts) == 20,
    f"sheets={len(sheet_counts)}",
)


# ============================================================
# DATABASE HEALTH
# ============================================================

with connection.cursor() as cursor:

    cursor.execute(
        "PRAGMA integrity_check;"
    )

    integrity = cursor.fetchone()

    integrity_value = (
        integrity[0]
        if integrity
        else "NO RESULT"
    )


    cursor.execute(
        "PRAGMA foreign_key_check;"
    )

    fk_violations = (
        cursor.fetchall()
    )


add_check(
    "SQLITE INTEGRITY",
    integrity_value == "ok",
    f"result={integrity_value}",
)


add_check(
    "FOREIGN KEY INTEGRITY",
    len(fk_violations) == 0,
    f"violations={len(fk_violations)}",
)


# ============================================================
# CURRENT DATABASE STATE
# ============================================================

preimport_expected = {
    "Service": 1,
    "ImportRow": 478,
    "ImportChange": 0,
    "ServiceClassification": 0,
    "ServiceCommercial": 0,
    "ServiceSource": 0,
    "ServiceContentSection": 0,
    "ReferenceItem": 0,
    "ComparisonMatrix": 0,
    "ComparisonEntry": 0,
    "CommunicationTemplate": 0,
}


actual_counts = {}

for name in preimport_expected:

    actual_counts[name] = (
        model(name)
        .objects
        .count()
    )


db_state_ok = (
    actual_counts
    == preimport_expected
)


add_check(
    "PRE-IMPORT DATABASE STATE",
    db_state_ok,
    (
        "destination tables remain empty"
        if db_state_ok
        else "database differs from approved baseline"
    ),
)


# ============================================================
# BUILD CURRENT PLANS
# ============================================================

core = (
    build_core_transformation_plan()
)

supporting = (
    build_supporting_transformation_plan(
        core
    )
)


add_check(
    "CORE PLAN TYPE",
    isinstance(core, dict),
    f"type={type(core).__name__}",
)


add_check(
    "SUPPORTING PLAN TYPE",
    isinstance(supporting, dict),
    f"type={type(supporting).__name__}",
)


services = core.get(
    "services",
    {},
)

categories = core.get(
    "categories",
    [],
)

classifications = core.get(
    "classifications",
    [],
)

commercial = core.get(
    "commercial",
    [],
)


# ============================================================
# CORE COUNT CONTRACT
# ============================================================

add_check(
    "PLANNED SERVICES",
    len(services) == 162,
    f"count={len(services)}",
)


add_check(
    "PLANNED NEW CATEGORIES",
    len(categories) == 8,
    f"count={len(categories)}",
)


add_check(
    "PLANNED CLASSIFICATIONS",
    len(classifications) == 150,
    f"count={len(classifications)}",
)


add_check(
    "PLANNED COMMERCIAL RECORDS",
    len(commercial) == 161,
    f"count={len(commercial)}",
)


add_check(
    "CORE STAGED ROW COUNT",
    core.get("staged_row_count") == 478,
    f"value={core.get('staged_row_count')}",
)


validation = core.get(
    "validation",
    {},
)

validation_total = sum(
    value
    for value in validation.values()
    if isinstance(value, int)
)


add_check(
    "VALIDATION ACCOUNTING",
    validation_total == 478,
    f"total={validation_total}",
)


# ============================================================
# SERVICE STRUCTURE
# ============================================================

required_service_fields = {
    "identity",
    "service_id",
    "title",
    "slug",
    "domain_slug",
    "category_slug",
    "service_kind",
    "status",
    "priority",
    "source_family",
    "source_row_ids",
}


service_shape_errors = 0

service_ids = []
service_slugs = []
service_statuses = Counter()


for identity, item in services.items():

    if not isinstance(item, dict):
        service_shape_errors += 1
        continue

    if not required_service_fields.issubset(
        set(item.keys())
    ):
        service_shape_errors += 1

    service_ids.append(
        item.get("service_id")
    )

    service_slugs.append(
        item.get("slug")
    )

    service_statuses[
        item.get("status")
    ] += 1


add_check(
    "SERVICE PLAN SCHEMA",
    service_shape_errors == 0,
    f"errors={service_shape_errors}",
)


add_check(
    "SERVICE ID UNIQUENESS",
    (
        len(service_ids)
        == len(set(service_ids))
        == 162
    ),
    f"unique={len(set(service_ids))}",
)


add_check(
    "SERVICE SLUG UNIQUENESS",
    (
        len(service_slugs)
        == len(set(service_slugs))
        == 162
    ),
    f"unique={len(set(service_slugs))}",
)


non_draft = sum(
    count
    for status, count in service_statuses.items()
    if status != "DRAFT"
)


add_check(
    "SAFE INITIAL SERVICE STATUS",
    non_draft == 0,
    f"non_DRAFT={non_draft}",
)


# ============================================================
# LIVE COLLISION CHECK
# ============================================================

Service = model(
    "Service"
)

existing_service_ids = set(
    Service.objects.values_list(
        "service_id",
        flat=True,
    )
)

existing_service_slugs = set(
    Service.objects.values_list(
        "slug",
        flat=True,
    )
)


service_id_collisions = (
    existing_service_ids
    & set(service_ids)
)

service_slug_collisions = (
    existing_service_slugs
    & set(service_slugs)
)


add_check(
    "LIVE SERVICE ID COLLISIONS",
    len(service_id_collisions) == 0,
    f"collisions={len(service_id_collisions)}",
)


add_check(
    "LIVE SERVICE SLUG COLLISIONS",
    len(service_slug_collisions) == 0,
    f"collisions={len(service_slug_collisions)}",
)


# ============================================================
# DOMAIN / CATEGORY REFERENCES
# ============================================================

ServiceDomain = model(
    "ServiceDomain"
)

Category = model(
    "Category"
)


existing_domains = set(
    ServiceDomain.objects.values_list(
        "slug",
        flat=True,
    )
)

existing_categories = set(
    Category.objects.values_list(
        "slug",
        flat=True,
    )
)


planned_category_slugs = {
    item.get("slug")
    for item in categories
    if isinstance(item, dict)
}


planned_category_domains = {
    item.get("domain_slug")
    for item in categories
    if isinstance(item, dict)
}


add_check(
    "PLANNED CATEGORY SLUG UNIQUENESS",
    len(planned_category_slugs) == len(categories),
    f"unique={len(planned_category_slugs)}",
)


category_collisions = (
    existing_categories
    & planned_category_slugs
)


add_check(
    "NEW CATEGORY COLLISIONS",
    len(category_collisions) == 0,
    f"collisions={len(category_collisions)}",
)


unknown_category_domains = (
    planned_category_domains
    - existing_domains
)


add_check(
    "NEW CATEGORY DOMAIN REFERENCES",
    len(unknown_category_domains) == 0,
    f"unknown={len(unknown_category_domains)}",
)


available_categories = (
    existing_categories
    | planned_category_slugs
)


bad_service_domain_refs = 0
bad_service_category_refs = 0


for item in services.values():

    if item.get(
        "domain_slug"
    ) not in existing_domains:
        bad_service_domain_refs += 1

    if item.get(
        "category_slug"
    ) not in available_categories:
        bad_service_category_refs += 1


add_check(
    "SERVICE DOMAIN REFERENCES",
    bad_service_domain_refs == 0,
    f"bad={bad_service_domain_refs}",
)


add_check(
    "SERVICE CATEGORY REFERENCES",
    bad_service_category_refs == 0,
    f"bad={bad_service_category_refs}",
)


# ============================================================
# CLASSIFICATION REFERENTIAL SAFETY
# ============================================================

classification_service_errors = 0
classification_category_errors = 0
classification_row_errors = 0


for item in classifications:

    if item.get(
        "service_identity"
    ) not in services:

        classification_service_errors += 1


    if item.get(
        "category_slug"
    ) not in available_categories:

        classification_category_errors += 1


    row_id = item.get(
        "source_import_row_id"
    )

    if (
        row_id is not None
        and row_id not in staged_ids
    ):
        classification_row_errors += 1


add_check(
    "CLASSIFICATION SERVICE REFERENCES",
    classification_service_errors == 0,
    f"bad={classification_service_errors}",
)


add_check(
    "CLASSIFICATION CATEGORY REFERENCES",
    classification_category_errors == 0,
    f"bad={classification_category_errors}",
)


add_check(
    "CLASSIFICATION SOURCE LINEAGE",
    classification_row_errors == 0,
    f"bad={classification_row_errors}",
)


# ============================================================
# COMMERCIAL SAFETY
# ============================================================

commercial_service_errors = 0
commercial_row_errors = 0
commercial_visibility_errors = 0
commercial_numeric_values = 0


numeric_fields = (
    "minimum_charge",
    "government_fee",
    "vendor_cost",
    "bdm_deduction",
)


for item in commercial:

    if item.get(
        "service_identity"
    ) not in services:

        commercial_service_errors += 1


    row_id = item.get(
        "source_import_row_id"
    )

    if (
        row_id is not None
        and row_id not in staged_ids
    ):
        commercial_row_errors += 1


    if item.get(
        "visibility"
    ) != "ADMIN_ONLY":

        commercial_visibility_errors += 1


    for field_name in numeric_fields:

        if item.get(
            field_name
        ) is not None:

            commercial_numeric_values += 1


add_check(
    "COMMERCIAL SERVICE REFERENCES",
    commercial_service_errors == 0,
    f"bad={commercial_service_errors}",
)


add_check(
    "COMMERCIAL SOURCE LINEAGE",
    commercial_row_errors == 0,
    f"bad={commercial_row_errors}",
)


add_check(
    "COMMERCIAL ADMIN VISIBILITY",
    commercial_visibility_errors == 0,
    f"bad={commercial_visibility_errors}",
)


add_check(
    "COMMERCIAL NUMERIC AUTO-PARSING",
    commercial_numeric_values == 0,
    (
        "no automatic numeric conversions"
        if commercial_numeric_values == 0
        else f"numeric_values={commercial_numeric_values}"
    ),
)


# ============================================================
# SUPPORTING DATA PRESENCE
# ============================================================

references = supporting.get(
    "references"
)

sources = supporting.get(
    "sources"
)

comparison = supporting.get(
    "comparison"
)

knowledge = supporting.get(
    "knowledge"
)

communication = supporting.get(
    "communication"
)


add_check(
    "REFERENCE PLAN PRESENT",
    bool(references),
    (
        f"items={len(references)}"
        if hasattr(references, "__len__")
        else "present"
    ),
)


add_check(
    "SOURCE PLAN PRESENT",
    bool(sources),
    "present" if sources else "missing",
)


add_check(
    "COMPARISON PLAN PRESENT",
    bool(comparison),
    "present" if comparison else "missing",
)


add_check(
    "KNOWLEDGE PLAN PRESENT",
    bool(knowledge),
    "present" if knowledge else "missing",
)


add_check(
    "COMMUNICATION PLAN PRESENT",
    bool(communication),
    "present" if communication else "missing",
)


# ============================================================
# URL FORMAT SAFETY
# ============================================================

urls = collect_url_values(
    supporting
)


nonblank_urls = [
    url.strip()
    for url in urls
    if isinstance(url, str)
    and url.strip()
]


invalid_urls = 0


for url in nonblank_urls:

    parsed = urlparse(
        url
    )

    if parsed.scheme not in {
        "http",
        "https",
    }:
        invalid_urls += 1


add_check(
    "SOURCE URL FORMAT",
    invalid_urls == 0,
    (
        f"verified-format URLs={len(nonblank_urls)}, "
        f"invalid={invalid_urls}"
    ),
)


# ============================================================
# 478-ROW LINEAGE RECONCILIATION
# ============================================================

core_lineage = collect_row_ids(
    core
)

supporting_lineage = collect_row_ids(
    supporting
)


lineage_ids = (
    core_lineage
    | supporting_lineage
)


unknown_lineage_ids = (
    lineage_ids
    - staged_ids
)


add_check(
    "TRANSFORMATION LINEAGE VALIDITY",
    len(unknown_lineage_ids) == 0,
    f"unknown_row_ids={len(unknown_lineage_ids)}",
)


lineage_linked_ids = (
    staged_ids
    & lineage_ids
)


# Explicitly preserved invalid rows are still accounted for.
invalid_ids = {
    row.id
    for row in staged_rows
    if str(
        row.validation_status
    ).upper()
    == "INVALID"
}


# Aggregate destination sheets can legitimately preserve
# their original rows in ImportRow while creating one
# document/template/matrix object.
aggregate_source_sheets = set()


for value in collect_values_for_key(
    supporting,
    "source_sheet",
):

    if isinstance(value, str):
        aggregate_source_sheets.add(
            value
        )


aggregate_ids = {
    row.id
    for row in staged_rows
    if row.sheet_name
    in aggregate_source_sheets
}


accounted_ids = (
    lineage_linked_ids
    | invalid_ids
    | aggregate_ids
)


unaccounted_ids = (
    staged_ids
    - accounted_ids
)


add_check(
    "478 ROW ACCOUNTING",
    len(unaccounted_ids) == 0,
    (
        f"accounted={len(accounted_ids)}/478, "
        f"unaccounted={len(unaccounted_ids)}"
    ),
)


# Safe per-sheet count only.
unaccounted_sheet_counts = Counter(
    row.sheet_name
    for row in staged_rows
    if row.id in unaccounted_ids
)


# ============================================================
# KNOWLEDGE ARCHITECTURE GATE
# ============================================================

ServiceContentSection = model(
    "ServiceContentSection"
)

service_field = (
    ServiceContentSection
    ._meta
    .get_field(
        "service"
    )
)


knowledge_document_exists = False
knowledge_section_exists = False


try:
    model(
        "KnowledgeDocument"
    )
    knowledge_document_exists = True
except LookupError:
    pass


try:
    model(
        "KnowledgeSection"
    )
    knowledge_section_exists = True
except LookupError:
    pass


step11g_report = Path(
    "confidential_source/audit/"
    "step11g_section_level_knowledge_SAFE_TO_SHARE.txt"
)


unmatched_sections = None
ambiguous_sections = None


if step11g_report.exists():

    text = step11g_report.read_text(
        encoding="utf-8",
        errors="replace",
    )

    unmatched_match = re.search(
        r"^\s*UNMATCHED:\s*(\d+)",
        text,
        re.MULTILINE,
    )

    ambiguous_match = re.search(
        r"^\s*AMBIGUOUS:\s*(\d+)",
        text,
        re.MULTILINE,
    )

    if unmatched_match:
        unmatched_sections = int(
            unmatched_match.group(1)
        )

    if ambiguous_match:
        ambiguous_sections = int(
            ambiguous_match.group(1)
        )


knowledge_architecture_safe = (
    knowledge_document_exists
    and knowledge_section_exists
)


if not knowledge_architecture_safe:

    # Current ServiceContentSection cannot safely
    # store general/unmatched knowledge when Service
    # is mandatory.
    knowledge_architecture_safe = (
        service_field.null
        and (
            unmatched_sections in (
                None,
                0,
            )
        )
    )


add_check(
    "KNOWLEDGE ARCHITECTURE",
    knowledge_architecture_safe,
    (
        "dedicated knowledge models available"
        if (
            knowledge_document_exists
            and knowledge_section_exists
        )
        else (
            "current ServiceContentSection requires Service; "
            f"unmatched={unmatched_sections}, "
            f"ambiguous={ambiguous_sections}"
        )
    ),
)


# ============================================================
# IMPORT / ROLLBACK ENGINE EVIDENCE
# ============================================================

python_files = list(
    (ROOT / "toolkit").rglob(
        "*.py"
    )
)


code_text_parts = []


for path in python_files:

    try:
        code_text_parts.append(
            path.read_text(
                encoding="utf-8",
                errors="ignore",
            )
        )
    except Exception:
        pass


code_text = "\n".join(
    code_text_parts
)


has_atomic = (
    "transaction.atomic" in code_text
)


has_importchange_write = bool(
    re.search(
        r"ImportChange\s*\.\s*objects\s*\.\s*(create|bulk_create)",
        code_text,
    )
)


has_rollback_function = bool(
    re.search(
        r"def\s+[A-Za-z0-9_]*rollback[A-Za-z0-9_]*\s*\(",
        code_text,
        re.IGNORECASE,
    )
)


add_check(
    "ATOMIC IMPORT ENGINE",
    has_atomic,
    f"transaction.atomic={has_atomic}",
)


add_check(
    "IMPORT CHANGE LEDGER WRITER",
    has_importchange_write,
    f"writer_detected={has_importchange_write}",
)


add_check(
    "ROLLBACK ENGINE",
    has_rollback_function,
    f"rollback_callable_detected={has_rollback_function}",
)


# ============================================================
# DEVELOPMENT / PRODUCTION MODE
# ============================================================

add_check(
    "DEVELOPMENT MODE",
    settings.DEBUG is True,
    f"DEBUG={settings.DEBUG}",
)


# ============================================================
# FINAL READINESS
# ============================================================

blocking_checks = {
    item["name"]: item["passed"]
    for item in checks
    if item["name"]
    not in {
        "DEVELOPMENT MODE",
    }
}


import_ready = all(
    blocking_checks.values()
)


production_ready = (
    import_ready
    and settings.DEBUG is False
)


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step12c_master_preimport_gate_SAFE_TO_SHARE.txt"
)


lines = [
    "=" * 84,
    "BHARATNXT WAVE — MASTER PRE-IMPORT GATE",
    "=" * 84,
    "",
    f"Contract version: {contract.get('contract', {}).get('version', 'UNKNOWN')}",
    f"Import Batch: {batch.id}",
    f"Batch status: {batch.status}",
    "Database writes performed: NO",
    "",
    "CHECK RESULTS",
    "-" * 84,
]


for item in checks:

    status = (
        "PASS"
        if item["passed"]
        else "FAIL"
    )

    lines.append(
        f"{status:4} | "
        f"{item['name']} | "
        f"{item['detail']}"
    )


lines.extend(
    [
        "",
        "ROW ACCOUNTING",
        "-" * 84,
        f"Staged rows: {len(staged_ids)}",
        f"Direct transformation lineage: {len(lineage_linked_ids)}",
        f"Explicit invalid preservation: {len(invalid_ids)}",
        f"Aggregate-sheet preservation coverage: {len(aggregate_ids)}",
        f"Unaccounted rows: {len(unaccounted_ids)}",
    ]
)


if unaccounted_sheet_counts:

    lines.append(
        "Unaccounted rows by sheet:"
    )

    for sheet_name, count in sorted(
        unaccounted_sheet_counts.items()
    ):
        lines.append(
            f"  {sheet_name}: {count}"
        )


lines.extend(
    [
        "",
        "KNOWN ARCHITECTURE STATUS",
        "-" * 84,
        (
            "KnowledgeDocument model: "
            f"{'YES' if knowledge_document_exists else 'NO'}"
        ),
        (
            "KnowledgeSection model: "
            f"{'YES' if knowledge_section_exists else 'NO'}"
        ),
        (
            "ServiceContentSection.service nullable: "
            f"{'YES' if service_field.null else 'NO'}"
        ),
        (
            "Step 11G unmatched sections: "
            f"{unmatched_sections}"
        ),
        (
            "Step 11G ambiguous sections: "
            f"{ambiguous_sections}"
        ),
        "",
        "FINAL GATE",
        "-" * 84,
        (
            "STRUCTURAL IMPORT READY: "
            f"{'YES' if import_ready else 'NO'}"
        ),
        (
            "PRODUCTION RELEASE READY: "
            f"{'YES' if production_ready else 'NO'}"
        ),
        "",
    ]
)


if not import_ready:

    lines.append(
        "BLOCKERS:"
    )

    for item in checks:

        if (
            not item["passed"]
            and item["name"]
            != "DEVELOPMENT MODE"
        ):
            lines.append(
                f"  - {item['name']}"
            )


lines.extend(
    [
        "",
        "LIVE DATABASE IMPORT: NOT STARTED",
        "=" * 84,
    ]
)


output.write_text(
    "\n".join(
        lines
    ),
    encoding="utf-8",
)


print(
    output.read_text(
        encoding="utf-8"
    )
)
