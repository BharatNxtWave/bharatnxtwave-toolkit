import hashlib
import os
import re
import sys

from collections import Counter, defaultdict
from pathlib import Path


os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "config.settings",
)

ROOT = Path.cwd()

if str(ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(ROOT),
    )


import django
django.setup()


from toolkit.models import (
    Category,
    CommunicationTemplate,
    ComparisonEntry,
    ComparisonMatrix,
    ImportBatch,
    ImportChange,
    ImportRow,
    ReferenceItem,
    Service,
    ServiceClassification,
    ServiceCommercial,
    ServiceContentSection,
    ServiceDomain,
    ServiceSource,
)


# ============================================================
# CONSTANTS
# ============================================================

BATCH_ID = 5

EXPECTED_SOURCE_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)

CONTRACT_V1 = Path(
    "confidential_source/audit/"
    "step10_mapping_contract_v1.json"
)

EXPECTED_CONTRACT_SHA256 = (
    "f1c41706c4d6e263546f86f3c0eb6e94"
    "ee081c490762bd472fdade082ef5a423"
)

EXPECTED_ROWS = 478
EXPECTED_STRUCTURED = 100
EXPECTED_COMMERCIAL = 61
EXPECTED_FINAL = 162


# ============================================================
# EXISTING DOMAIN SLUGS
# ============================================================

DOMAIN_BUSINESS = (
    "business-incorporation-and-launch"
)

DOMAIN_COMPLIANCE = (
    "compliance-management"
)

DOMAIN_LICENSES = (
    "licenses-registrations-and-certifications"
)

DOMAIN_GOVT = (
    "government-schemes-and-grants"
)

DOMAIN_FUNDING = (
    "funding-and-equity-support"
)

DOMAIN_LEGAL = (
    "legal-drafting-and-contracts"
)

DOMAIN_DIGITAL = (
    "branding-website-and-digital-presence"
)

DOMAIN_STRATEGY = (
    "business-strategy-and-growth-consulting"
)


# ============================================================
# EXISTING CATEGORY SLUGS
# ============================================================

CAT_COMPANY_INCORPORATION = (
    "company-incorporation"
)

CAT_BUSINESS_REGISTRATIONS = (
    "business-registrations"
)

CAT_STARTUP_MSME = (
    "startup-and-msme-recognition"
)

CAT_ANNUAL_ROC = (
    "annual-and-roc-compliance"
)

CAT_GST_TAX = (
    "gst-and-tax-compliance"
)

CAT_LABOUR = (
    "labour-law-compliance"
)

CAT_AUDIT = (
    "audit-and-reporting"
)

CAT_GOVT_GRANTS = (
    "government-grants"
)

CAT_CREDIT = (
    "credit-and-guarantee-schemes"
)

CAT_SECTOR_SCHEMES = (
    "sector-specific-schemes"
)

CAT_SUBSIDIES = (
    "state-subsidies"
)

CAT_LICENSES = (
    "licenses"
)

CAT_CERTIFICATIONS = (
    "certifications"
)

CAT_IP = (
    "trademark-and-intellectual-property"
)

CAT_TRADE_REG = (
    "trade-and-business-registrations"
)

CAT_INVESTOR = (
    "investor-connect"
)

CAT_PITCH = (
    "pitch-deck-and-financial-model"
)

CAT_VALUATION = (
    "valuation"
)

CAT_DATA_ROOM = (
    "data-room-and-fundraise-readiness"
)

CAT_FOUNDER_AGREEMENTS = (
    "founder-agreements"
)

CAT_NDA = (
    "ndas-and-commercial-contracts"
)

CAT_VENDOR_AGREEMENTS = (
    "vendor-and-partnership-agreements"
)

CAT_HR_POLICIES = (
    "hr-and-employment-policies"
)

CAT_BRANDING = (
    "branding-and-identity"
)

CAT_WEBSITE = (
    "website-development"
)

CAT_DIGITAL_MARKETING = (
    "digital-marketing"
)

CAT_SOCIAL = (
    "social-media"
)

CAT_SEO = (
    "seo"
)

CAT_HIRING = (
    "hiring-and-hr-systems"
)

CAT_PRICING = (
    "pricing-strategy"
)

CAT_GTM = (
    "go-to-market-strategy"
)

CAT_SCALING = (
    "scaling-and-growth"
)


# ============================================================
# PLANNED NEW CLASSIFICATION CATEGORIES
#
# These are not created in this audit.
# ============================================================

PLANNED_CLASSIFICATION_CATEGORIES = {

    "Agriculture": {
        "name": "Agriculture Schemes",
        "slug": "agriculture-schemes",
        "domain": DOMAIN_GOVT,
    },

    "Debt": {
        "name": "Debt Funding",
        "slug": "debt-funding",
        "domain": DOMAIN_FUNDING,
    },

    "Equity": {
        "name": "Equity Funding",
        "slug": "equity-funding",
        "domain": DOMAIN_FUNDING,
    },

    "Funding": {
        "name": "Funding Programs",
        "slug": "funding-programs",
        "domain": DOMAIN_FUNDING,
    },

    "Mixed Finance": {
        "name": "Mixed Finance",
        "slug": "mixed-finance",
        "domain": DOMAIN_FUNDING,
    },

    "NGO": {
        "name": "NGO-Focused Schemes",
        "slug": "ngo-focused-schemes",
        "domain": DOMAIN_GOVT,
    },

    "Women": {
        "name": "Women-Focused Schemes",
        "slug": "women-focused-schemes",
        "domain": DOMAIN_GOVT,
    },
}


# ============================================================
# HELPERS
# ============================================================

def sha256_file(path):

    digest = hashlib.sha256()

    with Path(path).open("rb") as handle:

        for chunk in iter(
            lambda: handle.read(
                1024 * 1024
            ),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


def raw(row):

    return (
        row.raw_data
        if isinstance(
            row.raw_data,
            dict,
        )
        else {}
    )


def meta(row):

    value = raw(row).get(
        "_meta",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def cells(row):

    value = raw(row).get(
        "cells",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def fields(row):

    value = raw(row).get(
        "fields",
        {},
    )

    return (
        value
        if isinstance(
            value,
            dict,
        )
        else {}
    )


def payload_value(payload):

    if not isinstance(
        payload,
        dict,
    ):
        return ""

    value = payload.get(
        "value"
    )

    if value is None:
        return ""

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def column_value(
    row,
    column,
):

    return payload_value(
        cells(row).get(
            column,
            {},
        )
    )


def normalize_identity(value):

    if value is None:
        return ""

    text = str(
        value
    ).casefold()

    text = text.replace(
        "&",
        " and ",
    )

    text = re.sub(
        r"[_/]+",
        " ",
        text,
    )

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def has_phrase(
    identity,
    phrase,
):

    text = normalize_identity(
        identity
    )

    phrase = normalize_identity(
        phrase
    )

    if not text or not phrase:
        return False

    return bool(
        re.search(
            r"(?:^|\s)"
            + re.escape(
                phrase
            )
            + r"(?:\s|$)",
            text,
        )
    )


def has_any(
    identity,
    phrases,
):

    return any(
        has_phrase(
            identity,
            phrase,
        )
        for phrase in phrases
    )


# ============================================================
# CONTRACT + BATCH INTEGRITY
# ============================================================

if not CONTRACT_V1.exists():

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 missing."
    )


if (
    sha256_file(CONTRACT_V1)
    != EXPECTED_CONTRACT_SHA256
):

    raise SystemExit(
        "STOPPED SAFELY: Mapping Contract v1 "
        "SHA-256 changed."
    )


batch = ImportBatch.objects.get(
    pk=BATCH_ID
)


if (
    batch.file_sha256
    != EXPECTED_SOURCE_SHA256
):

    raise SystemExit(
        "STOPPED SAFELY: source SHA-256 mismatch."
    )


batch_metadata = (
    batch.metadata
    if isinstance(
        batch.metadata,
        dict,
    )
    else {}
)


if (
    batch_metadata.get("operation")
    != "workbook_staging"
):

    raise SystemExit(
        "STOPPED SAFELY: Batch #5 is not "
        "the approved staging batch."
    )


rows = list(
    ImportRow.objects
    .filter(import_batch=batch)
    .order_by(
        "sheet_name",
        "source_row_number",
    )
)


if len(rows) != EXPECTED_ROWS:

    raise SystemExit(
        "STOPPED SAFELY: expected 478 staged rows."
    )


# ============================================================
# VERIFY EXISTING DOMAIN / CATEGORY VOCABULARY
# ============================================================

existing_domains = {
    domain.slug: domain
    for domain in (
        ServiceDomain.objects.all()
    )
}


required_domain_slugs = {
    DOMAIN_BUSINESS,
    DOMAIN_COMPLIANCE,
    DOMAIN_LICENSES,
    DOMAIN_GOVT,
    DOMAIN_FUNDING,
    DOMAIN_LEGAL,
    DOMAIN_DIGITAL,
    DOMAIN_STRATEGY,
}


missing_domains = (
    required_domain_slugs
    - set(
        existing_domains
    )
)


if missing_domains:

    raise SystemExit(
        "STOPPED SAFELY: expected domain "
        "vocabulary has changed."
    )


existing_categories = {
    (
        category.domain.slug,
        category.slug,
    ): category
    for category in (
        Category.objects
        .select_related("domain")
        .all()
    )
}


# ============================================================
# SOURCE-TYPE PRIMARY KIND LOGIC
#
# Same conservative architecture established earlier.
# ============================================================

SOURCE_TYPE_KEYWORDS = {

    "GRANT": (
        "grant",
    ),

    "LOAN": (
        "loan",
    ),

    "DEBT": (
        "debt",
    ),

    "EQUITY": (
        "equity",
    ),

    "SUBSIDY": (
        "subsidy",
    ),

    "CERTIFICATION": (
        "certificate",
        "certification",
    ),

    "GOVT_SCHEME": (
        "government scheme",
        "govt scheme",
    ),

    "REGISTRATION": (
        "registration",
    ),

    "COMPLIANCE": (
        "compliance",
    ),

    "LEGAL": (
        "legal",
    ),

    "CONSULTING": (
        "consulting",
        "consultancy",
    ),

    "DIGITAL": (
        "digital",
    ),
}


SHEET_PRIMARY_KIND = {

    "GRANT":
        "GRANT",

    "Women_GRANT":
        "GRANT",

    "Agriculture_FUND":
        "GOVT_SCHEME",

    "NGO_GRANT":
        "GRANT",

    "EQUITY":
        "EQUITY",

    "GRANTDEBTEQUITY":
        "GOVT_SCHEME",

    "DEBTEQUITY":
        "GOVT_SCHEME",

    "LOAN ONLY":
        "LOAN",

    "LOANSUBSIDY":
        "GOVT_SCHEME",

    "CERTGEM":
        "CERTIFICATION",
}


def source_type_signals(
    text
):

    padded = (
        " "
        + normalize_identity(
            text
        )
        + " "
    )


    matches = set()


    for kind, terms in (
        SOURCE_TYPE_KEYWORDS.items()
    ):

        for term in terms:

            normalized_term = (
                normalize_identity(
                    term
                )
            )

            if re.search(
                r"(?:^|\s)"
                + re.escape(
                    normalized_term
                )
                + r"(?:\s|$)",
                padded.strip(),
            ):

                matches.add(
                    kind
                )

                break


    return matches


service_kind_values = {
    str(value)
    for value, label
    in Service._meta.get_field(
        "service_kind"
    ).choices
}


def resolve_structured_kind(
    group
):

    sheets = {
        row.sheet_name
        for row in group
    }


    source_values = []


    for row in group:

        value = payload_value(
            fields(row).get(
                "scheme_type",
                {},
            )
        )


        if value:

            source_values.append(
                value
            )


    normalized_source_values = {
        normalize_identity(
            value
        )
        for value in (
            source_values
        )
        if normalize_identity(
            value
        )
    }


    source_signals = set()


    for value in (
        source_values
    ):

        source_signals.update(
            source_type_signals(
                value
            )
        )


    valid_signals = {
        signal
        for signal in (
            source_signals
        )
        if signal in (
            service_kind_values
        )
    }


    if (
        len(valid_signals) == 1
        and len(
            normalized_source_values
        ) <= 1
    ):

        return next(
            iter(
                valid_signals
            )
        )


    sheet_kinds = {
        SHEET_PRIMARY_KIND[
            sheet
        ]
        for sheet in sheets
        if sheet
        in SHEET_PRIMARY_KIND
    }


    if len(sheet_kinds) == 1:

        return next(
            iter(
                sheet_kinds
            )
        )


    if sheet_kinds:

        return "GOVT_SCHEME"


    return None


# ============================================================
# PRIMARY DOMAIN / CATEGORY FOR STRUCTURED SERVICE
# ============================================================

STRUCTURED_PRIMARY_MAP = {

    "CERTIFICATION": (
        DOMAIN_LICENSES,
        CAT_CERTIFICATIONS,
    ),

    "EQUITY": (
        DOMAIN_FUNDING,
        "equity-funding",
    ),

    "GOVT_SCHEME": (
        DOMAIN_GOVT,
        CAT_SECTOR_SCHEMES,
    ),

    "GRANT": (
        DOMAIN_GOVT,
        CAT_GOVT_GRANTS,
    ),

    "LOAN": (
        DOMAIN_GOVT,
        CAT_CREDIT,
    ),

    "SUBSIDY": (
        DOMAIN_GOVT,
        CAT_SUBSIDIES,
    ),

    "DEBT": (
        DOMAIN_FUNDING,
        "debt-funding",
    ),
}


# ============================================================
# STRUCTURED SERVICES
# ============================================================

structured_rows = [
    row
    for row in rows
    if (
        meta(row).get(
            "family"
        )
        == "SCHEME_TABLE"
        and row.source_key
    )
]


structured_groups = defaultdict(
    list
)


for row in structured_rows:

    identity = normalize_identity(
        payload_value(
            fields(row).get(
                "scheme_name",
                {},
            )
        )
    )


    if identity:

        structured_groups[
            identity
        ].append(
            row
        )


if len(structured_groups) != EXPECTED_STRUCTURED:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "100 structured Service identities."
    )


structured_resolution = {}

structured_kind_counts = Counter()

structured_domain_counts = Counter()

structured_category_counts = Counter()

structured_unresolved = 0

structured_new_primary_categories = Counter()


for identity, group in (
    structured_groups.items()
):

    kind = resolve_structured_kind(
        group
    )


    if (
        not kind
        or kind
        not in STRUCTURED_PRIMARY_MAP
    ):

        structured_unresolved += 1
        continue


    domain_slug, category_slug = (
        STRUCTURED_PRIMARY_MAP[
            kind
        ]
    )


    category_exists = (
        (
            domain_slug,
            category_slug,
        )
        in existing_categories
    )


    if not category_exists:

        # Only explicitly planned taxonomy categories
        # may be considered here.
        planned_match = any(
            data[
                "domain"
            ]
            == domain_slug
            and data[
                "slug"
            ]
            == category_slug
            for data in (
                PLANNED_CLASSIFICATION_CATEGORIES.values()
            )
        )


        if not planned_match:

            structured_unresolved += 1
            continue


        structured_new_primary_categories[
            category_slug
        ] += 1


    structured_resolution[
        identity
    ] = {
        "kind": kind,
        "domain": domain_slug,
        "category": category_slug,
        "category_exists": (
            category_exists
        ),
    }


    structured_kind_counts[
        kind
    ] += 1

    structured_domain_counts[
        domain_slug
    ] += 1

    structured_category_counts[
        category_slug
    ] += 1


# ============================================================
# COMMERCIAL SERVICE CATALOGUE
# ============================================================

amount_rows = [
    row
    for row in rows
    if (
        row.sheet_name
        == "AMOUNT DEDUCTIONS"
        and meta(row).get(
            "row_role"
        )
        == "DATA"
    )
]


commercial_rows_by_identity = defaultdict(
    list
)


for row in amount_rows:

    identity = normalize_identity(
        column_value(
            row,
            "A",
        )
    )


    if identity:

        commercial_rows_by_identity[
            identity
        ].append(
            row
        )


commercial_identities = set(
    commercial_rows_by_identity
)


if len(commercial_identities) != EXPECTED_COMMERCIAL:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "61 commercial labels."
    )


commercial_overlap = (
    commercial_identities
    & set(
        structured_groups
    )
)


commercial_additional = (
    commercial_identities
    - set(
        structured_groups
    )
)


# ============================================================
# COMMERCIAL PRIMARY KIND
# ============================================================

COMMERCIAL_KIND_RULES = {

    "REGISTRATION": (
        "registration",
        "incorporation",
        "register",
    ),

    "CERTIFICATION": (
        "certification",
        "certificate",
        "iso",
        "cert",
    ),
}


def commercial_kind(
    identity
):

    matches = set()


    for kind, terms in (
        COMMERCIAL_KIND_RULES.items()
    ):

        for term in terms:

            if has_phrase(
                identity,
                term,
            ):

                matches.add(
                    kind
                )

                break


    if len(matches) == 1:

        return next(
            iter(matches)
        )


    # No trustworthy type signal.
    return "OTHER"


# ============================================================
# COMMERCIAL EXISTING-CATEGORY RULES
#
# Ordered from specific -> generic.
# ============================================================

COMMERCIAL_CATEGORY_RULES = [

    (
        DOMAIN_LICENSES,
        CAT_IP,
        (
            "trademark",
            "trade mark",
            "patent",
            "copyright",
            "intellectual property",
        ),
    ),

    (
        DOMAIN_COMPLIANCE,
        CAT_GST_TAX,
        (
            "gst",
            "income tax",
            "tax return",
            "tds",
        ),
    ),

    (
        DOMAIN_COMPLIANCE,
        CAT_ANNUAL_ROC,
        (
            "roc",
            "annual filing",
            "annual compliance",
            "mca filing",
        ),
    ),

    (
        DOMAIN_COMPLIANCE,
        CAT_LABOUR,
        (
            "labour",
            "labor",
            "pf",
            "provident fund",
            "esi",
            "esic",
        ),
    ),

    (
        DOMAIN_COMPLIANCE,
        CAT_AUDIT,
        (
            "audit",
            "reporting",
        ),
    ),

    (
        DOMAIN_LICENSES,
        CAT_CERTIFICATIONS,
        (
            "iso",
            "certificate",
            "certification",
            "cert",
        ),
    ),

    (
        DOMAIN_LICENSES,
        CAT_LICENSES,
        (
            "license",
            "licence",
        ),
    ),

    (
        DOMAIN_BUSINESS,
        CAT_COMPANY_INCORPORATION,
        (
            "private limited",
            "pvt ltd",
            "incorporation",
            "company formation",
            "opc",
            "one person company",
            "llp",
            "limited liability partnership",
        ),
    ),

    (
        DOMAIN_BUSINESS,
        CAT_STARTUP_MSME,
        (
            "startup india",
            "start up india",
            "msme",
            "udyam",
        ),
    ),

    (
        DOMAIN_LICENSES,
        CAT_TRADE_REG,
        (
            "trade registration",
            "trade licence",
            "trade license",
            "gem",
            "import export",
            "iec",
        ),
    ),

    (
        DOMAIN_FUNDING,
        CAT_PITCH,
        (
            "pitch deck",
            "financial model",
        ),
    ),

    (
        DOMAIN_FUNDING,
        CAT_VALUATION,
        (
            "valuation",
        ),
    ),

    (
        DOMAIN_FUNDING,
        CAT_DATA_ROOM,
        (
            "data room",
            "fundraise readiness",
        ),
    ),

    (
        DOMAIN_FUNDING,
        CAT_INVESTOR,
        (
            "investor",
            "fundraise",
            "fund raising",
            "fundraising",
        ),
    ),

    (
        DOMAIN_GOVT,
        CAT_GOVT_GRANTS,
        (
            "grant",
        ),
    ),

    (
        DOMAIN_GOVT,
        CAT_CREDIT,
        (
            "loan",
            "credit guarantee",
        ),
    ),

    (
        DOMAIN_GOVT,
        CAT_SUBSIDIES,
        (
            "subsidy",
        ),
    ),

    (
        DOMAIN_LEGAL,
        CAT_FOUNDER_AGREEMENTS,
        (
            "founder agreement",
            "founders agreement",
        ),
    ),

    (
        DOMAIN_LEGAL,
        CAT_NDA,
        (
            "nda",
            "non disclosure",
            "commercial contract",
        ),
    ),

    (
        DOMAIN_LEGAL,
        CAT_VENDOR_AGREEMENTS,
        (
            "vendor agreement",
            "partnership agreement",
        ),
    ),

    (
        DOMAIN_LEGAL,
        CAT_HR_POLICIES,
        (
            "employment agreement",
            "employment policy",
            "hr policy",
        ),
    ),

    (
        DOMAIN_DIGITAL,
        CAT_SEO,
        (
            "seo",
            "search engine optimization",
        ),
    ),

    (
        DOMAIN_DIGITAL,
        CAT_SOCIAL,
        (
            "social media",
        ),
    ),

    (
        DOMAIN_DIGITAL,
        CAT_WEBSITE,
        (
            "website",
            "web development",
        ),
    ),

    (
        DOMAIN_DIGITAL,
        CAT_BRANDING,
        (
            "branding",
            "brand identity",
            "logo",
        ),
    ),

    (
        DOMAIN_DIGITAL,
        CAT_DIGITAL_MARKETING,
        (
            "digital marketing",
            "online marketing",
        ),
    ),

    (
        DOMAIN_STRATEGY,
        CAT_HIRING,
        (
            "hiring",
            "recruitment",
            "hr system",
        ),
    ),

    (
        DOMAIN_STRATEGY,
        CAT_PRICING,
        (
            "pricing strategy",
            "pricing",
        ),
    ),

    (
        DOMAIN_STRATEGY,
        CAT_GTM,
        (
            "go to market",
            "gtm",
        ),
    ),

    (
        DOMAIN_STRATEGY,
        CAT_SCALING,
        (
            "scaling",
            "growth strategy",
        ),
    ),

    (
        DOMAIN_BUSINESS,
        CAT_BUSINESS_REGISTRATIONS,
        (
            "registration",
            "register",
        ),
    ),
]


def resolve_commercial_category(
    identity,
    kind,
):

    matches = []


    for (
        domain_slug,
        category_slug,
        phrases,
    ) in COMMERCIAL_CATEGORY_RULES:

        if has_any(
            identity,
            phrases,
        ):

            matches.append(
                (
                    domain_slug,
                    category_slug,
                )
            )


    # Remove duplicates while keeping ordered
    # specificity.
    unique_matches = []


    for match in matches:

        if match not in (
            unique_matches
        ):

            unique_matches.append(
                match
            )


    if unique_matches:

        return (
            unique_matches[0],
            len(
                unique_matches
            ),
            "TITLE_SIGNAL",
        )


    # Primary-kind fallback is defensible for
    # known registration/certification Services.

    if kind == "CERTIFICATION":

        return (
            (
                DOMAIN_LICENSES,
                CAT_CERTIFICATIONS,
            ),
            0,
            "KIND_FALLBACK",
        )


    if kind == "REGISTRATION":

        return (
            (
                DOMAIN_BUSINESS,
                CAT_BUSINESS_REGISTRATIONS,
            ),
            0,
            "KIND_FALLBACK",
        )


    # OTHER remains intentionally unresolved.
    return (
        None,
        0,
        "GENERIC_CATEGORY_REQUIRED",
    )


commercial_resolution = {}

commercial_kind_counts = Counter()

commercial_domain_counts = Counter()

commercial_category_counts = Counter()

commercial_resolution_method = Counter()

commercial_multi_signal_counts = Counter()

commercial_unresolved_other = 0


for identity in sorted(
    commercial_additional
):

    kind = commercial_kind(
        identity
    )


    (
        category_pair,
        match_count,
        method,
    ) = resolve_commercial_category(
        identity,
        kind,
    )


    commercial_kind_counts[
        kind
    ] += 1


    if match_count > 1:

        commercial_multi_signal_counts[
            match_count
        ] += 1


    commercial_resolution_method[
        method
    ] += 1


    if category_pair is None:

        commercial_unresolved_other += 1

        commercial_resolution[
            identity
        ] = {
            "kind": kind,
            "domain": None,
            "category": None,
            "method": method,
        }

        continue


    domain_slug, category_slug = (
        category_pair
    )


    if (
        (
            domain_slug,
            category_slug,
        )
        not in existing_categories
    ):

        raise SystemExit(
            "STOPPED SAFELY: commercial rule "
            "references a missing existing Category."
        )


    commercial_resolution[
        identity
    ] = {
        "kind": kind,
        "domain": domain_slug,
        "category": category_slug,
        "method": method,
    }


    commercial_domain_counts[
        domain_slug
    ] += 1

    commercial_category_counts[
        category_slug
    ] += 1


# ============================================================
# TWO NEW ROLLING GRANTS
# ============================================================

rolling_rows = [
    row
    for row in rows
    if row.sheet_name
    == "Rolling_Grants"
]


rolling_new = {}


for row in (
    rolling_rows
):

    identity = normalize_identity(
        column_value(
            row,
            "A",
        )
    )


    if not identity:

        continue


    if identity in structured_groups:

        continue


    if identity in commercial_identities:

        continue


    rolling_new[
        identity
    ] = {
        "kind": "GRANT",
        "domain": DOMAIN_GOVT,
        "category": CAT_GOVT_GRANTS,
    }


if len(rolling_new) != 2:

    raise SystemExit(
        "STOPPED SAFELY: expected exactly "
        "2 new Rolling Grant Services."
    )


# ============================================================
# FINAL 162 SERVICE UNIVERSE
# ============================================================

final_identities = (
    set(
        structured_groups
    )
    | commercial_identities
    | set(
        rolling_new
    )
)


if len(final_identities) != EXPECTED_FINAL:

    raise SystemExit(
        "STOPPED SAFELY: expected "
        "162 final prospective Services."
    )


# ============================================================
# LIVE SERVICE COLLISION CHECK
# ============================================================

live_titles = {
    normalize_identity(
        title
    )
    for title in (
        Service.objects.values_list(
            "title",
            flat=True,
        )
    )
    if normalize_identity(
        title
    )
}


live_service_identity_matches = (
    final_identities
    & live_titles
)


# ============================================================
# CLASSIFICATION CATEGORY PLAN
# ============================================================

existing_classification_mapping = {

    "Certification": (
        DOMAIN_LICENSES,
        CAT_CERTIFICATIONS,
    ),

    "Grant": (
        DOMAIN_GOVT,
        CAT_GOVT_GRANTS,
    ),

    "Loan": (
        DOMAIN_GOVT,
        CAT_CREDIT,
    ),

    "Subsidy": (
        DOMAIN_GOVT,
        CAT_SUBSIDIES,
    ),
}


classification_plan_status = Counter()

planned_new_category_status = Counter()


for label, pair in (
    existing_classification_mapping.items()
):

    if pair in (
        existing_categories
    ):

        classification_plan_status[
            "REUSE_EXISTING"
        ] += 1

    else:

        classification_plan_status[
            "BROKEN_EXISTING_MAPPING"
        ] += 1


for label, data in (
    PLANNED_CLASSIFICATION_CATEGORIES.items()
):

    pair = (
        data[
            "domain"
        ],
        data[
            "slug"
        ],
    )


    if pair in (
        existing_categories
    ):

        planned_new_category_status[
            "ALREADY_EXISTS"
        ] += 1

    else:

        planned_new_category_status[
            "CREATE_NEW"
        ] += 1


# ============================================================
# GENERIC COMMERCIAL FALLBACK SIMULATION
#
# We do NOT create it yet.
# ============================================================

generic_fallback_candidate = {
    "name": (
        "Other Business Services"
    ),
    "slug": (
        "other-business-services"
    ),
    "domain": DOMAIN_STRATEGY,
}


generic_pair = (
    generic_fallback_candidate[
        "domain"
    ],
    generic_fallback_candidate[
        "slug"
    ],
)


generic_already_exists = (
    generic_pair
    in existing_categories
)


# ============================================================
# PRIMARY MAPPING READINESS
# ============================================================

structured_ready = len(
    structured_resolution
)

commercial_ready_without_generic = sum(
    1
    for identity in (
        commercial_additional
    )
    if commercial_resolution[
        identity
    ][
        "domain"
    ]
)


# Commercial overlap is not a new Service.
commercial_overlap_count = len(
    commercial_overlap
)


rolling_ready = len(
    rolling_new
)


ready_without_generic = (
    structured_ready
    + commercial_ready_without_generic
    + rolling_ready
)


unresolved_without_generic = (
    EXPECTED_FINAL
    - ready_without_generic
)


# The structured/commercial overlap is already represented
# by structured_resolution and therefore is not added again.


if (
    unresolved_without_generic
    != commercial_unresolved_other
):

    raise SystemExit(
        "STOPPED SAFELY: readiness arithmetic mismatch."
    )


ready_with_generic = (
    ready_without_generic
    + commercial_unresolved_other
)


# ============================================================
# DESTINATION SAFETY
# ============================================================

destination_counts = {

    "Service":
        Service.objects.count(),

    "ServiceDomain":
        ServiceDomain.objects.count(),

    "Category":
        Category.objects.count(),

    "ServiceClassification":
        ServiceClassification.objects.count(),

    "ServiceSource":
        ServiceSource.objects.count(),

    "ServiceCommercial":
        ServiceCommercial.objects.count(),

    "ServiceContentSection":
        ServiceContentSection.objects.count(),

    "ReferenceItem":
        ReferenceItem.objects.count(),

    "ComparisonMatrix":
        ComparisonMatrix.objects.count(),

    "ComparisonEntry":
        ComparisonEntry.objects.count(),

    "CommunicationTemplate":
        CommunicationTemplate.objects.count(),

    "ImportChange":
        ImportChange.objects.count(),
}


expected_zero_models = (
    "ServiceClassification",
    "ServiceSource",
    "ServiceCommercial",
    "ServiceContentSection",
    "ReferenceItem",
    "ComparisonMatrix",
    "ComparisonEntry",
    "CommunicationTemplate",
    "ImportChange",
)


if (
    destination_counts[
        "Service"
    ]
    != 1
):

    raise SystemExit(
        "STOPPED SAFELY: Service count changed."
    )


if (
    destination_counts[
        "ServiceDomain"
    ]
    != 8
):

    raise SystemExit(
        "STOPPED SAFELY: ServiceDomain count changed."
    )


if (
    destination_counts[
        "Category"
    ]
    != 32
):

    raise SystemExit(
        "STOPPED SAFELY: Category count changed."
    )


for model_name in (
    expected_zero_models
):

    if (
        destination_counts[
            model_name
        ]
        != 0
    ):

        raise SystemExit(
            "STOPPED SAFELY: "
            f"{model_name} unexpectedly "
            "contains data."
        )


# ============================================================
# SAFE REPORT
# ============================================================

output = Path(
    "confidential_source/audit/"
    "step10k_domain_category_resolution_SAFE_TO_SHARE.txt"
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 10K FINAL DOMAIN / CATEGORY RESOLUTION"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Mapping Contract v1 SHA-256 verified: YES"
)

lines.append(
    "Approved staged source verified: YES"
)

lines.append(
    f"Import Batch ID: "
    f"{batch.pk}"
)

lines.append(
    f"Final prospective Service identities: "
    f"{len(final_identities)}"
)

lines.append(
    "Database writes performed: NO"
)

lines.append("")


# ------------------------------------------------------------
lines.append(
    "1. STRUCTURED PRIMARY MAPPING"
)
# ------------------------------------------------------------

lines.append(
    f"  Structured identities: "
    f"{len(structured_groups)}"
)

lines.append(
    f"  Domain/category resolved: "
    f"{structured_ready}"
)

lines.append(
    f"  Unresolved: "
    f"{structured_unresolved}"
)


lines.append("")

lines.append(
    "  PRIMARY KINDS"
)


for kind, count in sorted(
    structured_kind_counts.items()
):

    lines.append(
        f"    {kind}: {count}"
    )


lines.append("")

lines.append(
    "  PRIMARY DOMAINS"
)


for domain_slug, count in sorted(
    structured_domain_counts.items()
):

    lines.append(
        f"    {domain_slug}: {count}"
    )


lines.append("")

lines.append(
    "  PRIMARY CATEGORIES"
)


for category_slug, count in sorted(
    structured_category_counts.items()
):

    lines.append(
        f"    {category_slug}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "2. COMMERCIAL ADDITIONAL SERVICE MAPPING"
)
# ------------------------------------------------------------

lines.append(
    f"  Unique commercial identities: "
    f"{len(commercial_identities)}"
)

lines.append(
    f"  Overlap with structured Services: "
    f"{commercial_overlap_count}"
)

lines.append(
    f"  Additional commercial Services: "
    f"{len(commercial_additional)}"
)

lines.append(
    f"  Existing domain/category resolved: "
    f"{commercial_ready_without_generic}"
)

lines.append(
    f"  Generic category still required: "
    f"{commercial_unresolved_other}"
)


lines.append("")

lines.append(
    "  COMMERCIAL SERVICE KINDS"
)


for kind, count in sorted(
    commercial_kind_counts.items()
):

    lines.append(
        f"    {kind}: {count}"
    )


lines.append("")

lines.append(
    "  RESOLUTION METHOD"
)


for method, count in sorted(
    commercial_resolution_method.items()
):

    lines.append(
        f"    {method}: {count}"
    )


lines.append("")

lines.append(
    "  RESOLVED DOMAINS"
)


if commercial_domain_counts:

    for domain_slug, count in sorted(
        commercial_domain_counts.items()
    ):

        lines.append(
            f"    {domain_slug}: {count}"
        )

else:

    lines.append(
        "    NONE"
    )


lines.append("")

lines.append(
    "  RESOLVED PRIMARY CATEGORIES"
)


if commercial_category_counts:

    for category_slug, count in sorted(
        commercial_category_counts.items()
    ):

        lines.append(
            f"    {category_slug}: {count}"
        )

else:

    lines.append(
        "    NONE"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "3. COMMERCIAL MULTI-SIGNAL OBSERVATIONS"
)
# ------------------------------------------------------------

if commercial_multi_signal_counts:

    for signal_count, count in sorted(
        commercial_multi_signal_counts.items()
    ):

        lines.append(
            f"  Services matching "
            f"{signal_count} ordered category rules: "
            f"{count}"
        )

else:

    lines.append(
        "  Services matching multiple category rules: 0"
    )


lines.append(
    "  First matching rule used only for "
    "this simulation: YES"
)

lines.append(
    "  Multi-signal values printed: NO"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "4. NEW ROLLING GRANT PRIMARY MAPPING"
)
# ------------------------------------------------------------

lines.append(
    f"  New Rolling Grant Services: "
    f"{rolling_ready}"
)

lines.append(
    "  Primary kind: GRANT"
)

lines.append(
    f"  Domain: "
    f"{DOMAIN_GOVT}"
)

lines.append(
    f"  Category: "
    f"{CAT_GOVT_GRANTS}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "5. CLASSIFICATION CATEGORY PLAN"
)
# ------------------------------------------------------------

lines.append(
    f"  Existing classification mappings: "
    f"{len(existing_classification_mapping)}"
)

lines.append(
    f"  Planned taxonomy categories: "
    f"{len(PLANNED_CLASSIFICATION_CATEGORIES)}"
)


for status, count in sorted(
    classification_plan_status.items()
):

    lines.append(
        f"  Existing-map {status}: "
        f"{count}"
    )


for status, count in sorted(
    planned_new_category_status.items()
):

    lines.append(
        f"  Planned-category {status}: "
        f"{count}"
    )


lines.append("")

lines.append(
    "  PLANNED NEW TAXONOMY CATEGORIES"
)


for label, data in sorted(
    PLANNED_CLASSIFICATION_CATEGORIES.items()
):

    lines.append(
        f"    {data['name']} | "
        f"domain={data['domain']} | "
        f"slug={data['slug']}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "6. GENERIC COMMERCIAL CATEGORY DECISION"
)
# ------------------------------------------------------------

lines.append(
    f"  Commercial Services requiring "
    f"generic primary category: "
    f"{commercial_unresolved_other}"
)

lines.append(
    f"  Proposed category name: "
    f"{generic_fallback_candidate['name']}"
)

lines.append(
    f"  Proposed category slug: "
    f"{generic_fallback_candidate['slug']}"
)

lines.append(
    f"  Proposed parent domain: "
    f"{generic_fallback_candidate['domain']}"
)

lines.append(
    "  Proposed Service kind for these: OTHER"
)

lines.append(
    "  Category currently exists: "
    + (
        "YES"
        if generic_already_exists
        else "NO"
    )
)

lines.append(
    "  Category created during audit: NO"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "7. FINAL PRIMARY-MAPPING READINESS"
)
# ------------------------------------------------------------

lines.append(
    f"  Total prospective Services: "
    f"{EXPECTED_FINAL}"
)

lines.append(
    f"  Ready using existing/planned "
    f"specific categories: "
    f"{ready_without_generic}"
)

lines.append(
    f"  Require generic Other Business "
    f"Services category: "
    f"{commercial_unresolved_other}"
)

lines.append(
    f"  Would be fully mapped after "
    f"generic category decision: "
    f"{ready_with_generic}"
)

lines.append(
    f"  Remaining unresolved after "
    f"generic decision: "
    f"{EXPECTED_FINAL - ready_with_generic}"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "8. EXISTING LIVE SERVICE COLLISION"
)
# ------------------------------------------------------------

lines.append(
    f"  Current live Service records: "
    f"{Service.objects.count()}"
)

lines.append(
    f"  Exact normalized title collisions "
    f"with final 162 identities: "
    f"{len(live_service_identity_matches)}"
)

lines.append(
    "  Colliding titles printed: NO"
)


lines.append("")


# ------------------------------------------------------------
lines.append(
    "9. DESTINATION SAFETY"
)
# ------------------------------------------------------------

for model_name, count in (
    destination_counts.items()
):

    lines.append(
        f"  {model_name}: {count}"
    )


lines.append("")


# ------------------------------------------------------------
lines.append(
    "10. WRITE / CONFIDENTIALITY SAFETY"
)
# ------------------------------------------------------------

lines.append(
    "  ServiceDomain records created: 0"
)

lines.append(
    "  Category records created: 0"
)

lines.append(
    "  Service records created: 0"
)

lines.append(
    "  Service records updated: 0"
)

lines.append(
    "  ImportRow records modified: 0"
)

lines.append(
    "  Source values printed: NO"
)

lines.append(
    "  Commercial service names printed: NO"
)

lines.append(
    "  Commercial amounts printed: NO"
)

lines.append(
    "  Workbook opened: NO"
)


output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 10K AUDIT COMPLETE"
)

print(
    f"Ready without generic category: "
    f"{ready_without_generic}"
)

print(
    f"Generic category required for: "
    f"{commercial_unresolved_other}"
)

print(
    f"Ready after generic decision: "
    f"{ready_with_generic}"
)

print(
    f"SAFE REPORT: {output}"
)
