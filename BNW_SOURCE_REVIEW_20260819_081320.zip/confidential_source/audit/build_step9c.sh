#!/usr/bin/env bash
set -euo pipefail

cd "/mnt/d/BharatNXT Wave/BharatNXTwave Toolkit"
source .venv/bin/activate

mkdir -p toolkit/importing
mkdir -p confidential_source/audit


echo ""
echo "============================================================"
echo "STEP 9C — WORKBOOK READER FOUNDATION"
echo "============================================================"


# ============================================================
# 1. PACKAGE
# ============================================================

cat > toolkit/importing/__init__.py <<'PY'
"""
BharatNXT Toolkit workbook import pipeline.

Nothing in this package should write live Service data unless
an explicit import/approval layer invokes that behaviour.
"""
PY


# ============================================================
# 2. SHEET REGISTRY
# ============================================================

cat > toolkit/importing/sheet_registry.py <<'PY'
import re


SCHEME_TABLES = (
    "GRANT",
    "Women_GRANT",
    "Agriculture_FUND",
    "NGO_GRANT",
    "EQUITY",
    "GRANTDEBTEQUITY",
    "DEBTEQUITY",
    "LOAN ONLY",
    "LOANSUBSIDY",
    "CERTGEM",
)


REFERENCE_TABLES = (
    "BENEFITS",
    "AMOUNT DEDUCTIONS",
)


COMPARISON_TABLES = (
    "LOAN",
)


KNOWLEDGE_SHEETS = (
    "START_UP INDIA",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
)


COMMUNICATION_SHEETS = (
    "ONBOARDING_MAIL",
)


ROLLING_GRANT_SHEETS = (
    "Rolling_Grants",
)


EXPECTED_SHEETS = (
    *SCHEME_TABLES,
    "BENEFITS",
    "START_UP INDIA",
    "LOAN",
    "TAX_CERT",
    "SEED FUND",
    "PVT",
    "LLP",
    "AMOUNT DEDUCTIONS",
    "ONBOARDING_MAIL",
    "Rolling_Grants",
)


def sheet_family(sheet_name):

    if sheet_name in SCHEME_TABLES:
        return "SCHEME_TABLE"

    if sheet_name in REFERENCE_TABLES:
        return "REFERENCE_TABLE"

    if sheet_name in COMPARISON_TABLES:
        return "COMPARISON_MATRIX"

    if sheet_name in KNOWLEDGE_SHEETS:
        return "KNOWLEDGE"

    if sheet_name in COMMUNICATION_SHEETS:
        return "COMMUNICATION"

    if sheet_name in ROLLING_GRANT_SHEETS:
        return "ROLLING_GRANTS"

    return "UNKNOWN"


def normalize_header(value):

    if value is None:
        return ""

    text = str(value).strip().casefold()

    text = text.replace(
        "&",
        " and ",
    )

    text = re.sub(
        r"[_/]+",
        " ",
        text,
    )

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


HEADER_ALIASES = {

    "serial_number": {
        "sr no",
        "sr no.",
        "sr. no.",
        "sr. no",
        "sr no",
        "sl no",
        "serial no",
        "serial number",
    },

    "scheme_name": {
        "scheme name",
    },

    "benefits": {
        "benefits",
        "benefit",
    },

    "focus_sectors": {
        "focus sectors",
        "focus sector",
        "sectors",
        "sector",
    },

    "eligibility": {
        "eligibility criteria",
        "eligibility",
    },

    "deadline": {
        "last date",
        "deadline",
        "application deadline",
    },

    "funding_organisation": {
        "funding organisation",
        "funding organization",
        "organisation",
        "organization",
    },

    "scheme_type": {
        "type of scheme",
        "scheme type",
        "type",
    },

    "applicable_for": {
        "applicable for",
        "application for",
    },

    "portal_link": {
        "portal links",
        "portal link",
        "portal",
    },

    "minimum_charge": {
        "min charge upfront",
        "minimum charge upfront",
        "min charge",
        "minimum charges",
    },

    "additional_info": {
        "additional info",
        "additional information",
    },

    "government_charge": {
        "govt charges if any",
        "govt charge if any",
        "govt charges",
        "govt registration charge",
        "government charge",
        "government charges",
    },

    "flyer": {
        "flyer",
    },
}


ALIAS_LOOKUP = {}

for canonical, aliases in HEADER_ALIASES.items():

    for alias in aliases:

        ALIAS_LOOKUP[
            normalize_header(alias)
        ] = canonical


def canonical_header(value):

    return ALIAS_LOOKUP.get(
        normalize_header(value)
    )
PY


# ============================================================
# 3. READ-ONLY WORKBOOK INSPECTOR
# ============================================================

cat > toolkit/importing/workbook_reader.py <<'PY'
from collections import Counter
from datetime import date, datetime
from hashlib import sha256
from pathlib import Path
import re

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell

from .sheet_registry import (
    EXPECTED_SHEETS,
    SCHEME_TABLES,
    canonical_header,
    sheet_family,
)


MAX_HEADER_SCAN_ROWS = 15
MAX_INSPECT_COLUMNS = 30


def file_sha256(path):

    digest = sha256()

    with Path(path).open("rb") as file:

        for chunk in iter(
            lambda: file.read(1024 * 1024),
            b"",
        ):
            digest.update(chunk)

    return digest.hexdigest()


def normalized_text(value):

    if value is None:
        return ""

    if isinstance(
        value,
        (datetime, date),
    ):
        return value.isoformat()

    return re.sub(
        r"\s+",
        " ",
        str(value),
    ).strip()


def normalized_identity(value):

    text = normalized_text(
        value
    ).casefold()

    text = re.sub(
        r"[^a-z0-9]+",
        " ",
        text,
    )

    return re.sub(
        r"\s+",
        " ",
        text,
    ).strip()


def build_merged_lookup(worksheet):

    lookup = {}

    for merged_range in (
        worksheet.merged_cells.ranges
    ):

        min_col = merged_range.min_col
        max_col = merged_range.max_col
        min_row = merged_range.min_row
        max_row = merged_range.max_row

        top_left = (
            min_row,
            min_col,
        )

        for row in range(
            min_row,
            max_row + 1,
        ):

            for column in range(
                min_col,
                max_col + 1,
            ):

                lookup[
                    (row, column)
                ] = top_left

    return lookup


def resolved_cell(
    worksheet,
    row,
    column,
    merged_lookup,
):

    cell = worksheet.cell(
        row=row,
        column=column,
    )

    if isinstance(
        cell,
        MergedCell,
    ):

        top_left = merged_lookup.get(
            (row, column)
        )

        if top_left:

            return worksheet.cell(
                row=top_left[0],
                column=top_left[1],
            )

    return cell


def cell_has_content(cell):

    if cell is None:
        return False

    if normalized_text(
        cell.value
    ):
        return True

    hyperlink = getattr(
        cell,
        "hyperlink",
        None,
    )

    if hyperlink and getattr(
        hyperlink,
        "target",
        None,
    ):
        return True

    return False


def find_scheme_header(
    worksheet,
    merged_lookup,
):

    best = None

    max_column = min(
        worksheet.max_column or 0,
        MAX_INSPECT_COLUMNS,
    )

    max_row = min(
        worksheet.max_row or 0,
        MAX_HEADER_SCAN_ROWS,
    )

    for row_number in range(
        1,
        max_row + 1,
    ):

        mapping = {}

        for column in range(
            1,
            max_column + 1,
        ):

            cell = resolved_cell(
                worksheet,
                row_number,
                column,
                merged_lookup,
            )

            canonical = canonical_header(
                cell.value
            )

            if (
                canonical
                and canonical not in mapping
            ):
                mapping[
                    canonical
                ] = column

        score = len(mapping)

        # A real scheme-table header must contain
        # Scheme Name. Other fields may vary.
        if "scheme_name" not in mapping:
            continue

        candidate = (
            score,
            -row_number,
            row_number,
            mapping,
        )

        if (
            best is None
            or candidate > best
        ):
            best = candidate

    if best is None:
        return None, {}

    return (
        best[2],
        best[3],
    )


def inspect_scheme_sheet(
    worksheet,
):

    merged_lookup = build_merged_lookup(
        worksheet
    )

    header_row, mapping = (
        find_scheme_header(
            worksheet,
            merged_lookup,
        )
    )

    result = {
        "header_row": header_row,
        "fields": sorted(mapping),
        "active_rows": 0,
        "rows_missing_scheme_name": 0,
        "portal_hyperlink_cells": 0,
        "merged_ranges": len(
            worksheet.merged_cells.ranges
        ),
        "_identities": [],
    }

    if header_row is None:
        return result

    meaningful_fields = {
        key: column
        for key, column
        in mapping.items()
        if key != "serial_number"
    }

    for row_number in range(
        header_row + 1,
        (worksheet.max_row or header_row) + 1,
    ):

        resolved = {}

        active = False

        for field, column in (
            meaningful_fields.items()
        ):

            cell = resolved_cell(
                worksheet,
                row_number,
                column,
                merged_lookup,
            )

            resolved[field] = cell

            if cell_has_content(cell):
                active = True

        if not active:
            continue

        result["active_rows"] += 1

        scheme_cell = resolved.get(
            "scheme_name"
        )

        scheme_name = (
            normalized_text(
                scheme_cell.value
            )
            if scheme_cell
            else ""
        )

        if not scheme_name:
            result[
                "rows_missing_scheme_name"
            ] += 1

        identity = normalized_identity(
            scheme_name
        )

        if identity:
            result[
                "_identities"
            ].append(identity)

        portal_cell = resolved.get(
            "portal_link"
        )

        if portal_cell:

            hyperlink = getattr(
                portal_cell,
                "hyperlink",
                None,
            )

            if (
                hyperlink
                and getattr(
                    hyperlink,
                    "target",
                    None,
                )
            ):
                result[
                    "portal_hyperlink_cells"
                ] += 1

    return result


def inspect_nonstandard_sheet(
    worksheet,
):

    merged_lookup = build_merged_lookup(
        worksheet
    )

    meaningful_rows = 0
    populated_cells = 0
    hyperlink_cells = 0

    max_column = min(
        worksheet.max_column or 0,
        MAX_INSPECT_COLUMNS,
    )

    for row_number in range(
        1,
        (worksheet.max_row or 0) + 1,
    ):

        row_has_content = False

        for column in range(
            1,
            max_column + 1,
        ):

            cell = resolved_cell(
                worksheet,
                row_number,
                column,
                merged_lookup,
            )

            if not cell_has_content(
                cell
            ):
                continue

            row_has_content = True
            populated_cells += 1

            hyperlink = getattr(
                cell,
                "hyperlink",
                None,
            )

            if (
                hyperlink
                and getattr(
                    hyperlink,
                    "target",
                    None,
                )
            ):
                hyperlink_cells += 1

        if row_has_content:
            meaningful_rows += 1

    return {
        "meaningful_rows": meaningful_rows,
        "populated_cells": populated_cells,
        "hyperlink_cells": hyperlink_cells,
        "merged_ranges": len(
            worksheet.merged_cells.ranges
        ),
    }


def inspect_workbook(path):

    path = Path(path)

    workbook = load_workbook(
        path,
        read_only=False,
        data_only=False,
        keep_links=True,
    )

    result = {
        "sheet_count": len(
            workbook.sheetnames
        ),
        "sheets": [],
        "missing_expected_sheets": [],
        "unexpected_sheets": [],
        "structured_scheme_rows": 0,
        "cross_sheet_duplicate_names": 0,
        "cross_sheet_duplicate_occurrences": 0,
    }

    expected = set(
        EXPECTED_SHEETS
    )

    actual = set(
        workbook.sheetnames
    )

    result[
        "missing_expected_sheets"
    ] = sorted(
        expected - actual
    )

    result[
        "unexpected_sheets"
    ] = sorted(
        actual - expected
    )

    identity_sheets = {}

    try:

        for sheet_name in (
            workbook.sheetnames
        ):

            worksheet = workbook[
                sheet_name
            ]

            family = sheet_family(
                sheet_name
            )

            entry = {
                "name": sheet_name,
                "family": family,
            }

            if sheet_name in SCHEME_TABLES:

                details = (
                    inspect_scheme_sheet(
                        worksheet
                    )
                )

                identities = details.pop(
                    "_identities"
                )

                entry.update(
                    details
                )

                result[
                    "structured_scheme_rows"
                ] += details[
                    "active_rows"
                ]

                for identity in identities:

                    identity_sheets.setdefault(
                        identity,
                        set(),
                    ).add(
                        sheet_name
                    )

            else:

                entry.update(
                    inspect_nonstandard_sheet(
                        worksheet
                    )
                )

            result["sheets"].append(
                entry
            )

    finally:

        workbook.close()

    duplicate_groups = {
        identity: sheets
        for identity, sheets
        in identity_sheets.items()
        if len(sheets) > 1
    }

    result[
        "cross_sheet_duplicate_names"
    ] = len(
        duplicate_groups
    )

    result[
        "cross_sheet_duplicate_occurrences"
    ] = sum(
        len(sheets)
        for sheets
        in duplicate_groups.values()
    )

    return result
PY


# ============================================================
# 4. SAFE REAL-WORKBOOK AUDIT
# ============================================================

cat > confidential_source/audit/step9c_real_workbook_dry_run.py <<'PY'
from pathlib import Path

from toolkit.importing.workbook_reader import (
    file_sha256,
    inspect_workbook,
)


EXPECTED_SHA256 = (
    "4228c2dadda12e220617acba7e301f809"
    "edf0dec42fc98983b1aef934287744d"
)


SOURCE_DIR = Path(
    "confidential_source"
)


matches = []

for candidate in SOURCE_DIR.glob(
    "*.xlsx"
):

    if candidate.name.startswith(
        "~$"
    ):
        continue

    try:
        digest = file_sha256(
            candidate
        )
    except OSError:
        continue

    if digest == EXPECTED_SHA256:
        matches.append(
            candidate
        )


if len(matches) != 1:

    raise SystemExit(
        "STOPPED SAFELY: expected exactly one workbook "
        "matching the approved SHA-256; "
        f"found {len(matches)}."
    )


workbook_path = matches[0]

result = inspect_workbook(
    workbook_path
)


lines = []

lines.append(
    "=" * 80
)

lines.append(
    "BHARATNXT WAVE — STEP 9C REAL WORKBOOK DRY RUN"
)

lines.append(
    "=" * 80
)

lines.append("")

lines.append(
    "Workbook SHA-256 verified: YES"
)

lines.append(
    f"Workbook sheets: {result['sheet_count']}"
)

lines.append(
    "Workbook cell values included in this report: NO"
)

lines.append("")

lines.append(
    "STRUCTURED SCHEME TOTAL"
)

lines.append(
    f"Active structured rows: "
    f"{result['structured_scheme_rows']}"
)

lines.append("")

lines.append(
    "CROSS-SHEET DUPLICATE CANDIDATES"
)

lines.append(
    f"Distinct duplicated normalized names: "
    f"{result['cross_sheet_duplicate_names']}"
)

lines.append(
    f"Total cross-sheet occurrences: "
    f"{result['cross_sheet_duplicate_occurrences']}"
)

lines.append("")

lines.append(
    "EXPECTED SHEET CHECK"
)

lines.append(
    "Missing expected sheets: "
    + (
        ", ".join(
            result[
                "missing_expected_sheets"
            ]
        )
        or "NONE"
    )
)

lines.append(
    "Unexpected sheets: "
    + (
        ", ".join(
            result[
                "unexpected_sheets"
            ]
        )
        or "NONE"
    )
)

lines.append("")


for sheet in result["sheets"]:

    lines.append(
        "-" * 80
    )

    lines.append(
        f"{sheet['name']} "
        f"[{sheet['family']}]"
    )

    if (
        sheet["family"]
        == "SCHEME_TABLE"
    ):

        lines.append(
            f"Header row: "
            f"{sheet['header_row']}"
        )

        lines.append(
            "Mapped fields: "
            + (
                ", ".join(
                    sheet["fields"]
                )
                or "NONE"
            )
        )

        lines.append(
            f"Active rows: "
            f"{sheet['active_rows']}"
        )

        lines.append(
            f"Rows missing scheme name: "
            f"{sheet['rows_missing_scheme_name']}"
        )

        lines.append(
            f"Excel hyperlink cells in portal field: "
            f"{sheet['portal_hyperlink_cells']}"
        )

        lines.append(
            f"Merged ranges: "
            f"{sheet['merged_ranges']}"
        )

    else:

        lines.append(
            f"Meaningful rows: "
            f"{sheet['meaningful_rows']}"
        )

        lines.append(
            f"Populated cells: "
            f"{sheet['populated_cells']}"
        )

        lines.append(
            f"Hyperlink cells: "
            f"{sheet['hyperlink_cells']}"
        )

        lines.append(
            f"Merged ranges: "
            f"{sheet['merged_ranges']}"
        )

    lines.append("")


lines.append(
    "=" * 80
)

lines.append(
    "SAFETY"
)

lines.append(
    "=" * 80
)

lines.append(
    "No Django database records were created or changed."
)

lines.append(
    "No Service records were created or changed."
)

lines.append(
    "No ImportRow records were created."
)

lines.append(
    "No migration was created or applied."
)

lines.append(
    "The Excel workbook was opened read-only in practice "
    "and was never saved."
)

lines.append(
    "No workbook cell values are printed in this report."
)


output = (
    SOURCE_DIR
    / "audit"
    / "step9c_real_workbook_SAFE_TO_SHARE.txt"
)

output.write_text(
    "\n".join(lines),
    encoding="utf-8",
)


print(
    "STEP 9C DRY RUN COMPLETE"
)

print(
    f"SAFE REPORT: {output}"
)
PY


# ============================================================
# 5. STATIC CHECKS
# ============================================================

echo ""
echo "===== PYTHON COMPILE ====="

python -m py_compile \
    toolkit/importing/__init__.py \
    toolkit/importing/sheet_registry.py \
    toolkit/importing/workbook_reader.py \
    confidential_source/audit/step9c_real_workbook_dry_run.py

echo "PASS: Step 9C files compile."


echo ""
echo "===== DJANGO CHECK ====="

python manage.py check


echo ""
echo "===== MODEL CHECK ====="

python manage.py makemigrations \
    --check \
    --dry-run


# ============================================================
# 6. REAL WORKBOOK DRY RUN
# ============================================================

echo ""
echo "===== REAL WORKBOOK STRUCTURAL DRY RUN ====="

python \
    confidential_source/audit/step9c_real_workbook_dry_run.py


echo ""
echo "===== SAFE REPORT ====="

cat \
    confidential_source/audit/step9c_real_workbook_SAFE_TO_SHARE.txt


echo ""
echo "============================================================"
echo "STEP 9C SUCCESS"
echo "============================================================"

echo ""
echo "No database data was changed."
echo "No ImportRow records were created."
echo "No Service records were changed."
echo "No migration was created."
echo "No workbook cell values were printed."
