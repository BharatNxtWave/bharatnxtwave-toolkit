from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.http import require_POST
from django.utils.http import url_has_allowed_host_and_scheme

from .activity import log_activity
from .models import LoginSession
from .network_security import get_request_ip


def default_workspace_redirect(user):
    if (
        user.is_superuser
        or user.role in {
            "SUPER_ADMIN",
            "IT_ADMIN",
            "DATA_ADMIN",
            "SECURITY_ADMIN",
        }
    ):
        return "dashboard:admin_overview"

    return "dashboard:home"


def login_view(request):
    if request.user.is_authenticated:
        return redirect(
            default_workspace_redirect(request.user)
        )

    if request.method == "POST":
        form = AuthenticationForm(
            request=request,
            data=request.POST
        )

        if form.is_valid():
            user = form.get_user()

            login(request, user)

            # Ensure Django has generated a session key.
            if not request.session.session_key:
                request.session.save()

            LoginSession.objects.create(
                user=user,
                session_key=request.session.session_key or "",
                ip_address=get_request_ip(request) or None,
                user_agent=request.META.get(
                    "HTTP_USER_AGENT",
                    ""
                ),
                is_active=True,
            )

            log_activity(
                request,
                "LOGIN",
                "Employee signed in.",
                target_type="user",
                target_id=user.pk,
            )

            messages.success(
                request,
                "Signed in successfully."
            )

            next_url = request.GET.get("next")

            if (
                next_url
                and url_has_allowed_host_and_scheme(
                    url=next_url,
                    allowed_hosts={request.get_host()},
                    require_https=request.is_secure(),
                )
            ):
                return redirect(next_url)

            return redirect(
                default_workspace_redirect(user)
            )

    else:
        form = AuthenticationForm(request=request)

    return render(
        request,
        "accounts/login.html",
        {"form": form}
    )


@require_POST
def logout_view(request):
    if request.user.is_authenticated:
        session_key = request.session.session_key

        if session_key:
            LoginSession.objects.filter(
                user=request.user,
                session_key=session_key,
                is_active=True
            ).update(
                is_active=False,
                logout_at=timezone.now()
            )

    if request.user.is_authenticated:
        log_activity(
            request,
            "LOGOUT",
            "Employee signed out.",
            target_type="user",
            target_id=request.user.pk,
        )

    logout(request)

    return redirect("accounts:login")


@login_required
@require_POST
def session_location_update(request):
    import json
    from decimal import Decimal, InvalidOperation

    try:
        payload = json.loads(request.body.decode("utf-8"))

        latitude = Decimal(str(payload.get("latitude")))
        longitude = Decimal(str(payload.get("longitude")))
        accuracy = float(payload.get("accuracy"))

    except (TypeError, ValueError, InvalidOperation, json.JSONDecodeError):
        return JsonResponse(
            {"ok": False, "error": "Invalid location data"},
            status=400
        )

    if not (-90 <= latitude <= 90):
        return JsonResponse(
            {"ok": False, "error": "Invalid latitude"},
            status=400
        )

    if not (-180 <= longitude <= 180):
        return JsonResponse(
            {"ok": False, "error": "Invalid longitude"},
            status=400
        )

    if accuracy < 0:
        return JsonResponse(
            {"ok": False, "error": "Invalid accuracy"},
            status=400
        )

    session_key = request.session.session_key

    if not session_key:
        return JsonResponse(
            {"ok": False, "error": "No active session"},
            status=400
        )

    login_session = (
        LoginSession.objects
        .filter(
            user=request.user,
            session_key=session_key,
            is_active=True
        )
        .order_by("-login_at")
        .first()
    )

    if not login_session:
        return JsonResponse(
            {"ok": False, "error": "Login session not found"},
            status=404
        )

    login_session.latitude = latitude
    login_session.longitude = longitude
    login_session.location_accuracy = accuracy

    login_session.save(
        update_fields=[
            "latitude",
            "longitude",
            "location_accuracy",
        ]
    )

    return JsonResponse({"ok": True})
