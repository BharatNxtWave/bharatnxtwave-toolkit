(function () {
    "use strict";


    /* =====================================================
       DATE PICKER
    ===================================================== */

    const picker =
        document.querySelector(
            ".bn-date-picker"
        );


    if (picker) {

        document.addEventListener(
            "click",
            function (event) {

                if (
                    picker.open
                    &&
                    !picker.contains(event.target)
                ) {

                    picker.removeAttribute(
                        "open"
                    );

                }

            }
        );

    }



    /* =====================================================
       INTERACTIVE TOOLKIT ACTIVITY PIE
    ===================================================== */

    const chart =
        document.getElementById(
            "bn-activity-pie"
        );


    if (!chart) {
        return;
    }


    const searchCount =
        Number(chart.dataset.searches) || 0;


    const clientCount =
        Number(chart.dataset.clientChecks) || 0;


    const total =
        searchCount + clientCount;


    const searchCircle =
        document.getElementById(
            "bn-pie-search"
        );


    const clientCircle =
        document.getElementById(
            "bn-pie-client"
        );


    const centerLabel =
        document.getElementById(
            "bn-pie-center-label"
        );


    const centerValue =
        document.getElementById(
            "bn-pie-center-value"
        );


    const centerDetail =
        document.getElementById(
            "bn-pie-center-detail"
        );


    const searchPercentElement =
        document.getElementById(
            "bn-search-percent"
        );


    const clientPercentElement =
        document.getElementById(
            "bn-client-percent"
        );


    const emptyMessage =
        document.getElementById(
            "bn-pie-empty"
        );


    const radius = 82;

    const circumference =
        2 * Math.PI * radius;



    function percentage(value) {

        if (!total) {
            return 0;
        }

        return Math.round(
            (value / total) * 100
        );

    }



    const searchPercent =
        percentage(searchCount);


    const clientPercent =
        percentage(clientCount);



    if (searchPercentElement) {

        searchPercentElement.textContent =
            searchPercent + "%";

    }


    if (clientPercentElement) {

        clientPercentElement.textContent =
            clientPercent + "%";

    }



    function resetCenter() {

        centerLabel.textContent =
            "TOTAL ACTIONS";

        centerValue.textContent =
            total;

        centerDetail.textContent =
            total === 1
                ? "1 Toolkit action"
                : total + " Toolkit actions";

    }



    function showSeries(
        label,
        value,
        percent
    ) {

        centerLabel.textContent =
            label;

        centerValue.textContent =
            value;

        centerDetail.textContent =
            percent + "% of activity";

    }



    function clearActiveSeries() {

        document
            .querySelectorAll(
                ".bn-pie-legend-item"
            )
            .forEach(function (item) {

                item.classList.remove(
                    "active"
                );

            });


        searchCircle.classList.remove(
            "highlighted",
            "dimmed"
        );


        clientCircle.classList.remove(
            "highlighted",
            "dimmed"
        );

    }



    function activateSeries(series) {

        clearActiveSeries();


        const button =
            document.querySelector(
                '[data-pie-series="'
                + series
                + '"]'
            );


        if (button) {

            button.classList.add(
                "active"
            );

        }


        if (series === "search") {

            searchCircle.classList.add(
                "highlighted"
            );

            clientCircle.classList.add(
                "dimmed"
            );


            showSeries(
                "TOOLKIT SEARCHES",
                searchCount,
                searchPercent
            );

        }


        else if (series === "client") {

            clientCircle.classList.add(
                "highlighted"
            );

            searchCircle.classList.add(
                "dimmed"
            );


            showSeries(
                "CLIENT SERVICE CHECKS",
                clientCount,
                clientPercent
            );

        }

    }



    /* =====================================================
       ZERO DATA
    ===================================================== */

    if (total <= 0) {

        searchCircle.style.display =
            "none";

        clientCircle.style.display =
            "none";


        centerLabel.textContent =
            "NO ACTIVITY";

        centerValue.textContent =
            "0";

        centerDetail.textContent =
            "Selected period";


        if (emptyMessage) {

            emptyMessage.hidden =
                false;

        }

        return;

    }



    /* =====================================================
       PIE GEOMETRY
    ===================================================== */

    const searchLength =
        circumference
        * (
            searchCount
            / total
        );


    const clientLength =
        circumference
        * (
            clientCount
            / total
        );



    /*
     * Initial zero-state makes the chart animate
     * into position after the page loads.
     */

    searchCircle.style.strokeDasharray =
        "0 "
        + circumference;


    clientCircle.style.strokeDasharray =
        "0 "
        + circumference;


    clientCircle.style.strokeDashoffset =
        "0";


    resetCenter();



    requestAnimationFrame(
        function () {

            requestAnimationFrame(
                function () {

                    searchCircle.style
                        .strokeDasharray =
                        searchLength
                        + " "
                        + (
                            circumference
                            - searchLength
                        );


                    clientCircle.style
                        .strokeDasharray =
                        clientLength
                        + " "
                        + (
                            circumference
                            - clientLength
                        );


                    clientCircle.style
                        .strokeDashoffset =
                        String(
                            -searchLength
                        );

                }
            );

        }
    );



    /* =====================================================
       LEGEND INTERACTION
    ===================================================== */

    document
        .querySelectorAll(
            "[data-pie-series]"
        )
        .forEach(function (button) {

            const series =
                button.dataset.pieSeries;


            button.addEventListener(
                "mouseenter",
                function () {

                    activateSeries(
                        series
                    );

                }
            );


            button.addEventListener(
                "focus",
                function () {

                    activateSeries(
                        series
                    );

                }
            );


            button.addEventListener(
                "click",
                function () {

                    activateSeries(
                        series
                    );

                }
            );


            button.addEventListener(
                "mouseleave",
                function () {

                    clearActiveSeries();

                    resetCenter();

                }
            );


            button.addEventListener(
                "blur",
                function () {

                    clearActiveSeries();

                    resetCenter();

                }
            );

        });



    /* =====================================================
       PIE SLICE INTERACTION
    ===================================================== */

    searchCircle.addEventListener(
        "mouseenter",
        function () {

            activateSeries(
                "search"
            );

        }
    );


    clientCircle.addEventListener(
        "mouseenter",
        function () {

            activateSeries(
                "client"
            );

        }
    );


    [
        searchCircle,
        clientCircle
    ].forEach(function (circle) {

        circle.addEventListener(
            "mouseleave",
            function () {

                clearActiveSeries();

                resetCenter();

            }
        );

    });

})();
